#!/usr/bin/env python3
"""Generates the PlayerBots world-database SQL for LegionCore 7.3.5.

Produces one idempotent file: it can be re-applied at any time without
duplicating rows or failing. Entry range 800000-800999 is reserved for bots.
"""

import pathlib
import sys

ENTRY_BASE = 800000

# role ids must match PlayerBotRole in PlayerBots.h
TANK, HEALER, MELEE, RANGED = 0, 1, 2, 3
ROLE_NAME = {TANK: "tank", HEALER: "healer", MELEE: "melee", RANGED: "ranged"}

# creature_template.unit_class: 1 warrior (rage), 2 paladin (mana), 4 rogue (energy), 8 mage (mana)
ROLE_UNIT_CLASS = {TANK: 1, MELEE: 1, HEALER: 2, RANGED: 8}

ALLIANCE, HORDE = 0, 1
FACTION_TEMPLATE = {ALLIANCE: 1801, HORDE: 1802}

# race id -> (name, male display, female display)
#
# These are NPC display IDs, verified against the official world dump
# (LegionCore_full_735.26972_2024_10_23): each one exists in creature_model_info
# and is already used by real humanoid NPCs, so the client has a textured model
# for it. Player display IDs from ChrRaces (49, 50, 51, ...) must NOT be used:
# nothing in the world uses them, and a creature wearing one renders white.
RACES = {
    1:  ("Human",     3167,  3167),   # Stormwind City Guard / Northshire Guard
    2:  ("Orc",       4259,  4259),   # Orgrimmar Grunt / Stonebreaker Grunt
    3:  ("Dwarf",     1598,  1598),   # Ironforge Mountaineer / Coldridge Mountaineer
    4:  ("NightElf",  4841,  4841),   # Astranaar Sentinel / Ashenvale Sentinel
    5:  ("Undead",    7117,  7117),   # Deathguard Elite / Tirisfal Deathguard
    6:  ("Tauren",    2141,  2141),   # Bluffwatcher / Thunder Bluff Brave
    7:  ("Gnome",     46504, 46504),  # Gnome Laborer
    8:  ("Troll",     31737, 31737),  # Darkspear Warrior / Sen'jin Guardian
    10: ("BloodElf",  15511, 15511),  # Silvermoon Guardian / Sunstrider Guardian
    11: ("Draenei",   17372, 17372),  # Exodar Peacekeeper / Azuremyst Peacekeeper
}

ALLIANCE_RACES = [1, 3, 4, 7, 11]
HORDE_RACES    = [2, 5, 6, 8, 10]

NAMES = {
    1:  ["Aldric", "Marcus", "Garrick", "Edwin", "Tobias", "Rowan", "Cedric", "Lysa", "Marin", "Elise",
         "Katrin", "Seraphine", "Alden", "Brom", "Isolde", "Harlan"],
    3:  ["Thoribald", "Brannik", "Durgan", "Kegger", "Morgran", "Hilda", "Brunnhild", "Thulda"],
    4:  ["Thenysil", "Aelrindel", "Shaldorei", "Nalarin", "Mythanil", "Shandris", "Tyrande", "Velandra"],
    7:  ["Fizzwick", "Nimble", "Cogsworth", "Bimbley", "Tinkerbell", "Wizzle"],
    11: ["Oriano", "Vindaar", "Exarchus", "Nobundo", "Ishara", "Yrel"],
    2:  ["Grokk", "Thragan", "Morg", "Kazgar", "Durzak", "Hargoth", "Rexxa", "Zagara", "Gorka", "Urga"],
    5:  ["Mordrek", "Sallow", "Grimlund", "Ashgrave", "Morwyn", "Ravena", "Nethys", "Lilith"],
    6:  ["Kargath", "Stonehoof", "Thunderhorn", "Grimtotem", "Mahani", "Ayasha", "Winterhoof"],
    8:  ["Zul'tak", "Jin'rokh", "Vol'kar", "Rakjan", "Zentha", "Jinara", "Sen'ja"],
    10: ["Kael'ran", "Sylvanor", "Theronis", "Anveena", "Liadrin", "Valeera", "Elyndra", "Sunstrider"],
}

# ----------------------------------------------------------------- rotations
# (role, priority, spell, condition, value, cooldown_ms, min_range, max_range,
#  target_self, triggered, comment)
#
# conditions: 0 always, 1 self hp% below, 2 self hp% above, 3 target hp% below,
#             4 target hp% above, 5 enemies around >= value, 6 target is player,
#             7 target is not a player
#
# The area-of-effect rows are gated on condition 5 (several enemies around), which
# is what stops a bot from firing weak aoe at a single enemy player in world pvp.
ROTATIONS = [
    # ---- tank: protection warrior ----
    (TANK,   10, 355,   7, 0,  8000, 0,  30, 0, 1, "Taunt - pull creatures, never players"),
    (TANK,   20, 23922, 0, 0,  6000, 0,   5, 0, 1, "Shield Slam"),
    (TANK,   30, 6572,  0, 0,  9000, 0,   5, 0, 1, "Revenge"),
    (TANK,   40, 6343,  5, 3,  6000, 0,   8, 0, 1, "Thunder Clap - only with 3+ enemies on us"),
    (TANK,   50, 2565,  1, 50, 20000, 0,  0, 1, 1, "Shield Block when hurt"),
    (TANK,   60, 20243, 0, 0,  2000, 0,   5, 0, 1, "Devastate - filler"),

    # ---- melee dps: arms/fury warrior ----
    (MELEE,  10, 100,   0, 0, 15000, 8,  25, 0, 1, "Charge into range"),
    (MELEE,  20, 5308,  3, 20, 3000, 0,   5, 0, 1, "Execute below 20%"),
    (MELEE,  30, 1715,  6, 0, 12000, 0,   5, 0, 1, "Hamstring - players only"),
    (MELEE,  40, 12294, 0, 0,  6000, 0,   5, 0, 1, "Mortal Strike"),
    (MELEE,  50, 1680,  5, 3,  8000, 0,   8, 0, 1, "Whirlwind - only with 3+ enemies"),

    # ---- ranged dps: frost mage ----
    (RANGED, 10, 122,   5, 2, 20000, 0,  10, 0, 0, "Frost Nova when several are on us"),
    (RANGED, 20, 30455, 3, 25, 3000, 5,  35, 0, 0, "Ice Lance to finish"),
    (RANGED, 30, 116,   0, 0,  2500, 5,  35, 0, 0, "Frostbolt - main nuke"),
    (RANGED, 40, 133,   0, 0,  3000, 5,  35, 0, 0, "Fireball - filler"),

    # ---- healer: holy ----
    # Milestone 1 bots travel alone, so the healer keeps itself up; healing other
    # party members arrives with the group/queue work.
    (HEALER, 10, 17,    1, 60, 15000, 0,  0, 1, 0, "Power Word: Shield"),
    (HEALER, 20, 2061,  1, 50,  6000, 0,  0, 1, 0, "Flash Heal"),
    (HEALER, 30, 139,   1, 80, 12000, 0,  0, 1, 0, "Renew"),
    (HEALER, 40, 14914, 0, 0,   8000, 5, 30, 0, 0, "Holy Fire"),
    (HEALER, 50, 585,   0, 0,   2500, 5, 30, 0, 0, "Smite - filler"),
]

# ------------------------------------------------------------------- areas
# (map, zone, x, y, z, radius, min, max, team_mask, name)
# team_mask: 1 alliance, 2 horde, 3 both.
# Z is only a hint - the module drops every bot onto the real ground height at
# spawn time, and ".bots addarea" lets you record exact spots in game.
AREAS = [
    (0,   12, -9464.0,    62.0,  56.0, 120, 1,  12, 1, "Elwynn Forest - Goldshire"),
    (0,   40, -10620.0, 1037.0,  33.0, 140, 10, 20, 1, "Westfall - Sentinel Hill"),
    (0,   44, -9240.0, -2150.0,  65.0, 140, 15, 26, 1, "Redridge - Lakeshire"),
    (0,   10, -10510.0, -1230.0, 42.0, 140, 20, 32, 1, "Duskwood - Darkshire"),
    (0,   33, -14440.0,  490.0,  16.0, 160, 30, 45, 3, "Stranglethorn - Booty Bay (contested)"),
    (0, 1519, -8833.0,   628.0,  94.0, 160, 10, 110, 1, "Stormwind City"),
    (0,   85,  2270.0,   330.0,  34.0, 120, 1,  12, 2, "Tirisfal Glades - Brill"),
    (1,   14,   310.0, -4700.0,  10.0, 120, 1,  12, 2, "Durotar - Razor Hill"),
    (1,  215, -2360.0,  -350.0,  -9.0, 120, 1,  12, 2, "Mulgore - Bloodhoof Village"),
    (1,   17,  -430.0, -2650.0,  95.0, 160, 10, 25, 3, "The Barrens - Crossroads (contested)"),
    (1, 1637,  1630.0, -4373.0,  31.0, 160, 10, 110, 2, "Orgrimmar"),
]


# Valid race/class pairs, taken from the `playercreateinfo` table of the
# official world dump (LegionCore_full_735.26972) - the same table the server
# checks on character creation. A pair that is not here is refused with
# "Possible hacking-attempt ... invalid race/class pair".
VALID_CLASSES = {
    1:  {1, 2, 3, 4, 5, 6, 8, 9, 10},         # Human
    2:  {1, 3, 4, 6, 7, 8, 9, 10},            # Orc
    3:  {1, 2, 3, 4, 5, 6, 7, 8, 9, 10},      # Dwarf
    4:  {1, 3, 4, 5, 6, 8, 10, 11, 12},       # Night Elf
    5:  {1, 3, 4, 5, 6, 8, 9, 10},            # Undead
    6:  {1, 2, 3, 5, 6, 7, 10, 11},           # Tauren
    7:  {1, 3, 4, 5, 6, 8, 9, 10},            # Gnome  (no paladin)
    8:  {1, 3, 4, 5, 6, 7, 8, 9, 10, 11},     # Troll
    10: {1, 2, 3, 4, 5, 6, 8, 9, 10, 12},     # Blood Elf
    11: {1, 2, 3, 5, 6, 7, 8, 10},            # Draenei
}

# Which player classes suit each role, best first. Intersected with the race's
# valid set, so the result is always a combination the server accepts.
#   1 warrior  2 paladin  3 hunter  4 rogue   5 priest   6 death knight
#   7 shaman   8 mage     9 warlock 10 monk  11 druid   12 demon hunter
ROLE_PLAYER_CLASSES = {
    TANK:   [1, 2, 6, 11, 10, 12],
    HEALER: [5, 2, 11, 7, 10],
    MELEE:  [4, 1, 6, 10, 7, 12],
    RANGED: [8, 9, 3, 5],
}

# Character names are varchar(12) in `characters` and `account_last_played_character`.
NAME_MAX = 12


def pick_player_class(race, role):
    """A class the server will accept for this race, suited to the role."""
    allowed = VALID_CLASSES.get(race, set())
    for candidate in ROLE_PLAYER_CLASSES[role]:
        if candidate in allowed:
            return candidate
    return sorted(allowed)[0] if allowed else 1


def make_bot_name(base, role, index):
    """Fit <base><RoleLetter><NNN> into 12 characters."""
    suffix = "{}{:03d}".format(ROLE_NAME[role][0].upper(), index)
    return base[:NAME_MAX - len(suffix)] + suffix


def build_profiles():
    """One creature entry per bot identity: race + gender + role + a name."""
    profiles = []
    entry = ENTRY_BASE
    per_role_per_team = 6     # 6 identities x 4 roles x 2 teams x (races cycled)

    for team, races in ((ALLIANCE, ALLIANCE_RACES), (HORDE, HORDE_RACES)):
        for role in (TANK, HEALER, MELEE, RANGED):
            used = 0
            race_cycle = 0
            while used < per_role_per_team * len(races) // 2:
                race = races[race_cycle % len(races)]
                race_cycle += 1
                pool = NAMES[race]
                for i in range(2):      # one male, one female per pass
                    if used >= per_role_per_team * len(races) // 2:
                        break
                    gender = i
                    name = pool[(used + race_cycle * 3 + gender) % len(pool)]
                    profiles.append({
                        "entry": entry,
                        "race": race,
                        "gender": gender,
                        "role": role,
                        "team": team,
                        "class": pick_player_class(race, role),
                        "name": make_bot_name(name, role, entry - ENTRY_BASE),
                        "display": RACES[race][1 + gender],
                    })
                    entry += 1
                    used += 1
    return profiles


def sql_escape(text):
    return text.replace("\\", "\\\\").replace("'", "''")


def main(out_path):
    profiles = build_profiles()
    lines = []
    w = lines.append

    w("-- LegionCore PlayerBots - world database objects")
    w("-- Generated by tools/Generate-PlayerBots-Sql.py. Safe to re-apply at any time.")
    w("--")
    w("-- Creature entries 800000-800999 are reserved for bots.")
    w("")
    w("SET @BOT_MIN := 800000;")
    w("SET @BOT_MAX := 800999;")
    w("")

    # ------------------------------------------------------------- tables
    w("-- ---------------------------------------------------------------- tables")
    w("""CREATE TABLE IF NOT EXISTS `playerbot_profile` (
  `entry`  INT UNSIGNED NOT NULL COMMENT 'creature_template.entry',
  `class`  TINYINT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'informational: wow class id',
  `race`   TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `gender` TINYINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '0 male, 1 female',
  `role`   TINYINT UNSIGNED NOT NULL DEFAULT 2 COMMENT '0 tank, 1 healer, 2 melee, 3 ranged',
  `team`   TINYINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '0 alliance, 1 horde',
  `name`   VARCHAR(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`entry`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='PlayerBots: one row per bot identity';""")
    w("")
    w("""CREATE TABLE IF NOT EXISTS `playerbot_area` (
  `id`        INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `map`       INT UNSIGNED NOT NULL DEFAULT 0,
  `zone`      INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '0 = any zone on that map',
  `x`         FLOAT NOT NULL DEFAULT 0,
  `y`         FLOAT NOT NULL DEFAULT 0,
  `z`         FLOAT NOT NULL DEFAULT 0,
  `radius`    FLOAT NOT NULL DEFAULT 80,
  `min_level` TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `max_level` TINYINT UNSIGNED NOT NULL DEFAULT 110,
  `team_mask` TINYINT UNSIGNED NOT NULL DEFAULT 3 COMMENT '1 alliance, 2 horde, 3 both',
  `weight`    INT UNSIGNED NOT NULL DEFAULT 1,
  `name`      VARCHAR(128) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='PlayerBots: where wanderers may appear';""")
    w("")
    w("""CREATE TABLE IF NOT EXISTS `playerbot_rotation` (
  `role`        TINYINT UNSIGNED NOT NULL COMMENT '0 tank, 1 healer, 2 melee, 3 ranged',
  `priority`    TINYINT UNSIGNED NOT NULL COMMENT 'lower runs first',
  `spell_id`    INT UNSIGNED NOT NULL,
  `condition`   TINYINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '0 always, 1 self hp<, 2 self hp>, 3 target hp<, 4 target hp>, 5 enemies>=, 6 target is player, 7 target is not player',
  `value`       FLOAT NOT NULL DEFAULT 0,
  `cooldown_ms` INT UNSIGNED NOT NULL DEFAULT 1500,
  `min_range`   FLOAT NOT NULL DEFAULT 0,
  `max_range`   FLOAT NOT NULL DEFAULT 40,
  `target_self` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `triggered`   TINYINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '1 = ignore power cost (melee resources a creature never builds)',
  `comment`     VARCHAR(128) NOT NULL DEFAULT '',
  PRIMARY KEY (`role`, `priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='PlayerBots: data-driven spell priority per role';""")
    w("")

    # --------------------------------------------------------- creatures
    w("-- ------------------------------------------------- creature templates")
    w("DELETE FROM `creature_template`     WHERE `entry` BETWEEN @BOT_MIN AND @BOT_MAX;")
    w("DELETE FROM `creature_template_wdb` WHERE `Entry` BETWEEN @BOT_MIN AND @BOT_MAX;")
    w("DELETE FROM `playerbot_profile`     WHERE `entry` BETWEEN @BOT_MIN AND @BOT_MAX;")
    w("")

    w("INSERT INTO `creature_template` (`entry`, `minlevel`, `maxlevel`, `faction`, `npcflag`, `speed_walk`, `speed_run`, "
      "`scale`, `unit_class`, `unit_flags`, `dmg_multiplier`, `baseattacktime`, `rangeattacktime`, `MovementType`, "
      "`AIName`, `ScriptName`, `RegenHealth`, `flags_extra`, `WorldEffects`, `PassiveSpells`) VALUES")
    rows = []
    for p in profiles:
        rows.append("({}, 1, 110, {}, 0, 1.0, 1.14286, 1.0, {}, 0, 1.0, 2000, 2000, 0, '', 'npc_playerbot_wanderer', 1, 0, '', '')".format(
            p["entry"], FACTION_TEMPLATE[p["team"]], ROLE_UNIT_CLASS[p["role"]]))
    w(",\n".join(rows) + ";")
    w("")

    w("INSERT INTO `creature_template_wdb` (`Entry`, `Name1`, `Type`, `Classification`, `DisplayId1`, `HpMulti`, `PowerMulti`, `VerifiedBuild`) VALUES")
    rows = []
    for p in profiles:
        rows.append("({}, '{}', 7, 0, {}, 1, 1, 26972)".format(p["entry"], sql_escape(p["name"]), p["display"]))
    w(",\n".join(rows) + ";")
    w("")

    w("-- ------------------------------------------------------------ profiles")
    w("INSERT INTO `playerbot_profile` (`entry`, `class`, `race`, `gender`, `role`, `team`, `name`) VALUES")
    rows = []
    for p in profiles:
        rows.append("({}, {}, {}, {}, {}, {}, '{}')".format(
            p["entry"], p["class"], p["race"], p["gender"], p["role"], p["team"], sql_escape(p["name"])))
    w(",\n".join(rows) + ";")
    w("")

    # ------------------------------------------------------------- areas
    w("-- --------------------------------------------------------- spawn areas")
    w("-- Only the starter set. Use '.bots addarea <min> <max> [radius]' in game to")
    w("-- record exact spots of your own - those rows are kept, these are replaced.")
    w("DELETE FROM `playerbot_area` WHERE `name` LIKE 'LegionCore starter%';")
    w("INSERT INTO `playerbot_area` (`map`, `zone`, `x`, `y`, `z`, `radius`, `min_level`, `max_level`, `team_mask`, `weight`, `name`) VALUES")
    rows = []
    for (m, z, x, y, zz, r, lo, hi, mask, name) in AREAS:
        rows.append("({}, {}, {}, {}, {}, {}, {}, {}, {}, 1, 'LegionCore starter: {}')".format(
            m, z, x, y, zz, r, lo, hi, mask, sql_escape(name)))
    w(",\n".join(rows) + ";")
    w("")

    # ---------------------------------------------------------- rotations
    w("-- ----------------------------------------------------------- rotations")
    w("-- Spell ids are validated when the world starts: anything this client's")
    w("-- data does not know is logged and skipped, never crashed on. Edit freely")
    w("-- and run '.bots reload' to apply without a restart.")
    w("DELETE FROM `playerbot_rotation`;")
    w("INSERT INTO `playerbot_rotation` (`role`, `priority`, `spell_id`, `condition`, `value`, `cooldown_ms`, "
      "`min_range`, `max_range`, `target_self`, `triggered`, `comment`) VALUES")
    rows = []
    for (role, prio, spell, cond, val, cd, mn, mx, self_t, trig, comment) in ROTATIONS:
        rows.append("({}, {}, {}, {}, {}, {}, {}, {}, {}, {}, '{}')".format(
            role, prio, spell, cond, val, cd, mn, mx, self_t, trig, sql_escape(comment)))
    w(",\n".join(rows) + ";")
    w("")

    text = "\n".join(lines) + "\n"
    pathlib.Path(out_path).write_text(text, encoding="utf-8", newline="\n")

    print("wrote {} ({} bytes)".format(out_path, len(text.encode("utf-8"))))
    print("  creature entries : {} ({}..{})".format(len(profiles), profiles[0]["entry"], profiles[-1]["entry"]))
    print("  spawn areas      : {}".format(len(AREAS)))
    print("  rotation steps   : {}".format(len(ROTATIONS)))


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "2026_10_13_00_playerbots.sql")
