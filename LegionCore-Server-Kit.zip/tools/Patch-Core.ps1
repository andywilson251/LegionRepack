<#
.SYNOPSIS
    Applies, reverts or checks the PlayerBots core patch. Pure PowerShell - no
    Python, no other tooling.

.DESCRIPTION
    Real player-bots need a WorldSession with no socket. WorldSession::Update
    ends with

        if (!m_Socket[CONNECTION_TYPE_REALM])
            return false;        // Will remove this session from the world session map

    and both callers - World::UpdateSessions and Map::Update - respond by
    calling LogoutPlayer(true) and erasing the session, so a socket-less bot
    would log itself out on the next tick.

    This adds an opt-in flag plus two login entry points, and makes that one
    condition respect the flag. A session without the flag behaves exactly as
    before.

    Idempotent: applying twice is a no-op, and Revert restores the original
    bytes from the .before-playerbots backups.

.PARAMETER Action
    Apply, Revert or Check.

.PARAMETER SourceDir
    Root of the LegionCore source tree, e.g. C:\LegionCore\source

.EXAMPLE
    .\Patch-Core.ps1 -Action Check  -SourceDir C:\LegionCore\source
    .\Patch-Core.ps1 -Action Apply  -SourceDir C:\LegionCore\source
    .\Patch-Core.ps1 -Action Revert -SourceDir C:\LegionCore\source
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][ValidateSet('Apply', 'Revert', 'Check')][string]$Action,
    [Parameter(Mandatory = $true)][string]$SourceDir
)

$ErrorActionPreference = 'Stop'

$HeaderRel = 'src\server\game\Server\WorldSession.h'
$SourceRel = 'src\server\game\Server\WorldSession.cpp'

$HdrAnchor = '        bool PlayerLoading() const { return !m_playerLoading.IsEmpty(); }'
$HdrAdd = @'

        // PlayerBots: a bot session owns no socket. Flagging it keeps
        // WorldSession::Update from treating the missing socket as a dropped
        // connection. Untouched for every normal session.
        bool IsBot() const { return _isBot; }
        void SetBot(bool on) { _isBot = on; }

        // PlayerBots: begin login for a bot character. The normal path is
        // driven by CMSG_PLAYER_LOGIN followed by the client reconnecting on
        // the instance socket; a bot has no client, so it sets the pending
        // guid and continues directly.
        void BotLogin(ObjectGuid guid) { m_playerLoading = guid; HandleContinuePlayerLogin(); }

        // PlayerBots: the client clears the loading state with the load-screen
        // packet. Without this a bot stays "logging in" forever.
        void BotFinishLogin() { m_playerLoading.Clear(); }
'@

# Full line including its trailing comment: anchoring on the prefix alone would
# insert mid-line and split that comment onto a line of its own.
$HdrFieldAnchor = '        bool m_playerLogout;                                // code processed in LogoutPlayer'
$HdrFieldAdd    = '        bool _isBot = false;                                // PlayerBots: socket-less bot session'

$CppOld = @'
        if (!m_Socket[CONNECTION_TYPE_REALM])
        {
            m_sUpdate = false;
            return false;                                       //Will remove this session from the world session map
        }
'@
$CppNew = @'
        // PlayerBots: a bot session legitimately has no socket, so an absent
        // one must not be read as a dropped connection.
        if (!m_Socket[CONNECTION_TYPE_REALM] && !IsBot())
        {
            m_sUpdate = false;
            return false;                                       //Will remove this session from the world session map
        }
'@

function Get-Paths {
    param([string]$Root)
    [PSCustomObject]@{
        Header = (Join-Path $Root $HeaderRel)
        Source = (Join-Path $Root $SourceRel)
    }
}

# Read raw bytes as text without letting PowerShell rewrite line endings.
function Read-Text {
    param([string]$Path)
    [System.IO.File]::ReadAllText($Path)
}

function Write-Text {
    param([string]$Path, [string]$Text)
    # No BOM: these are existing C++ files and must stay byte-comparable.
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Text, $utf8NoBom)
}

function Get-PatchState {
    param([string]$Root)
    $p = Get-Paths $Root
    foreach ($f in @($p.Header, $p.Source)) {
        if (-not (Test-Path -LiteralPath $f)) { return @{ State = 'missing'; Why = "$f not found" } }
    }
    $h = Read-Text $p.Header
    $c = Read-Text $p.Source
    $hp = $h.Contains('bool IsBot() const')
    $cp = $c.Contains('!IsBot()')
    if ($hp -and $cp)       { return @{ State = 'applied'; Why = 'both files carry the patch' } }
    if (-not $hp -and -not $cp) { return @{ State = 'clean'; Why = 'neither file is patched' } }
    return @{ State = 'partial'; Why = "header patched=$hp, source patched=$cp" }
}

function Invoke-Apply {
    param([string]$Root)
    $st = Get-PatchState $Root
    switch ($st.State) {
        'applied' { Write-Host "[ok] already applied ($($st.Why))"; return 0 }
        'missing' { Write-Host "[xx] $($st.Why)"; return 1 }
        'partial' {
            Write-Host "[xx] refusing to touch a half-patched tree: $($st.Why)"
            Write-Host "     restore the .before-playerbots backups, or re-extract the core source"
            return 1
        }
    }

    $p = Get-Paths $Root
    foreach ($f in @($p.Header, $p.Source)) {
        $backup = "$f.before-playerbots"
        if (-not (Test-Path -LiteralPath $backup)) { Copy-Item -LiteralPath $f -Destination $backup -Force }
    }

    $h = Read-Text $p.Header
    if (-not $h.Contains($HdrAnchor)) {
        Write-Host '[xx] header anchor not found - core version differs from the one this patch targets'
        return 1
    }
    # Match whatever the file already uses, so a CRLF checkout stays CRLF.
    $nl = if ($h.Contains("`r`n")) { "`r`n" } else { "`n" }
    $hdrAddNl = ($HdrAdd -replace "`r`n", "`n") -replace "`n", $nl
    $idx = $h.IndexOf($HdrAnchor)
    $h = $h.Substring(0, $idx + $HdrAnchor.Length) + $nl + $hdrAddNl + $nl + $h.Substring($idx + $HdrAnchor.Length)

    if (-not $h.Contains($HdrFieldAnchor)) {
        Write-Host '[xx] header field anchor not found'
        return 1
    }
    $idx = $h.IndexOf($HdrFieldAnchor)
    $h = $h.Substring(0, $idx + $HdrFieldAnchor.Length) + $nl + $HdrFieldAdd + $nl + $h.Substring($idx + $HdrFieldAnchor.Length)
    Write-Text $p.Header $h

    $c = Read-Text $p.Source
    # Match whichever line ending the file actually uses.
    $oldLf   = $CppOld -replace "`r`n", "`n"
    $oldCrLf = $oldLf  -replace "`n", "`r`n"
    $newLf   = $CppNew -replace "`r`n", "`n"
    $newCrLf = $newLf  -replace "`n", "`r`n"

    if ($c.Contains("`r`n") -and $c.Contains($oldCrLf)) { $c = $c.Replace($oldCrLf, $newCrLf) }
    elseif ($c.Contains($oldLf))                        { $c = $c.Replace($oldLf, $newLf) }
    else {
        Write-Host '[xx] source anchor not found - core version differs from the one this patch targets'
        return 1
    }
    Write-Text $p.Source $c

    Write-Host "[ok] patched WorldSession.h"
    Write-Host "[ok] patched WorldSession.cpp"
    Write-Host "     backups: *.before-playerbots"
    return 0
}

function Invoke-Revert {
    param([string]$Root)
    $p = Get-Paths $Root
    $done = 0
    foreach ($f in @($p.Header, $p.Source)) {
        $backup = "$f.before-playerbots"
        if (Test-Path -LiteralPath $backup) {
            Copy-Item -LiteralPath $backup -Destination $f -Force
            Remove-Item -LiteralPath $backup -Force
            Write-Host "[ok] restored $(Split-Path -Leaf $f)"
            $done++
        }
        else {
            Write-Host "[!!] no backup for $(Split-Path -Leaf $f), left as is"
        }
    }
    if ($done -gt 0) { return 0 } else { return 1 }
}

switch ($Action) {
    'Check'  { $st = Get-PatchState $SourceDir; Write-Host "$($st.State): $($st.Why)"; exit 0 }
    'Apply'  { exit (Invoke-Apply  $SourceDir) }
    'Revert' { exit (Invoke-Revert $SourceDir) }
}
