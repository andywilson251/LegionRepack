#!/usr/bin/env bash
# Rebuilds the Linux/GCC compile harness used by verify-playerbots.sh.
# It is a cross-check of code destined for Windows/MSVC, not a substitute for it.
set -u
CORE=${CORE:-/home/user/core-repo}
GEN=${GEN:-/tmp/botgen}
mkdir -p "$GEN" /tmp/botobj

# Test for a real source file, not .git: a bare directory is not a checkout
# (verify-playerbots.sh creates $CORE/src/.../PlayerBots), and .git does not
# survive workspace snapshots.
if [ ! -f "$CORE/src/server/game/Entities/Creature/Creature.h" ]; then
    echo "cloning the core at the commit the module was written against"
    git clone --quiet https://github.com/The-Legion-Preservation-Project/LegionCore-7.3.5.git "$CORE"
    git -C "$CORE" checkout --quiet fed58f79c498521836612acd12009e9fa9e60e31
fi

# Every directory holding a header, plus its parent so "fmt/printf.h" style
# includes resolve. Core sources must come BEFORE dep/, because
# dep/CascLib/src/common/Common.h otherwise shadows src/common/Common.h.
# dep/rapidjson/rapidjson/msinttypes is excluded: it hijacks <stdint.h> with an
# MSVC-only #error.
cd "$CORE"
find src dep -type f \( -name '*.h' -o -name '*.hpp' \) -printf '%h\n' 2>/dev/null | sort -u > "$GEN/dirs.tmp"
{ cat "$GEN/dirs.tmp"; xargs -n1 dirname < "$GEN/dirs.tmp" | sort -u; } | sort -u \
  | grep -v 'msinttypes' | sed "s|^|-I$CORE/|" > "$GEN/all.tmp"
{ grep '/src/' "$GEN/all.tmp" | grep -v '/dep/'
  grep '/dep/' "$GEN/all.tmp" | grep -v 'CascLib/src/common$'
} > "$GEN/incs.txt"
rm -f "$GEN/dirs.tmp" "$GEN/all.tmp"
echo "include dirs: $(wc -l < "$GEN/incs.txt")"

cat > "$GEN/revision_data.h" <<'EOF'
#ifndef __REVISION_DATA_H__
#define __REVISION_DATA_H__
#define _HASH            "fed58f79"
#define _DATE            "2025-04-19"
#define _BRANCH          "master"
#define _SOURCE_DIRECTORY "."
#define _MYSQL_EXECUTABLE "/usr/bin/mysql"
#define _FULL_DATABASE   "LegionCore_full.sql"
#define VER_COMPANYNAME_STR    "LegionCore"
#define VER_LEGALCOPYRIGHT_STR "GPL"
#define VER_FILEVERSION        0,0,0,0
#define VER_FILEVERSION_STR    "fed58f79"
#define VER_PRODUCTVERSION     VER_FILEVERSION
#define VER_PRODUCTVERSION_STR VER_FILEVERSION_STR
#endif
EOF

# <windows.h> defines these as empty macros on every MSVC build and NOMINMAX
# does not suppress them. Force-including this on GCC reproduces the class of
# failure that produced error C2513 ("no variable declared before '='").
cat > "$GEN/winmacros.h" <<'EOF'
#ifndef WINMACROS_EMULATION_H
#define WINMACROS_EMULATION_H
#define near
#define far
#define pascal
#endif
EOF
echo "harness ready in $GEN"

# --- real world-data extracts used by the SQL and display-ID checks ---
# creature_model_info + creature_template_wdb + creature_template, pulled from
# the official release dump so the checks run against the data the user has.
DUMP=${DUMP:-/home/user/release/LegionCore_full.7z}
mkdir -p /tmp/dumps /tmp/wdbtest
if [ -f "$DUMP" ] && [ ! -s /tmp/dumps/ctw.sql ]; then
    # awk appends with >>, so clear any partial extract first or a re-run
    # doubles the file and every INSERT fails on a duplicate key.
    rm -f /tmp/dumps/*.sql
    7z e -so "$DUMP" LegionCore_world_735.26972_2024_10_23.sql 2>/dev/null | awk '
      /^DROP TABLE IF EXISTS `creature_model_info`/   {t="/tmp/dumps/cmi.sql"; next}
      /^DROP TABLE IF EXISTS `creature_template_wdb`/ {t="/tmp/dumps/ctw.sql"; next}
      /^DROP TABLE IF EXISTS `creature_template`;/    {t="/tmp/dumps/ct.sql";  next}
      /^DROP TABLE IF EXISTS `playercreateinfo`;/     {t="/tmp/dumps/pci.sql"; next}
      /^DROP TABLE IF EXISTS/ {t=""}
      t!="" {print >> t}'
    echo "world-data extracts: $(wc -c < /tmp/dumps/ctw.sql) bytes of creature_template_wdb"
    echo "                     $(wc -c < /tmp/dumps/pci.sql) bytes of playercreateinfo"
fi
# schema-only copies for the SQL group
for t in creature_template creature_template_wdb updates updates_include; do
    out=$t.sql; [ "$t" = creature_template ] && out=ct.sql; [ "$t" = creature_template_wdb ] && out=ctw.sql
    if [ ! -s "/tmp/wdbtest/$out" ] && [ -f "$DUMP" ]; then
        7z e -so "$DUMP" LegionCore_world_735.26972_2024_10_23.sql 2>/dev/null |
          awk -v T="$t" 'BEGIN{p=0} $0 ~ "^CREATE TABLE `"T"`"{p=1} p{print} p && /ENGINE=/{exit}' > "/tmp/wdbtest/$out"
    fi
done
echo "harness data ready"
