<#
.SYNOPSIS
    Installs the PlayerBots module into your LegionCore source tree, world
    database and worldserver.conf.

.DESCRIPTION
    Four things happen, all of them safe to repeat:

      1. the module sources are copied into
         <source>\src\server\scripts\Custom\PlayerBots\
      2. one line is added to <source>\src\server\scripts\Custom\custom_script_loader.cpp
         so the core registers the scripts
      3. the world database gets the bot tables and data
         (creature entries 800000-800999, playerbot_profile/area/rotation)
      4. the PlayerBots block is appended to worldserver.conf if it is not there

    After this you still have to REBUILD (2-Build-Core.ps1) and restart, because
    the module is C++ inside worldserver.exe.

.PARAMETER DryRun
    Show what would be done and change nothing.

.PARAMETER SkipSql
    Do not touch the database (sources and config only).

.PARAMETER SkipSource
    Do not touch the source tree (database and config only).

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\7-Install-PlayerBots.ps1
.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\7-Install-PlayerBots.ps1 -DryRun
#>

[CmdletBinding()]
param(
    [switch]$DryRun,
    [switch]$SkipSql,
    [switch]$SkipSource,
    [switch]$NoCorePatch,        # skip the WorldSession patch real player-bots need
    [switch]$RevertCorePatch     # undo it and exit
)

$ErrorActionPreference = 'Stop'

$InstallerVersion = '2.1 (2026-10-13)'   # 2.0 real bots, 2.1 legal race/class pairs + 12-char names

. (Join-Path $PSScriptRoot 'kit-config.ps1')
. (Join-Path $PSScriptRoot 'tools\MySql-Client.ps1')
. (Join-Path $PSScriptRoot 'tools\Sql-Updates.ps1')

# If the kit was merged rather than replaced, some files can be old and some new.
# Say so plainly instead of failing later with "term is not recognized".
foreach ($needed in 'Invoke-LegionMySql', 'Get-LegionSqlUpdateHash') {
    if (-not (Get-Command $needed -ErrorAction SilentlyContinue)) {
        Write-Host ''
        Write-Host "  [xx] This kit folder has mismatched files: $needed is missing." -ForegroundColor Red
        Write-Host "       $PSScriptRoot\tools still holds an older copy."
        Write-Host "       Delete that folder and extract the new kit fresh, rather than"
        Write-Host "       merging it over the top."
        exit 1
    }
}

function Find-MySqlClient {
    $cand = @(
        (Join-Path $MySqlRoot 'bin\mysql.exe'),
        "$env:ProgramFiles\MySQL\MySQL Server 8.0\bin\mysql.exe",
        "$env:ProgramFiles\MySQL\MySQL Server 8.4\bin\mysql.exe",
        "${env:ProgramFiles(x86)}\MySQL\MySQL Server 8.0\bin\mysql.exe"
    )
    foreach ($c in $cand) { if ($c -and (Test-Path $c)) { return $c } }
    foreach ($n in 'mysql.exe', 'mysql', 'mariadb') {
        $g = Get-Command $n -ErrorAction SilentlyContinue
        if ($g) { return $g.Source }
    }
    return $null
}

function Invoke-MySqlQuery {
    param([string]$Query, [string]$Database = '')
    $result = Invoke-LegionMySql -Executable $script:MySqlExe -HostName $MySqlHost -Port $MySqlPort `
        -User $MySqlUser -Password $MySqlPass -Query $Query -Database $Database
    if ($result.ExitCode -ne 0) { throw "MySQL query failed (exit $($result.ExitCode)).`n$($result.StdErr)" }
    return $result.StdOut
}

function Import-MySqlFile {
    param([string]$Path, [string]$Database = '')
    $result = Invoke-LegionMySql -Executable $script:MySqlExe -HostName $MySqlHost -Port $MySqlPort `
        -User $MySqlUser -Password $MySqlPass -InputFile $Path -Database $Database
    if ($result.ExitCode -ne 0) { throw "Applying $(Split-Path -Leaf $Path) failed (exit $($result.ExitCode)).`n$($result.StdErr)" }
    return $result.StdErr
}

function Info($m) { Write-Host "  $m" }
function Ok($m)   { Write-Host "  [ok] $m"   -ForegroundColor Green }
function Warn($m) { Write-Host "  [!!] $m"   -ForegroundColor Yellow }
function Die($m)  { Write-Host ""; Write-Host "  [xx] $m" -ForegroundColor Red; Write-Host ""; exit 1 }

Write-Host ""
Write-Host "  LegionCore - install PlayerBots   (installer v$InstallerVersion)" -ForegroundColor Cyan
$wsHeaderFinal = Join-Path $SourceDir 'src\server\game\Server\WorldSession.h'
$corePatched = (Test-Path $wsHeaderFinal) -and (Select-String -LiteralPath $wsHeaderFinal -Pattern 'void SetBot' -Quiet)
Write-Host "  ------------------------------------------------------------"
if ($corePatched) { Ok   "core patch: APPLIED - real player-bots available after a rebuild" }
else              { Warn "core patch: NOT APPLIED - .bots player will be unavailable" }
if ($DryRun) { Warn "DRY RUN - nothing will be changed" }

$moduleSrc = Join-Path $PSScriptRoot 'module\PlayerBots'
$sqlSrc    = Join-Path $PSScriptRoot 'sql\custom\world\2026_10_13_00_playerbots.sql'

if (-not (Test-Path $moduleSrc)) { Die "Module sources are missing: $moduleSrc" }
if (-not (Test-Path $sqlSrc))    { Die "Module SQL is missing: $sqlSrc" }

# ---------------------------------------------------------------- 1. sources
if (-not $SkipSource) {
    Write-Host ""
    Write-Host "  1. source tree" -ForegroundColor Cyan

    if (-not (Test-Path $SourceDir)) {
        Die "Source tree not found at $SourceDir. Run 2-Build-Core.ps1 first, or fix `$SourceDir in kit-config.ps1."
    }

    $customDir = Join-Path $SourceDir 'src\server\scripts\Custom'
    if (-not (Test-Path $customDir)) {
        Die "This does not look like a LegionCore checkout - $customDir is missing."
    }

    $targetDir = Join-Path $customDir 'PlayerBots'
    $moduleFileCount = @(Get-ChildItem -Path $moduleSrc -Include *.h,*.cpp -File -Recurse).Count
    Info "copying $moduleFileCount files to $targetDir"
    if (-not $DryRun) {
        New-Item -ItemType Directory -Force -Path $targetDir | Out-Null
        Copy-Item (Join-Path $moduleSrc '*.h')   $targetDir -Force
        Copy-Item (Join-Path $moduleSrc '*.cpp') $targetDir -Force
    }
    Ok "module sources in place"

    # ---- the single line the core needs ----
    $loader = Join-Path $customDir 'custom_script_loader.cpp'
    if (-not (Test-Path $loader)) {
        Die "Expected $loader to exist. Is this the right source tree?"
    }

    $text = Get-Content -LiteralPath $loader -Raw
    if ($text -match 'AddSC_playerbots') {
        Ok "custom_script_loader.cpp already registers the module"
    }
    else {
        if ($text -notmatch 'void\s+AddCustomScripts\s*\(\s*\)') {
            Die "custom_script_loader.cpp does not contain AddCustomScripts() - refusing to edit it blindly."
        }

        $backup = "$loader.before-playerbots"
        Info "editing custom_script_loader.cpp (backup: $(Split-Path -Leaf $backup))"

        # declaration above the function, call inside it
        $patched = $text -replace '(?m)^(void\s+AddCustomScripts\s*\(\s*\))', "void AddSC_playerbots();`r`n`r`n`$1"
        $patched = $patched -replace '(?m)^(\s*)(AddSC_solocraft\s*\(\s*\)\s*;)', "`$1`$2`r`n`$1AddSC_playerbots();"

        if ($patched -notmatch 'AddSC_playerbots\(\);') {
            # no solocraft line to anchor to: add the call right after the opening brace
            $patched = $patched -replace '(?s)(void\s+AddCustomScripts\s*\(\s*\)\s*\{)', "`$1`r`n    AddSC_playerbots();"
        }

        if ($patched -notmatch 'AddSC_playerbots\(\);') {
            Die "Could not work out where to add AddSC_playerbots() - add it to AddCustomScripts() by hand."
        }

        if (-not $DryRun) {
            Copy-Item $loader $backup -Force
            Set-Content -LiteralPath $loader -Value $patched -NoNewline -Encoding UTF8
        }
        Ok "module registered in the script loader"
    }

    # ---- keep a copy of the sql with the source, like the core's own updates ----
    $sqlDir = Join-Path $SourceDir 'sql\custom\world'
    Info "copying the module SQL to $sqlDir"
    if (-not $DryRun) {
        New-Item -ItemType Directory -Force -Path $sqlDir | Out-Null
        Copy-Item $sqlSrc $sqlDir -Force
    }
    Ok "SQL filed with the source tree"
}

# --------------------------------------------------------------- 2. database
if (-not $SkipSql) {
    Write-Host ""
    Write-Host "  2. world database" -ForegroundColor Cyan

    $script:MySqlExe = Find-MySqlClient
    if (-not $script:MySqlExe) {
        Die ("mysql client not found. Install MySQL 8.0 (1-Install-Prerequisites.ps1)`n" +
             "       or set `$MySqlRoot in kit-config.ps1.")
    }
    Info "client: $script:MySqlExe"

    try {
        $tableCount = (Invoke-MySqlQuery -Query "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='world';").Trim()
    }
    catch {
        Die ("Cannot reach MySQL at ${MySqlHost}:${MySqlPort} as '$MySqlUser'.`n" +
             "       Is the service running, and is `$MySqlPass correct in kit-config.ps1?`n       $_")
    }
    if ([int]$tableCount -eq 0) {
        Die "The 'world' database is empty or missing. Run 3-Setup-Databases.ps1 first."
    }
    Info "world database reachable ($tableCount tables)"

    if ($DryRun) {
        Warn "dry run: not applying $(Split-Path -Leaf $sqlSrc)"
    }
    else {
        $warnings = Import-MySqlFile -Path $sqlSrc -Database 'world'
        if ($warnings) {
            foreach ($line in ($warnings -split "`r?`n")) {
                if ($line.Trim() -and $line -notmatch 'Using a password') { Warn $line.Trim() }
            }
        }

        $counts = (Invoke-MySqlQuery -Database 'world' -Query @"
SELECT CONCAT(
  (SELECT COUNT(*) FROM creature_template WHERE entry BETWEEN 800000 AND 800999), ' creatures, ',
  (SELECT COUNT(*) FROM playerbot_profile),  ' profiles, ',
  (SELECT COUNT(*) FROM playerbot_area),     ' areas, ',
  (SELECT COUNT(*) FROM playerbot_rotation), ' rotation steps');
"@).Trim()
        Ok "applied: $counts"

        # Tell the auto-updater this file is already applied, using the hash the
        # core itself computes, so it never re-runs it after a git pull.
        $sqlInTree = Join-Path $SourceDir 'sql\custom\world\2026_10_13_00_playerbots.sql'
        if (Test-Path $sqlInTree) {
            $hash = Get-LegionSqlUpdateHash -Path $sqlInTree
            $name = Split-Path -Leaf $sqlInTree
            Invoke-MySqlQuery -Database 'world' -Query @"
INSERT INTO updates_include (path, state)
  SELECT '`$/sql/custom/world', 'RELEASED' FROM DUAL
  WHERE NOT EXISTS (SELECT 1 FROM updates_include WHERE path = '`$/sql/custom/world');
REPLACE INTO updates (name, hash, state, timestamp, speed)
  VALUES ('$name', '$hash', 'RELEASED', NOW(), 0);
"@ | Out-Null
            Ok "recorded in world.updates (hash $($hash.Substring(0,7))) - the updater will leave it alone"
        }
    }
}

# ------------------------------------------------------- 3. core source patch
Write-Host ""
Write-Host "  3. core patch (WorldSession)" -ForegroundColor Cyan

$patchPs = Join-Path $PSScriptRoot 'tools\Patch-Core.ps1'

if ($RevertCorePatch) {
    if (-not (Test-Path $patchPs)) { Die "tools\Patch-Core.ps1 is missing from this kit." }
    & $patchPs -Action Revert -SourceDir $SourceDir
    Ok "core patch reverted - rebuild with 2-Build-Core.ps1 to return to stock behaviour"
    exit 0
}

if ($NoCorePatch) {
    Warn "skipped on request (-NoCorePatch). Creature-backed bots still work;"
    Warn "real player-bots need this patch, because a session with no socket is"
    Warn "otherwise logged out on the next world tick."
}
elseif (-not (Test-Path $patchPs)) {
    Warn "tools\Patch-Core.ps1 is missing from this kit - the core patch was not applied."
}
elseif ($DryRun) {
    & $patchPs -Action Check -SourceDir $SourceDir
    Info "dry run: no changes made"
}
else {
    $before = & $patchPs -Action Check -SourceDir $SourceDir
    Info "current state: $before"
    & $patchPs -Action Apply -SourceDir $SourceDir

    # Trust nothing: confirm the marker is actually in the file on disk.
    $wsHeader = Join-Path $SourceDir 'src\server\game\Server\WorldSession.h'
    if ((Test-Path $wsHeader) -and (Select-String -LiteralPath $wsHeader -Pattern 'void SetBot' -Quiet)) {
        Ok "WorldSession patched and verified (backups: *.before-playerbots)"
        Info "this changes core source, so 2-Build-Core.ps1 must be run before the change takes effect"
    }
    else {
        Write-Host ""
        Warn "================= CORE PATCH NOT APPLIED ================="
        Warn "SetBot is not present in:"
        Warn "  $wsHeader"
        Warn ""
        Warn "The build will still succeed and creature-backed bots still work,"
        Warn "but .bots player will report the patch as missing."
        Warn "See docs/TROUBLESHOOTING.md section 23 for the manual edit."
        Warn "=========================================================="
        Write-Host ""
    }
}

# ----------------------------------------------------------------- 3. config
Write-Host ""
Write-Host "  4. worldserver.conf" -ForegroundColor Cyan

# The rest of the kit treats $ServerDir\worldserver.conf as the live config:
# 2-Build-Core.ps1 seeds it there, Repair-Update-Hashes.ps1 reads it from there,
# and 4-Start-Server.bat launches worldserver.exe with $ServerDir as its working
# directory. CMake's install step also drops copies under $ServerDir\etc, which
# the server does NOT read. Rather than assume, find every candidate and treat
# the ones holding a real WorldDatabaseInfo line as live.
$candidates = @(
    (Join-Path $ServerDir 'worldserver.conf'),
    (Join-Path $ServerDir 'etc\worldserver.conf')
) | Select-Object -Unique

$live = @()
foreach ($c in $candidates) {
    if (-not (Test-Path $c)) { continue }
    $text = Get-Content -LiteralPath $c -Raw
    if ($text -match '(?m)^\s*WorldDatabaseInfo\s*=') {
        $live += $c
    }
    else {
        Info "skipping $c (no WorldDatabaseInfo - not a live config)"
    }
}

if ($live.Count -eq 0) {
    Warn "No live worldserver.conf found under $ServerDir."
    Warn "Add module\PlayerBots\playerbots.conf.snippet to your worldserver.conf by hand."
}
else {
    foreach ($conf in $live) {
        $confText = Get-Content -LiteralPath $conf -Raw
        $snippet  = Get-Content -LiteralPath (Join-Path $moduleSrc 'playerbots.conf.snippet') -Raw

        # Which settings does the snippet define, and which are already live?
        # An all-or-nothing check on PlayerBots.Enable would skip the whole
        # block whenever the kit gains a NEW setting, so an upgraded kit would
        # never deliver it. Compare key by key instead.
        $wantKeys = [regex]::Matches($snippet, '(?m)^\s*(PlayerBots\.[A-Za-z0-9_.]+)\s*=') |
                    ForEach-Object { $_.Groups[1].Value }
        $haveKeys = [regex]::Matches($confText, '(?m)^\s*(PlayerBots\.[A-Za-z0-9_.]+)\s*=') |
                    ForEach-Object { $_.Groups[1].Value }
        $missing  = @($wantKeys | Where-Object { $haveKeys -notcontains $_ })

        if ($missing.Count -eq 0) {
            Ok "all $($wantKeys.Count) settings already present in $conf (your values were left alone)"
            continue
        }

        if ($haveKeys.Count -eq 0) {
            Info "appending the PlayerBots block to $conf"
            $toAppend = $snippet
        }
        else {
            Info "$($haveKeys.Count) of $($wantKeys.Count) settings already there; adding $($missing.Count) new one(s):"
            foreach ($m in $missing) { Info "    $m" }

            # Keep each new setting with the comment block that documents it.
            $blocks = $snippet -split "(\r?\n){2,}"
            $keep = @()
            foreach ($b in $blocks) {
                $key = [regex]::Match($b, '(?m)^\s*(PlayerBots\.[A-Za-z0-9_.]+)\s*=')
                if ($key.Success -and ($missing -contains $key.Groups[1].Value)) { $keep += $b.Trim() }
            }
            if ($keep.Count -eq 0) {
                # no recognisable blocks: fall back to bare assignments
                foreach ($m in $missing) {
                    $line = [regex]::Match($snippet, "(?m)^\s*$([regex]::Escape($m))\s*=.*$")
                    if ($line.Success) { $keep += $line.Value.Trim() }
                }
            }
            $toAppend = ($keep -join "`r`n`r`n")
        }

        if (-not $DryRun) {
            Copy-Item $conf "$conf.before-playerbots" -Force
            # Add-Content does not add a leading line break, and a config file
            # without a trailing newline would get its last line glued.
            $prefix = ''
            if ($confText.Length -gt 0 -and -not $confText.EndsWith("`n")) { $prefix = "`r`n" }
            Add-Content -LiteralPath $conf -Value ($prefix + "`r`n" + $toAppend)
        }
        Ok "config updated (backup: $(Split-Path -Leaf $conf).before-playerbots)"
    }

    # A block sitting in a file the server never reads is why PlayerBots can
    # report "disabled" after a successful install. Say so explicitly.
    $ignored = @($candidates | Where-Object { (Test-Path $_) -and ($live -notcontains $_) })
    foreach ($i in $ignored) {
        $t = Get-Content -LiteralPath $i -Raw
        if ($t -match '(?m)^\s*PlayerBots\.Enable') {
            Warn "$i also has a PlayerBots block but is not the live config - it has no effect."
        }
    }
    Info ("the server reads: " + ($live -join ', '))
}

# ------------------------------------------------------------------ summary
Write-Host ""
Write-Host "  ------------------------------------------------------------"
if ($DryRun) {
    Write-Host "  Dry run finished - nothing was changed." -ForegroundColor Yellow
}
else {
    Write-Host "  PlayerBots installed." -ForegroundColor Green
    Write-Host ""
    Write-Host "  Next, because the module is C++ inside worldserver.exe:"
    Write-Host ""
    Write-Host "     1.  .\4-Stop-Server.bat            (Windows locks a running exe)"
    Write-Host "     2.  .\2-Build-Core.ps1             (incremental - minutes, not an hour)"
    Write-Host "     3.  .\4-Start-Server.bat"
    Write-Host ""
    Write-Host "  Then in game, as GM:   .bots status     and    .bots spawn 20"
}
Write-Host ""
