# Test Report — LegionCore 7.3.5 Server Kit

**Subject:** `The-Legion-Preservation-Project/LegionCore-7.3.5`
@ commit `fed58f79c498521836612acd12009e9fa9e60e31` (2025-04-19)
**Test environment:** Linux sandbox (2 vCPU / 1.9 GB RAM), **MariaDB 11.8.6**,
PowerShell 7.4.6; follow-up tests also use Oracle MySQL 8.0.43 and CMake 3.31.6.
The kit itself targets Windows 10/11 + MySQL 8.0 + VS2022/MSVC.

---

## 1. Summary

| Area | Status | Evidence |
|---|---|---|
| Source inspection (build system, updater, tools, schema) | ✅ done | sections 2–5 |
| **All 4 databases created from scratch** | ✅ **executed & verified** | section 6 |
| **All SQL updates applied exactly like the core does** | ✅ **executed & verified** (48/48, 0 errors) | section 7 |
| **Update tracking rows (SHA1) accepted by the core** | ✅ **verified 81/81 hashes** | section 8 |
| **Account creation / password hash** | ✅ **verified against the project's own C++ code + shipped account** | section 9 |
| Kit PowerShell scripts (syntax + execution) | ✅ all 9 parse; DB + account scripts executed; native build runner tested | sections 6–10, 14–17 |
| Native CMake warning/arguments/build configuration repair | ✅ 13 test groups + real small CMake/C++ build on Linux; regression passed after static change | sections 17–18 (not Windows LegionCore) |
| Static-core tool targets | ✅ five actual source targets compile/link on Linux; 9 cache/install/probe groups | section 18 (not Windows) |
| Windows MSVC build / extractor run / live client login | ⚠️ user reports a partial Windows build; no Windows runtime or client test here | sections 11, 18 |

---

## 2. Release asset is the database source (no binaries)

The official release `LegionCore735.24101` provides a single asset
`LegionCore_full_735.26972_2024_10_23.7z` — **33,262,376 bytes**, SHA256
`CF681E1FB2E7443DAAB2A5DB04F4EFA2FC53CC485EA8DE6B6EC3D60D569C2696`.
Contents (verified by extraction):

| File | Size | SHA256 (verified after import) |
|---|---|---|
| `LegionCore_world_735.26972_2024_10_23.sql` | 237,409,451 B | `0265CC795B6507F8918162293E7C905143CDB2EF227EE72179BB43BCF889F68C` |
| `LegionCore_hotfixes_735.26972_2024_10_23.sql` | 30,880,355 B | `437EF854F35DFF7CB39CB34766769CEC1B113A00A5F513361D3A8FCC6E48A96F` |

There are **no pre-built executables** in the release → the server must be compiled
from source, which is what `2-Build-Core.ps1` automates.

The core itself never downloads these files; if they are missing it prints
*"File ... is missing, download it from .../releases ... and place the file in the
directory ..."* (`DBUpdater.cpp`). The kit downloads + SHA256-verifies + extracts them.

## 3. Build configuration verified against the project's own Windows CI

`2-Build-Core.ps1` uses the dependency layout and intended core flags from
`.github/workflows/build-win-x64.yml`; this is not a byte-for-byte copy of that workflow:

* Boost **1.84.0**, static, MSVC (vc143) — the exact archive the CI's
  `MarkusJx/install-boost` step downloads; URL returns HTTP 200 and the asset is
  **646,990,325 bytes** (verified against the GitHub API), containing
  `boost/include` + `boost/lib/libboost_*-vc143-mt[-gd]-x64-1_84.lib` + `lib/cmake`.
* OpenSSL **3.x x64** via the slproweb hash-manifest API (`arch=INTEL, bits=64,
  light=false, installer=exe`) — same source the CI uses.
* `MYSQL_ROOT_DIR`, `OPENSSL_ROOT_DIR`, `BOOST_ROOT` environment variables — the
  project's `cmake/macros/FindMySQL.cmake` and `dep/boost/CMakeLists.txt` read exactly
  these.
* Generator: Ninja + MSVC (VS2022, x64), `-DTOOLS=ON`, `RelWithDebInfo`,
  build output `build/bin/RelWithDebInfo`. The VS2022 x64 fallback explicitly
  builds `--config RelWithDebInfo` after the repair in section 17. Section 18 corrects
  the kit to the repository/CI default static scripts and static core libraries.
* Post-build DLL collection identical to CI: `libmysql.dll`, `libssl-3-x64.dll`,
  `libcrypto-3-x64.dll`, `legacy.dll` copied next to the exes.
* MySQL 8.0 ZIP: pinned to 8.0.43. The original redirect returned HTTP 200 here
  but later failed on the user's PC. The repaired direct archive and full download
  verification are documented in section 13 below.

Tools built by `-DTOOLS=ON` and their semantics (read from source, encoded in the kit):

| Tool | Verified usage |
|---|---|
| `mapextractor.exe` | `-i <client dir>` `-o <out dir>` (−e 1=map,2=dbc,4=camera,8=gt|11=all, `-f` float flag, `-l` locale); input dir is the client root, it appends `Data` |
| `vmap4extractor.exe` | `-d <client dir>`; **writes to `./Buildings` relative to the current working directory** |
| `vmap4assembler.exe` | `<raw dir> <dest dir>` (defaults `Buildings` → `vmaps`) |
| `mmaps_generator.exe` | runs in a folder containing `maps\` + `vmaps\`, creates `mmaps\`; `--threads`, `--tile`, `--file`, `--skipLiquid`, … |
| `connection_patcher.exe` | `<path to Wow.exe>` — patches the client to accept the server certificate |

## 4. Database architecture verified in source

* 4 databases: `auth`, `characters`, `world`, `hotfixes` — base files
  `sql/base/auth_database.sql`, `sql/base/characters_database.sql` (in repo) and the two
  release dumps (world/hotfixes).
* The updater reads include-paths **from each database** (`updates_include`):
  `$/sql/old/<db>` (ARCHIVED) + `$/sql/updates/<db>` (RELEASED); `$` = `SourceDirectory`
  from the conf. **All four base dumps already contain these rows** (verified by query).
* Files are applied in **byte order** (`std::string` comparison) and recorded in
  `updates(name, hash, state, speed)`; the hash is SHA1 in **uppercase, forward byte
  order** (`CalculateSHA1Hash` → `ByteArrayToHexStr`, verified 4/4 against hashes the
  project itself stored for `sql/old/world`).
* Orphan cleanup warning: entries recorded but missing on disk are deleted when
  ≤ `Updates.CleanDeadRefMaxCount` (default 3) → **the kit therefore ships the `sql/old`
  archived trees** so the core sees the complete history.
* `auth` schema has **no battlenet account tables** (this fork merged them):
  login is validated in `bnetserver` (`LoginRESTService`) by uppercasing the typed
  login+password and comparing `CalculateShaPassHash(...)` with `account.sha_pass_hash`.
  `account` row creation therefore needs only `username` + `sha_pass_hash`
  (`LOGIN_INS_ACCOUNT`).

## 5. Runtime output/tool facts used by the scripts

* Install target for the servers on Windows: `${CMAKE_INSTALL_PREFIX}` (exe + conf);
  tools land in `build/bin/RelWithDebInfo`.
* `worldserver.conf`: `DataDir = "C:/LegionCore/ClientData"`,
  `SourceDirectory = "C:/LegionCore/source"`,
  `MySQLExecutable = C:/libs/mysql-8.0/bin/mysql.exe`,
  `WorldServerPort = 8085`, DB strings `127.0.0.1;3306;root;admin;<db>`.
* `bnetserver.conf`: `LoginREST.Port = 8081`, `LoginDatabaseInfo` same style,
  `Updates.EnableDatabases = 0` (bnetserver never touches the databases).
* `bnetserver.cert.pem` / `bnetserver.key.pem` ship in `src/server/bnetserver/` and are
  installed next to the exe by `2-Build-Core.ps1` (verified by `-DTOOLS`-independent
  install rules).

---

## 6. Executed test — creating all four databases from scratch

Run through the **shipped** `3-Setup-Databases.ps1` (PowerShell 7.4.6 on Linux,
`-BaseDumpDir` pointing at the extracted dumps), against an empty server:

```
=== Creating databases (utf8mb4 / utf8mb4_unicode_ci)
  [ok] auth / characters / world / hotfixes (tables: 0)
=== Importing base data
  auth:        imported in  0.2s - tables:  34
  characters:  imported in  0.6s - tables: 146
  world:       imported in 41.5s - tables: 281   (226 MB SQL)
  hotfixes:    imported in  7.6s - tables: 813
=== Applying pending SQL updates
  auth: applied 3   characters: applied 2   world: applied 43   hotfixes: 0
  total updates applied this run: 48        (zero SQL errors)
=== Configuring the realmlist row
  realm: LegionCore | 127.0.0.1:8085 | build 26972
=== Creating / updating the admin account
  [ok] account 'GM@GM' (id 1) ready - password 'admin', gmlevel 6
=== Verification
  auth tables 22, characters tables 140, world tables 282, hotfixes tables 813
  no pending updates
  world.creature_template = 101838 | world.gameobject_template = 54968
  world.quest_template = 30317 | hotfixes.item = 1273
  RESULT: SUCCESS
```

*(Post-update table counts are lower than the fresh-import counts
34/146/281/813 because several updates intentionally drop unused tables.)*

**Idempotency:** a second run on the finished databases skipped all imports and
updates and finished with `RESULT: SUCCESS` in **7 s**, reporting `0 pending` for all
four databases.

The same end state was reproduced a second time from a completely empty server by an
independent shell harness (`tools/verify-databases.sh`), which reports
`ALL CHECKS PASSED [...] pending total: 0`.

## 7. Update-file sequencing — one real bug found and fixed

During the first executed run, `2024_11_17_creature_template_spell_difficulty_data.sql`
failed with `Unknown column 'Difficulties'` because PowerShell's culture-aware
`Sort-Object` ordered it **before** the file that adds the column
(`..._difficulty.sql`). The core sorts by raw byte order. The kit now sorts update files
with `[StringComparer]::Ordinal` (identical to the core) — after the fix all 43 world
updates applied in the correct order, `Difficulties` exists and `timerCast` is dropped.

## 8. Tracking rows accepted by the core (interoperability test)

After the fix, all tracking rows were compared independently (Python SHA1) against the
file contents:

* `world.updates` — 81 rows: **43/43 RELEASED** (from `sql/updates/world`) and
  **38/38 ARCHIVED** (from `sql/old/world`) carry **correct SHA1 hashes**;
* per-database totals: auth 6 (3+3), characters 9 (2+7), world 81 (43+38), hotfixes 4 (0+4).

Consequence: when the real `worldserver.exe` starts against this database, its updater
will match every hash and report *"database is up-to-date"* without re-applying anything.

## 9. Account password hash — verified three ways

The login path (`bnetserver/LoginRESTService.cpp` + `AccountMgr::CalculateShaPassHash`)
was reproduced and verified:

1. **Ground truth from the project's own code:** the repo's `SHA256.cpp` +
   `ByteArrayToHexStr` + `CalculateShaPassHash` were compiled and run
   (`g++`), producing reference hashes; the Python and **PowerShell** implementations
   match them exactly (4/4 test vectors).
2. **Known-answer test against real data:** the `GM@GM` account row shipped in
   `auth_database.sql` (`sha_pass_hash = 586EF64D...BAA492`) corresponds to password
   **`ADMIN`** (i.e. log in with `GM@GM` / `admin`) — found by hashing candidates with
   the verified algorithm.
3. **End-to-end:** `6-Create-Account.ps1 -Login TESTPLAYER@REALM -Password Test123`
   wrote a row whose hash matched an independent Python computation, with
   `account_access` (gmlevel 2, RealmID −1) correctly set.

## 10. Kit script validation

* All 6 PowerShell files parse cleanly (PowerShell AST parser).
* `3-Setup-Databases.ps1` — executed from scratch **and** re-run (idempotency).
* `6-Create-Account.ps1` — executed, result verified in the database.
* `1-…`, `2-…`, `5-…` — syntax-checked; all external URLs they use were verified
  (HTTP 200 / correct sizes) as listed in section 3.

## 11. Not verified here (and why)

| Item | Reason |
|---|---|
| MSVC/Ninja build on Windows | no Windows machine in this environment. Mitigation: intended dependencies/core flags/DLL collection follow the project's Windows CI; the corrected runner/argument logic is tested in section 17. This does not establish Windows build success. |
| MySQL 8.0 zip install & service creation | Windows-only. URL verified; commands are the documented Oracle zip deployment (`--initialize-insecure`, `--install`). |
| `5-Extract-Client-Data.ps1` execution | requires a WoW 7.3.5 build 26972 client (not present, and not distributable). Tool syntax and working-directory behaviour were verified from source. |
| Live `worldserver.exe` startup / client login | requires the Windows binaries + client data + client. |

The database outcomes above were produced on MariaDB 11.8.6. The dumps were generated
by `mysqldump 8.0.37` against server 8.4.3 and use only standard syntax and the
`utf8mb4_unicode_ci` collation, so MySQL 8.0 (which the kit installs) is the native,
closest-to-verified environment.

## 12. How to reproduce the database verification on your PC

```powershell
# after 3-Setup-Databases.ps1 has run once:
powershell -ExecutionPolicy Bypass -File .\3-Setup-Databases.ps1
#   -> should skip all imports, report "0 pending" and RESULT: SUCCESS in seconds

# optional, independent check (Git Bash or WSL):
bash tools/verify-databases.sh C:/LegionCore/source
#   -> "[4/4] Pending updates remaining ... pending total: 0"
#   -> "RESULT: ALL CHECKS PASSED - databases are ready for worldserver.exe"
```


## 13. MySQL download repair — 2026-10-11

**User-reported failure:** Windows PowerShell `Invoke-WebRequest` received Oracle's
"Technical Difficulties" HTML page while downloading the MySQL ZIP in step 1.
This was before MySQL extraction, initialization, service installation or database import.

**Repair:** `1-Install-Prerequisites.ps1` now recognizes the original configured
redirect and selects the direct official archive URL first, with an official archive
redirect fallback. It verifies size and SHA256, uses a temporary `.download` file,
discards invalid cached ZIPs, retries failed requests, and provides `-MySqlZipPath`
for a browser-downloaded ZIP. Defaults in the script support the **original**
`kit-config.ps1`, so the user's edited settings need not be replaced. Extraction uses
an isolated staging directory, verifies required files, and will not delete an existing
MySQL data/config directory to repair missing binaries. No database SQL was changed.

### Full official archive verification (executed)

- URL: `https://cdn.mysql.com/archives/mysql-8.0/mysql-8.0.43-winx64.zip`
- HTTP 200, `application/zip`; **244,242,563 bytes** (233 MiB).
- SHA256 computed from the complete HTTPS download:
  `745B4A9535992705AC43A5645B84D213A579C8FD866D1B5DCE8D6EE5A2FC7728`.
- MD5 `823a523ec2da41a06830b90b17852b90` matches Oracle's published
  `mysql-8.0.43-winx64.zip.md5` file.
- Every ZIP member passed CRC verification; verified archive paths include
  `bin/mysqld.exe`, `bin/mysql.exe`, `include/mysql.h`, `lib/libmysql.lib`,
  and `lib/libmysql.dll` below the expected `mysql-8.0.43-winx64` directory.
- The **actual download function extracted from the repaired script** completed a
  second live download using PowerShell 7.4.6 and matched the pinned size and SHA256.

### Recovery/extraction tests (executed, 14 scenario groups passed)

1. Backward compatibility with the **original** configuration taken from the original kit ZIP.
2. Pinned size/SHA256 validation against the real complete Oracle archive.
3. Live download using the actual repaired PowerShell download function.
4. Valid cache skips network requests.
5. Invalid HTML/partial cache is discarded; an interrupted request is retried and cleaned up.
6. Fallback URL is tried after the primary's two failed attempts.
7. A same-size file with the wrong SHA256 is rejected before caching.
8. Exhausted retries leave no partial/cache file and provide manual-recovery instructions.
9. A local ZIP path containing spaces bypasses network and is preserved.
10. Invalid local ZIP is rejected without modification.
11. Isolated extraction checks required files and replaces the original redirect URL.
12. Existing MySQL binaries skip extraction and downloads.
13. A ZIP missing a required file does not replace the target; staging is cleaned up.
14. Existing database data/config protection prevents destructive replacement.

Recovery failures were simulated deterministically; extraction tests used tiny synthetic
ZIPs containing placeholder files. **No downloaded Windows executable was run.**
All 6 PowerShell files again passed AST parsing. Windows PowerShell 5.1, MySQL
initialization/service setup, the Windows core build and live client login remain
unexecuted in this Linux environment; the download repair is not a claim of full
Windows/server verification.


## 14. Native MySQL warning / Windows PowerShell repair — 2026-10-11

**User report:** step 1 surfaced MySQL's command-line-password security notice as a
PowerShell `NativeCommandError` at the readiness probe. The original three direct client
calls redirected/captured native stderr under `$ErrorActionPreference = 'Stop'`.
That can abort Windows PowerShell 5.1 before the installer completes; the warning
itself does not damage the database or determine the client's actual exit code.

### Implementation changes

- Shared `tools/MySql-Client.ps1` uses `System.Diagnostics.Process`, separate async
  stdout/stderr reads and the actual exit code. It does not change global error handling.
- A private temporary option file holds the connection credentials; no command-line
  password or SQL query is used. Files are UTF-8 without BOM, quoted/escaped, and
  removed in `finally`. The Windows path sets current-user/SYSTEM-only inherited ACLs
  before writing credentials and fails closed if this cannot be done. Unix tests use
  directory/file modes 700/600. Windows ACL execution is **not tested here**.
- SQL queries are UTF-8 input; dump files are streamed in 64 KiB chunks, not loaded as
  a complete string. Both output pipes are drained concurrently to avoid deadlock.
- Step 1 verifies existing configured root credentials before trying initial empty
  credentials, retries startup connection failures, bootstraps only a passwordless
  initial root account, and requires a final successful `SELECT 1`. Wrong credentials
  or real setup errors no longer lead to a misleading success summary.
- Steps 3 and 6 use the shared transport, preventing warnings from polluting numeric
  table counts/account IDs. SQL sources, account-hash logic and kit configuration
  were unchanged; their byte contents were checked against the pre-repair full ZIP.
- The existing Oracle ZIP-download repair is retained.

### Executed fixture tests — 13 groups passed

1. Native stderr warning + exit 0 succeeds under strict PowerShell error handling.
2. Native nonzero exit/access-denied diagnostics are retained.
3. UTF-8 option/password escaping, native argument quoting, no command-line secrets,
   private Unix permissions and temporary-file cleanup.
4. Concurrent 1 MiB stdout + 1 MiB stderr completes without deadlock.
5. An input-file path with spaces is streamed byte-for-byte (SHA256 checked).
6. An early client exit/broken stdin pipe retains the real exit code/diagnostic.
7. Missing executable/input-file failures leave no temporary credentials behind.
8. Actual step 3 query/import functions accept warnings but reject real errors.
9. Actual step 6 query function returns only stdout and rejects real errors.
10. Existing-root bootstrap rerun does not modify working credentials.
11. Initial empty-password root is configured and re-verified.
12. Root readiness retries simulated temporary connection failures.
13. Wrong root credentials abort clearly without account reset or false success.

These deterministic fixtures execute a test-only native Python program, **not a Windows
MySQL binary**. They were run on PowerShell 7.4.6 on Linux.

### Executed live database tests — MariaDB 11.8.6 / PowerShell 7.4.6 on Linux

A separate, freshly initialized database server was started on loopback for these tests.
The actual native MariaDB client was used by the repaired transport:

- Empty-root TCP login succeeded; the **actual step 1 bootstrap subsection** configured
  root, created/granted the loopback root account, and re-verified `SELECT 1`.
- A bootstrap rerun verified the configured credentials without resetting them.
- A test account authenticated with a password containing quotes, backslashes,
  spaces, `#` and UTF-8 characters through the protected option file.
- A streamed SQL import of 2,500 rows succeeded; row count and UTF-8 text matched.
- Wrong passwords and invalid SQL returned nonzero exits and the proper diagnostics.

The repaired **complete step 3 script** was then executed against empty `auth`,
`characters`, `world` and `hotfixes` databases, using the verified official base dumps:

| Database | Base import | Final tables | Tracking rows |
|---|---:|---:|---:|
| auth | 0.3 s | 22 | 6 |
| characters | 0.8 s | 140 | 9 |
| world | 41.2 s | 282 | 81 |
| hotfixes | 7.4 s | 813 | 4 |

- 48 updates applied, 0 SQL errors; `RESULT: SUCCESS` (whole tool run about 75 s).
- A complete rerun skipped populated bases and reported **0 pending / 0 applied**,
  with `RESULT: SUCCESS` again.
- Creature templates 101,838; gameobject templates 54,968; quest templates 30,317;
  hotfix items 1,273 — identical to the pre-repair verified state.
- Independent Python audit verified **100/100** stored SHA1 values against the kit's
  SQL files (auth 6, characters 9, world 81, hotfixes 4).
- The repaired step 6 script created `TESTPLAYER@REALM` with password `Test123`,
  GM level 2 / RealmID -1. Its stored hash independently matched
  `EB9D1CBB41C758C988900C7227B0DC7702020CDD5741BA6EAEA39BB141224569`.
- All **7** PowerShell files, including the new helper, passed AST parsing.

**Still unexecuted:** Windows PowerShell 5.1, NTFS ACL application, Windows MySQL 8.0
initialization/service creation, MSVC build, game-data extraction and client login.
These Linux/MariaDB outcomes are not claims that the user's Windows instance or full
LegionCore server has been verified. The manual service + `SELECT 1` check in
troubleshooting section 12 verifies the user's local MySQL state without resetting data.


## 15. Native MySQL host-access bootstrap repair — 2026-10-11

**User report:** both configured and empty root probes return
`ERROR 1130 (HY000): Host '127.0.0.1' is not allowed to connect to this MySQL server`.
The prior error text incorrectly suggested a password problem. The actual cause
in the generated configuration was `skip-name-resolve` enabled before creation of
`root@127.0.0.1`; initial native MySQL creates only `root@localhost`.

This behavior is explicitly documented by Oracle:
https://dev.mysql.com/doc/refman/8.0/en/server-system-variables.html#sysvar_skip_name_resolve

### Changes

- New default `my.ini` no longer enables `skip-name-resolve`.
- Existing configurations receive a byte-preserving backup, then only active
  skip-name-resolve flag lines are commented. The migration is idempotent and retains
  bind address, port, data directory and all unrelated settings. Windows backup ACLs
  are copied from the original file; that ACL operation is not executed here.
- Before migration/account changes, the Windows service command must include the
  kit's server executable/config paths and the service must own the local listener
  on the configured port. Other processes/instances, stopped services, absent
  listeners, remote hosts and command-line skip-name overrides fail closed.
- A migrated config triggers a restart of only `LegionCoreMySQL` and rechecking of
  ownership. No data directory is removed/reinitialized; authentication is never
  disabled; no wildcard/root@% account is created.
- The root bootstrap also creates/grants the exact missing TCP loopback account
  when the configured localhost password already works. Existing working localhost
  passwords are not reset. A final successful `SELECT 1` is mandatory.
- `ERROR 1130` stops probes promptly and is diagnosed as host rejection, not a
  bad password. Earlier secure client transport and download fixes are retained.
- Configuration template `kit-config.ps1` and all game SQL files were checked byte
  for byte against the pre-repair ZIP and are unchanged.

### Executed on real Oracle MySQL 8.0.43 / PowerShell 7.4.6, Linux

Downloaded the official Linux minimal distribution over HTTPS and verified its MD5
against Oracle's `.md5` file (61,135,184 bytes). This distribution is test-only and
not included in the Windows kit. A separate fresh test instance was initialized
with the original skip-name setting and bound to loopback on port 13308.

1. A local socket query confirmed that the only root grant was `root@localhost`.
2. **Exact user error reproduced twice** through the shipped client helper:
   TCP `127.0.0.1` with both `admin` and empty passwords returned `ERROR 1130`.
3. The **actual INI-migration function** created a byte-identical backup and commented
   the flag. A second migration was a no-op. CRLF/underscore/loose/value-spelling
   fixture variants also passed without changing unrelated settings.
4. The native test server was stopped/restarted using process tools to load the
   repaired INI. TCP empty-root login then succeeded; `@@skip_name_resolve` returned 0.
5. A pre-existing sentinel database/table/row (`preserve_check.marker`, value 42)
   survived restart and every bootstrap/rerun.
6. The **actual installer bootstrap subsection** configured the initial root
   password, created/granted `root@127.0.0.1`, and verified the configured password.
   `CURRENT_USER()` subsequently returned `root@127.0.0.1`.
7. A bootstrap rerun succeeded; the working localhost authentication hash and
   sentinel row were unchanged.
8. An intentionally wrong password still returned `ERROR 1045`; authentication
   remained enabled throughout the fix.
9. A second missing-loopback-account scenario was tested with an already-configured
   localhost password. The actual bootstrap recreated the exact TCP account without
   resetting the localhost password or disturbing data.

### Service/port fencing fixtures (not live Windows tests)

Deterministic mock cmdlets verified acceptance of the correct executable/config/
service PID/listener and rejection of a wrong port owner, wrong instance path,
command-line override, stopped service, no listener and remote bootstrap target.

All 7 PowerShell files passed AST parsing. **Not executed:** Windows service/CIM/
NTFS operations, Windows PowerShell 5.1, Windows MySQL binaries, MSVC build, game-data
extraction or client login. This new native MySQL 8.0.43 test is stronger evidence
for the host-access repair than the prior MariaDB-only tests, but is not a claim of
complete Windows/server verification. Game database schema/import logic is unchanged;
its most recent full verification remains section 14.


## 16. Windows MySQL monitor/child PID verification repair — 2026-10-11

**User report:** the previous ownership check throws `Port 3306 belongs to a different
process, not LegionCoreMySQL`. That text assumed listener PID equals service PID;
it could not distinguish a normal server child from a genuine unrelated instance.

MySQL's Windows implementation normally creates a monitor process and a direct
server child. Oracle confirms this expected behavior
[2](https://bugs.mysql.com/bug.php?id=92683). The **pinned 8.0.43** source inspected at
`sql/restart_monitor_win.cc` calls `CreateProcess`, passes `MYSQLD_PARENT_PID`, and
reconstructs the child's argument list with quoting:
https://github.com/mysql/mysql-server/blob/mysql-8.0.43/sql/restart_monitor_win.cc

### Corrected guard

- Checks the exact executable/config option in service registration AND the actual
  running service-monitor process (not a registry path substring alone).
- Accepts the service PID directly for no-monitor mode.
- Otherwise accepts only a direct child with the expected executable/config and a
  creation timestamp not older than the current monitor (to avoid reused parent PIDs).
- Keeps actual instance/port mismatch rejection; matching only the name mysqld.exe,
  or even matching path/config without the parent relationship, is not sufficient.
- Recognizes both `--defaults-file="path"` and `"--defaults-file=path"` argument styles,
  spaced paths and the unquoted form. Rejects path suffix/lookalikes and unrelated flags.
- For an explicit 127.0.0.1 target, an unrelated IPv6-only ::1 listener is not relevant;
  for an ambiguous localhost target, unrelated IPv6 listeners cannot be ignored.
- Failure messages include safe PID/parent/executable details and reference the new
  read-only diagnostic `tools/Show-MySql-Port.ps1`. It prints no command lines/passwords.
- The guard is not bypassed, no ports are changed, and no unrelated service is stopped.
  Root bootstrap, secure client transport, configuration and all game SQL are unchanged.

### Executed fixtures — 18 scenario groups passed

The actual guard functions were extracted via the PowerShell AST and exercised with
mocked Windows CIM/NetTCP responses under PowerShell 7.4.6 on Linux:

1. Normal monitor + direct server child listener accepted.
2. Single-process/no-monitor listener accepted.
3. Exact configuration argument quoting, spaced paths and lookalike rejection.
4. Unrelated parent rejected even with matching executable/config.
5. Child wrong executable rejected.
6. Child wrong config rejected.
7. Child predating monitor/reused-parent-PID scenario rejected.
8. Missing creation evidence rejected.
9. Disappeared/unavailable listener process rejected.
10. Unavailable executable identity rejected.
11. Command-line skip-name-resolve override rejected.
12. Registered config correct but actual monitor uses another config rejected.
13. Service executable prefix/lookalike rejected.
14. Stopped service rejected.
15. Absent listener rejected.
16. Explicit IPv4 target ignores unrelated IPv6-only ::1 listener.
17. Ambiguous localhost target rejects unrelated IPv6 listener.
18. Remote bootstrap target rejected.

All **8** PowerShell files, including the read-only diagnostic, passed AST parsing.
**Windows CIM/SCM/process calls have not been executed here.** The source check and
fixtures fix a demonstrably invalid assumption, but do not prove that the user's
specific error was a false positive. If the corrected guard rejects the listener,
use the diagnostic output to identify its actual owner before changing services/ports.
Earlier native MySQL 8.0.43 host-repair tests remain valid; no database logic was
changed by this monitor-PID repair.


## 17. Native CMake/build warning and argument repair — 2026-10-11

**User status:** after the MySQL monitor repair, the user explicitly reports that
step 1 works all the way through on Windows. Their step 2 log confirms source clone,
expected SQL revision, dependency header checks and loaded `cl.exe`. The script
then aborts at `CMake Warning:` / `NativeCommandError`, before the warning body is
shown. Ninja was absent and the script selected VS2022. No actual CMake warning
continuation, real exit code or Windows compile result has yet been provided.

### Confirmed code defects and repair

- Executed the original CMake array expression: **20** VS arguments, with each of
  four `-DNAME=` definitions separate from its path. Parenthesized concatenations
  keep those definitions complete: **16** VS arguments or **13** Ninja arguments.
- Replaced redirected native Git/CMake/version pipelines with
  `tools/Native-Tools.ps1`: .NET process API, separate concurrent line reads from
  stdout/stderr, complete UTF-8 logs, streamed console output and actual exit codes.
  Native text never becomes a PowerShell error record. Strict global error handling
  stays `Stop`; errors are not ignored or stderr discarded.
- Added explicit `--config RelWithDebInfo` to build, CMake `--parallel`, and isolated
  the MSBuild-only `/nologo` option to the VS fallback.
- Reuse an existing supported cached generator; fail clearly for unsupported or
  unavailable cached generators. No automatic partial-build/source deletion.
- Added a 30-second bound to executable `--version` probes. These probes are not
  database/server startup or client-login tests.
- The focused patch includes only step 2, its new required helper and instructions.
  Working prerequisite/MySQL/database/account logic, kit configuration, game SQL,
  libraries and data are not replaced by the patch.

### Executed tests — 13 groups passed

Environment: **PowerShell 7.4.6, CMake 3.31.6, Ninja 1.12.1, g++ on Linux**.
The actual shipped helper and extracted step-2 expressions/selection code were used.
Test-only native fixtures do not emulate or claim to be Windows MSVC/LegionCore.

1. CMake-style stderr warning plus continuation and exit 0 succeeds under strict
   error handling; both complete streams and actual exit are logged.
2. Real nonzero native result (fixture exit 7) retains the full diagnostic.
3. Live `All` output mode displays the entire warning body and success lines.
4. Native argument round-trip preserves a spaced executable/generator/path, embedded
   quote, trailing backslash and empty argument.
5. Both pipes drained concurrently: **12,002** output lines (over 2 MB total), final
   lines and complete log retained without deadlock/truncation.
6. Working directory containing spaces is passed correctly.
7. A smoke-probe timeout terminates the launched tool and reports failure.
8. Missing executable/start failure cleans up log/process handles.
9. Actual Ninja/VS configure expressions keep all four path definitions complete,
   including paths with spaces (no separate empty `-DNAME=` tokens).
10. Actual build expressions select `RelWithDebInfo` and parallel mode for both
    generators, with default/explicit jobs; Ninja never receives `/nologo`.
11. Six actual generator-selection cases pass: new VS fallback, new Ninja, reuse
    cached VS after Ninja becomes available, reuse cached Ninja, reject missing
    cached Ninja, and reject unsupported cache without deletion.
12. **Real CMake configure** of a small C++ project emits an intentional multi-line
    stderr warning but exits 0; a spaced install-prefix option arrives intact.
13. **Real CMake/Ninja Multi-Config build** of that project succeeds in
    `RelWithDebInfo`; the produced binary executes and prints `native-build-ok`.

All **9** kit PowerShell files also passed AST parsing. ZIP members passed CRC
verification, and the focused patch excludes `kit-config.ps1`, prerequisite/MySQL/
database scripts and all SQL. Unchanged prerequisite/MySQL/SQL/config bytes were
compared with the prior full-kit ZIP.

**Still not executed here:** Windows PowerShell 5.1, Windows MSVC LegionCore compile,
Windows server runtime, extraction of game-client data or a game-client login. The
small Linux C++ build verifies native invocation/logging/config selection, not the
LegionCore dependency combination or the user's PC. Step 2 must now run on that PC;
a genuine remaining configure/build error will be visible in the complete logs.


## 18. Static script/core linker and target-install repair — 2026-10-13

### User-reported Windows evidence

The user supplied the full configure/build logs from their Windows 10 PC:

- VS2022 x64 configure/generated successfully, **exit 0**, SDK 10.0.26100.0 targeting
  Windows 10.0.19045; Boost/OpenSSL/MySQL checks did not stop configure.
- `bnetserver.exe`, `worldserver.exe`, core DLLs and dynamic script DLLs linked.
- `vmap4extractor`, `mapextractor` and `mmaps_generator` failed to link: missing
  `DB2Record` destructor/getters and `VMAP::WmoLiquid`, `GroupModel`, `WorldModel` and
  `StaticMapTree` methods. MSBuild's **exit 1** is a real link failure.
- Boost toolset and revision/SDK macro warnings are not the listed fatal errors.
- No Windows executable launch/version or game-client result was supplied. The kit
  stops before its collection phase on build failure; linked output alone does not
  verify server runtime.

### Source cause and code changes

The kit forced `SCRIPTS=dynamic`, unlike the repo's CI/default `SCRIPTS=static`.
`cmake/options.cmake` + `ConfigureScripts.cmake` enforce `BUILD_SHARED_LIBS=ON` when
any dynamic script requires it. `DB2Record` lacks `TC_COMMON_API`; the named VMAP
classes/tool methods likewise have no DLL export annotations. Windows DLL import
libraries do not provide those unexported definitions to the tools.

The correction explicitly selects **`SCRIPTS=static`**, **`WITH_DYNAMIC_LINKING=OFF`**,
`TOOLS=ON` and `SERVERS=ON`. This preserves every default gameplay/script module and
all five tools, without editing upstream C++ headers. Existing supported generators
are reused. A custom explicit per-module dynamic cache override is rejected with
its name instead of being silently overwritten. Old kit `default` module choices
naturally inherit static mode; no automatic build/source/data deletion.

Deployment now invokes `cmake --install --config RelWithDebInfo --prefix <ServerDir>`
using the current project's install rules. This also handles any current runtime DLL
targets and avoids glob-copying stale prior dynamic outputs. All seven executables
and certificate/key are required. External MySQL/OpenSSL files are still copied.
Existing runtime configs are preserved; missing ones are seeded from the kit.
Server `--version` failures/timeouts stop the script instead of a false success.

### Executed native regression and deployment tests

PowerShell **7.4.6**, CMake **3.31.6**, Ninja **1.12.1**, GCC on Linux:

- All **13** prior native-runner/argument/generator tests passed after the change.
  Current configure arrays contain **14 Ninja / 17 VS arguments**, with full path
  definitions, `SCRIPTS=static`, `WITH_DYNAMIC_LINKING=OFF` and `TOOLS=ON`.
- **9 additional test groups** passed using the actual shipped installer/guard/probe
  code and the repository's actual CMake options/macros:
  1. Normal legacy global/default cache accepted; explicit per-module dynamic override
     rejected without editing/deleting cache.
  2. Legacy dynamic scripts reproduce shared-library enforcement even with dynamic
     core option off.
  3. Reconfigure that **same build tree** to static: `BUILD_SHARED_LIBS=OFF`, target
     type `STATIC_LIBRARY`, all 16 default module choices and tools/servers retained;
     sentinel build file preserved.
  4. Real small static C++ fixture builds all seven deployment filenames in
     `RelWithDebInfo` (Linux binaries, not Windows PEs).
  5. Actual step 5 + real CMake install deploys outputs/TLS/external file fixtures,
     preserves edited config, seeds missing config and does not copy a stale DLL.
  6. Required-output guard rejects each missing server/tool (7 individual cases).
  7. TLS guard rejects either missing certificate/key.
  8. Actual native version probes accept success; deliberate exit 9 fails closed and
     full stderr/exit are logged.
  9. Deliberate install exit 8 stops before downstream config copying.
- All **9** kit PowerShell files passed AST parsing. Windows PowerShell 5.1 itself
  is not available here.

### Actual LegionCore tool compilation — executed, unmodified source

Source: `fed58f79c498521836612acd12009e9fa9e60e31`, git working tree clean.
Environment: **Debian 13, GCC 14.2.0, Boost 1.83, OpenSSL 3.5.7, MariaDB client
headers/library, CMake 3.31.6, Ninja 1.12.1**, Linux x64.
Configure selected static scripts/core, all tools and servers, `RelWithDebInfo`.

An initial test deliberately disabled PCH and hit a pre-existing missing `<cstring>`
include in `Common.cpp` (`strlen` undeclared). The test was reconfigured to the
project's **default PCH=ON**, matching the Windows build/defaults; **no C++ source
changes or test-only compiler header shim were used**. The subsequent build succeeded:

```text
cmake --build <linux-test-build> --config RelWithDebInfo --parallel 2 --target   mapextractor vmap4extractor vmap4assembler mmaps_generator connection_patcher
exit code: 0
```

| Actual target | Compiled Linux ELF size |
|---|---:|
| mapextractor | 6,174,448 bytes |
| vmap4extractor | 17,184,536 bytes |
| vmap4assembler | 16,750,752 bytes |
| mmaps_generator | 31,600,896 bytes |
| connection_patcher | 4,649,344 bytes |

- `common` is a real **static archive** (`libcommon.a`). `nm -C` found definitions
  for every missing DB2Record/VMAP function family in the user's tool-link errors.
- `ldd` resolved every tool's external dependency and no tool depends on
  `libcommon.so` in this mode.
- Safe `mapextractor -h` startup reached its usage text and expected exit 1 before
  any client access/extraction. A usage exit is not an extraction success test.
- Evidence is saved outside excluded caches in `LegionCore-Linker-Verification/`:
  configure/build logs (including the first no-PCH failure), symbol audit, tool
  hashes/dependency audit, and PowerShell test source/output.

**Limits:** these five artifacts are Linux binaries and are not included in the
Windows kit. Linux Boost/MariaDB/OpenSSL versions differ from the Windows dependency
bundle. The server targets/game scripts were configured but not compiled in this
Linux target-limited test. No Windows/MSVC static rebuild, Windows runtime, actual
client extraction, complete game-server startup or client login was performed here.
The user's PC must finish the static retry; partial Windows linking and Linux tool
success are not claims of full Windows/server verification.

Prerequisite/MySQL setup, database/account scripts, configuration and all SQL retain
their prior bytes. The focused patch contains only step 2, its required native helper
and instructions; ZIP CRC and full-kit comparisons are checked during packaging.

## 19. Step 5 client-data extraction without `.build.info` — 2026-10-13

### Problem

The user's 7.3.5 client has `Data\config` and `Data\data` but no `.build.info`.
Step 5 refused to start, and removing that check alone does not help: CascLib
itself needs the file. Verified against the actual library in this repository —
`CheckGameDirectory()` (`dep/CascLib/src/CascFiles.cpp`) returns
`ERROR_FILE_NOT_FOUND` (2) when neither `.build.info` nor `.build.db` exists, so
every extractor fails before reading any game data.

### Change

- **new `tools/Casc-BuildInfo.ps1`** — reconstructs the metadata from the client's
  own files: MD5-verifies every `Data\config\xx\yy\<32 hex>` entry against its
  filename, classifies build vs CDN configurations, orders candidates (build
  26972 first, then `root`-bearing, then highest build number, then newest),
  resolves the locale (`-ClientLocale` → `kit-config.ps1` → `WTF\Config.wtf` →
  locale folder → enUS) and writes the 8-column, `Active=1`, BOM-less file that
  `ParseFile_BuildInfo` accepts. Can write to the client or to a linked shadow
  root (junction on Windows, symbolic link otherwise).
- **`5-Extract-Client-Data.ps1` rewritten** — `.build.db` is accepted, a missing
  `Wow.exe` is a warning instead of a fatal error, an existing `.build.info` is
  never touched (unless `-RebuildBuildInfo`, which backs it up), a `-e 8`
  self-test runs before the long extraction and retries the next candidate, every
  tool runs through `tools/Native-Tools.ps1` with its own log, and success is
  judged by log text **and** produced-file counts rather than exit codes.
- New switches: `-ClientLocale`, `-NoClientWrite`, `-RebuildBuildInfo`,
  `-SkipProbe` (plus the existing `-SkipMmaps`, `-Threads`).
- `kit-config.ps1` gained `$ClientLocaleOverride`.

### Tests — 25 groups, all passing

Environment: PowerShell 7.4.6 (portable, Linux x64), the repository's own CascLib
compiled from `fed58f79` and `mapextractor` built from the same tree.

**A. Against the real CascLib parser** — a harness
(`casc-buildinfo-probe.cpp`, in `LegionCore-Casc-Verification/`) links the actual
`libcasc.a` and calls `CheckGameDirectory()` + `LoadBuildInfo()`, printing what the
library parsed. 15 groups:

1. no `.build.info` ⇒ error 2 — the user's failure reproduced;
2. config scan accepts only MD5-valid, correctly located text configs (2 build,
   1 CDN, 3 rejected with reasons);
3. candidate order prefers build 26972 over a newer-timestamped 25996;
4. generated file has the exact expected columns, `Active=1`, both keys, tags;
5. **CascLib loads it**: build key, CDN key, build number 26972, encoding (2 keys),
   root key, archives, index path all read back correctly;
6. a `deDE` client is detected from `WTF\Config.wtf` ⇒ CascLib reports mask
   `0x00000020`;
7. `-ClientLocale esmx` normalises to `esMX` ⇒ mask `0x00001000`; `xxXX` refused;
8. client without a CDN configuration still loads (the optional file is skipped);
9. a CDN key pointing at a build configuration — what a naive fix would write —
   really does fail in CascLib, while the kit's classification loads;
10. a config edited after hashing is dropped by the kit and rejected by CascLib;
11. an existing `.build.info` stays byte-for-byte identical;
12. a read-only client falls back to a shadow root that CascLib opens through the
    link, and a real folder is never replaced by a link;
13. the step-5 output check catches a tool that prints `No locales detected` while
    exiting 0, plus non-zero exits and hangs;
14. the **real `mapextractor` binary** reads the generated `.build.info`, opens both
    referenced config files and advances to the index stage (strace evidence in
    `casc-strace-mapextractor.txt`);
15. found while testing: with an empty `Data\data` CascLib **crashes (SIGSEGV)**
    instead of reporting an error, so the kit now refuses that client up front.

**B. The real script end to end** (`5-Extract-Client-Data.ps1` run as-is against
fixture clients and stub tools) — 10 groups: full run produces
dbc/maps/vmaps/mmaps/cameras/gt and per-tool logs, removes the temporary
`Buildings` folder and passes `--threads` in the data folder; `-SkipMmaps`;
`-NoClientWrite` (client untouched, shadow root used, `frFR` detected); automatic
retry with the second build configuration; `No locales detected` ⇒ exit 1 with the
`-ClientLocale` hint; dbc-less output ⇒ exit 1; empty `Data\data` ⇒ refused;
existing file kept, `-RebuildBuildInfo` backs it up; missing tool and `Data`-less
client refused; locale precedence `-ClientLocale` → `kit-config.ps1` →
`WTF\Config.wtf` → enUS.

All 10 kit scripts parse cleanly (PowerShell AST).

### Limits

Linux verification only. The generated metadata was proven correct against the
real CascLib parser and the real `mapextractor`, but no Windows run, no real WoW
client and no actual data extraction happened here — fixtures contain
configuration files, not CASC archives, so the tools cannot get past the index
stage in this environment. Whether *your* client's config tree is complete can
only be confirmed on your PC; the script's self-test is there to tell you that in
seconds instead of after hours of extraction. Steps 1–3 remain as reported by you;
server startup and client login are still unverified.

## 20. SQL update-hash repair (worldserver "it changed" loop) — 2026-10-13

### Problem

With the client data extracted and bnetserver running, worldserver stopped at:

```
>> Reapplying update "2024_11_24_drop_transferts.sql" '33553C5' -> 'A6D52F8' (it changed)...
ERROR 1051 (42S02) ... Unknown table 'auth.transferts'
```

Cause, confirmed numerically: `3-Setup-Databases.ps1` stored
`Get-FileHash -Algorithm SHA1`, i.e. the hash of the bytes on disk, while the
core hashes the file after a text-mode read (`UpdateFetcher::ReadSQLUpdate` +
`CalculateSHA1Hash`), which on Windows converts CRLF to LF first. The user's
checkout is CRLF (Git for Windows default), so every stored hash differed and
the core tried to re-apply already-applied updates.

Decisive evidence — the repository's own compiled `CalculateSHA1Hash`, driven by
the exact body of `ReadSQLUpdate`, over the same file in both byte forms:

```
A6D52F899C3E643074D9E1534DCFFABA360FB4A0   ...\auth\2024_11_24_drop_transferts.sql   (LF)
33553C547956CD71D80E69BC956854D480BB996E   ...\auth\2024_11_24_drop_transferts.sql   (CRLF)
```

Those are exactly the two hashes in the user's error message.

### Change

- **new `tools/Sql-Updates.ps1`** — `Get-LegionSqlUpdateHash` (CRLF→LF, Ctrl-Z
  end marker honoured, Latin-1 round-trip so non-UTF8 bytes survive, uppercase
  hex like `ByteArrayToHexStr`), `Get-LegionSqlFileHashRaw`,
  `Get-LegionUpdatesSourceDir` (reads `Updates.SourcePath`) and
  `Get-LegionSqlUpdateFiles` (walks the `updates_include` directories
  recursively, per database, like `FillFileListRecursively`).
- **new `Repair-Update-Hashes.ps1`** — compares every `updates` row with the file
  the core would read, classifies the difference as line-endings or content,
  writes a rollback .sql, corrects only the line-ending rows (content rows need
  `-Force`), then re-reads the tables to verify. `-DryRun` changes nothing.
- **`3-Setup-Databases.ps1`** now records `Get-LegionSqlUpdateHash` instead of
  `Get-FileHash`, so new installs never create the mismatch.

### Tests — 12 groups, all passing

Environment: real Oracle **MySQL 8.0.43** (Linux x64 minimal build) on port 3307,
a CRLF checkout of the repository's `sql` tree (what `core.autocrlf=true`
produces), the four databases populated exactly as the old step 3 left them
(100 update rows: auth 6, characters 9, world 81, hotfixes 4), and a hash oracle
linking the core's own `libcommon.a`.

1. the fixture reproduces the user's row (`33553C5…`) and the hash worldserver
   computed (`A6D52F8…`);
2. `Get-LegionSqlUpdateHash` equals the core's compiled hash for **all 106**
   update files;
3. and for awkward inputs: UTF-8 BOM, lone CR, Ctrl-Z, Latin-1 bytes, empty
   file, no trailing newline;
4. `-DryRun` reports every wrong row and changes nothing;
5. the repair fixes all rows and writes a runnable rollback script containing the
   old hashes;
6. simulating `UpdateFetcher::Update()`: **99 of 100** updates would have been
   re-applied before (the 100th is a single-line file whose CRLF and LF forms are
   identical), **0** afterwards;
7. re-running is a no-op and writes no extra backup;
8. a genuinely edited file is reported as "content", left for the core, and only
   rehashed with `-Force`;
9. a row whose file was deleted is reported without breaking the rest;
10. custom `updates_include` directories and nested folders are handled;
11. a wrong `-SourceDir` is refused instead of corrupting rows;
12. rows written by the corrected step 3 need no repair.

All 12 kit scripts parse cleanly (PowerShell AST).

### Limits

Tested on Linux against a real MySQL server with a faithful CRLF fixture, not on
the user's Windows PC, and worldserver itself was not run here. The CRLF→LF
translation is the documented Windows text-mode behaviour and is corroborated by
the two hashes in the user's own log. Whether worldserver proceeds past the
updater on his machine is the remaining confirmation.

## 21. PlayerBots module, milestone 1 (world population) — 2026-10-13

### What was built

A custom module in the `Custom` script module —
`src/server/scripts/Custom/PlayerBots/` (4 files, ~1,550 lines) — plus one line
added to `custom_script_loader.cpp`. No other core file is touched, so a future
`git pull` stays clean.

Creature-backed "wanderer" bots that appear around connected players, roam,
fight, and scale their levels to whoever is online; a data-driven rotation
engine with four roles; `.bots` GM commands; a 30-setting config block; and
three world-database tables (120 bot identities in entries 800000-800119,
11 spawn areas, 20 rotation steps).

### Research that shaped it

No maintained playerbot module exists for Legion 7.3.5. mod-playerbots is
AzerothCore 3.3.5 and needs its own AC fork; `normalzero/LegionPlayerBot` is on
this same core but was last touched in 2022 and documents "max count set to 10",
passive BG behaviour and incomplete group AI; SPPNXT's Legion wanderers are
NPC-based and ship without source. Hence: written fresh, hybrid design —
cheap creature wanderers for population, real player-bots later for queues.

### Verification — 7 groups, all passing

`LegionCore-PlayerBots-Verification/verify-playerbots.sh`:

1. all 3 translation units compile against the real core headers with
   `-Wall -Wextra` and **zero warnings in module code** (GCC 14, C++17);
2. no symbol the module declares is left unimplemented (`nm` set difference
   across the module's own objects);
3. all **79** core functions the module calls exist in the core/dep sources —
   i.e. no link errors waiting on the Windows build;
4. the generated SQL applies to the **real** `creature_template` /
   `creature_template_wdb` schema extracted from the official release dump,
   on a real MySQL 8.0.43 server **in strict mode**;
5. it applies three times in a row (idempotent, so the auto-updater re-running
   it is harmless);
6. row counts after those three applies are exactly 120/120/120/11/20;
7. all three area-of-effect spells are gated on "several enemies nearby", which
   is the rule that stops a bot area-nuking a single enemy player.

A control file (the existing `Solocraft.cpp`) was compiled first to prove the
harness itself is sound before trusting it on new code.

### Bug the schema test caught

The first generated SQL omitted `creature_template.WorldEffects` and
`PassiveSpells`, which are `NOT NULL` with no default in the real dump. Under
MySQL 8 strict mode that fails with ERROR 1364 — it would have failed on the
user's server. Both columns are now supplied.

### Installer test

`7-Install-PlayerBots.ps1` was run twice against a fixture source tree: the
`custom_script_loader.cpp` edit produces a file that still compiles, contains
`AddSC_playerbots` exactly twice (declaration + call), is not duplicated on the
second run, and the config block is appended once with the existing
worldserver.conf lines untouched.

### Limits

Compiled with GCC on Linux, not MSVC on Windows; the server was not started and
no bot has been seen in game. The shipped spell ids are the long-stable ones and
are validated against the client's spell data at startup — unknown ids are
logged and skipped rather than crashing. Queues, questing and the remaining 32
specialisations are not in this milestone.

## 22. PlayerBots installer - database path, retested after the Find-MySqlClient bug

The first release of `7-Install-PlayerBots.ps1` was tested with `-SkipSql`, which
skips the whole database section. That is exactly where the bug was, so the test
never executed the broken line and the crash reached the user. The section was
rewritten onto `Invoke-LegionMySql` and the suite was extended so the gap cannot
reappear.

| # | Check | Result |
|---|-------|--------|
| 1 | Every command in all 13 kit `.ps1` files resolves to a local function, a dot-sourced function, a shipped executable or a real cmdlet (static AST walk) | pass - 13/13 scripts |
| 2 | The same check against a deliberately re-broken copy | correctly **fails** on `Find-MySqlClient` |
| 3 | Installer run end to end, database section **active**, against MySQL 8.0.43 in strict mode | exit 0 |
| 4 | Run a second time over existing data | exit 0 |
| 5 | Rows after two runs (profiles/areas/rotations/updates/include) | `120/11/20/1/1` |
| 6 | `world.updates.hash` vs the core's own hashing rule for the file in the tree | identical - the updater will skip it |
| 7 | `custom_script_loader.cpp` after two runs | exactly one declaration + one call |
| 8 | `worldserver.conf` after two runs | 23 settings, zero duplicated keys |
| 9 | Wrong password | `Cannot reach MySQL at 127.0.0.1:3307 as 'root'` + the MySQL error |
| 10 | Server down (port 3399) | same message, with `ERROR 2003 Can't connect` |
| 11 | `world` database missing or empty | `Run 3-Setup-Databases.ps1 first` |
| 12 | `mysql` client not on PATH | `Install MySQL 8.0 ... or set $MySqlRoot` |

Groups 5 and 6 of `verify-playerbots.sh` now cover this permanently; the suite is
**14 checks, 14 passing**. The lesson applied: a test that passes a flag which
disables the code under test is not a test of that code.

## 23. PlayerBots - MSVC compatibility, after the `near` build failure

The module compiled cleanly on GCC and still failed on MSVC, because the whole
class of "identifier eaten by a Windows macro" cannot occur without
`<windows.h>`. The suite now emulates that header's macro pollution and scans
for the pattern lexically.

| # | Check | Result |
|---|-------|--------|
| 1 | 3 translation units, `g++ -std=c++17 -Wall -Wextra` | compile, no diagnostics in module code |
| 2 | Same 3, force-including a header that defines `near`/`far`/`pascal` empty, as `WinDef.h` does | compile clean |
| 3 | Deliberately restoring `uint32 near` | pass 1 still succeeds, **pass 2 fails** at the same three lines MSVC reported |
| 4 | Lexical scan for Windows-macro identifiers, with comments and string literals blanked | none |
| 5 | Lexical scan for GCC-only extensions (`__attribute__`, `typeof`, `__builtin_`, `#pragma GCC`) | none |
| 6 | Every `std::` facility used has its header included explicitly, not transitively | 3 gaps found and fixed |
| 7 | Declared symbols implemented | 56 defined, 0 undefined |
| 8 | Core functions called exist in the core | 74/74 |
| 9-18 | SQL, installer and kit-script groups from the previous report | unchanged, all pass |

**Fixes made**

| File | Change | Why |
|------|--------|-----|
| `PlayerBotMgr.cpp` | `near` -> `nearbyBots` (3 sites) | `#define near` in `WinDef.h` - the build failure |
| `PlayerBots.h` | `SpawnBatch(Player* near,...)` -> `Player* player` | same macro; the parameter was silently unnamed |
| `PlayerBotWandererAI.cpp` | `std::max(...)` -> `std::max<float>(...)` | explicit template args stop function-like macro expansion |
| `PlayerBotMgr.cpp` | `pos = ...` -> `pos.Relocate(...)` | `Position` declares a copy ctor but no copy-assignment |
| `PlayerBotMgr.cpp`, `PlayerBotScripts.cpp` | added `<utility>` | `std::swap` was relying on a transitive include |
| `PlayerBotWandererAI.cpp` | added `<algorithm>` | `std::max` was relying on a transitive include |

The core builds MSVC with `/W3` and **no** `/WX`, so warnings will not fail the
build; only hard errors will.

**Still unproven:** no MSVC compile, no server start, no bot seen in game.

## 24. PlayerBots - the installer wrote to a config the server never reads

The module built and loaded, but reported itself disabled in game. The block had
been appended to `<ServerDir>\etc\worldserver.conf` while the server reads
`<ServerDir>\worldserver.conf`. The test fixtures had been built around the same
wrong assumption, so every earlier run confirmed the mistake instead of exposing it.

| # | Check | Result |
|---|-------|--------|
| 1 | Installer covers every `worldserver.conf` path any kit script uses | pass |
| 2 | Same check against an installer that only knows `etc\` | correctly **fails** |
| 3 | Installer only writes to a file containing `WorldDatabaseInfo` | pass |
| 4 | End-to-end fixture rebuilt to mirror the real layout (live conf in `server\`, CMake's copy in `server\etc\`) | block lands in the live file, 23 settings |
| 5 | The ignored `etc\` copy after the run | untouched, 0 settings |
| 6 | A pre-existing block in a non-live file | warned about explicitly |
| 7 | Live config with **no trailing newline** | line break inserted first, final line intact |
| 8 | Three consecutive runs | 23 settings, 0 duplicated keys |

Suite is now **23 checks, 23 passing**.

**Root cause of the miss:** the fixture was written from the installer's own
assumption rather than from how the rest of the kit and `4-Start-Server.bat`
actually locate the config. Group 11 now compares the installer against every
other script instead of against itself.

## 25. PlayerBots - white models and the world server crash

Both faults were in code that compiled cleanly and had no SQL errors, so every
existing check passed. Two new groups were added, each verified by
reintroducing the bug.

| # | Check | Result |
|---|-------|--------|
| 1 | No packed update-field written with `SetUInt32Value` | pass |
| 2 | Same check with `SetUInt32Value(UNIT_FIELD_SEX, ...)` restored | correctly **fails** |
| 3 | No `ChrRaces` player display ID applied to a creature | pass |
| 4 | Same check with the `MaleDisplayID`/`FemaleDisplayID` override restored | correctly **fails** |
| 5 | All 120 bot displays used by existing NPCs in the official dump | pass (4-79 NPCs each) |
| 6 | Same check with the old player display IDs | correctly **fails**, 108 of 120 flagged |
| 7 | Every bot display has a `creature_model_info` row | pass |
| 8 | Upgrade path: old rows with display 49 overwritten by the new SQL | 120 rows, 0 bad, 0 stale |
| 9 | 3 translation units, plain and with Windows macro pollution | compile clean |

**A false pass found while building this.** Group 13 first reported success
against the *old* display IDs. The module SQL had aborted partway because the
scratch database lacked `creature_template`, so the orphan query inspected an
empty set. It now asserts all 120 rows are present before judging them - the
same empty-set trap that was fixed in groups 2 and 3 earlier.

Suite is now **27 checks, 27 passing**.

**Root cause of the miss:** both bugs are runtime-only. Nothing in a compile, a
symbol check or a SQL apply can see that a display ID renders white or that a
packed field write clears a class. The new checks test the *meaning* of the
values against real game data rather than their syntax.

## 26. PlayerBots - making the spell ids verifiable

The 20 rotation spell ids were the last thing in this module taken on trust.
They came from knowledge of 7.3.5, never checked against the client's
`Spell.db2`.

**They cannot be verified from here.** The release ships a hotfixes dump, but
its `spell`, `spell_misc`, `spell_class_options` and `skill_line_ability` tables
are schema with no rows - a hotfix overlay, not a copy of the client DB2. There
is no `spell_name` table at all. Nothing available offline can confirm that
spell 12294 is Mortal Strike on this build.

So instead of guessing again, the answer is now obtainable from the one
authority that has the data - the running server:

| # | Check | Result |
|---|-------|--------|
| 1 | `.bots spells` lists every loaded step with the name from `sSpellMgr->GetSpellInfo()` | implemented |
| 2 | Steps dropped at load are retained and reported, with the role they were meant for | implemented |
| 3 | `.bots status` warns when any step was dropped | implemented |
| 4 | `.bots reload` clears and rebuilds the dropped list | verified in `LoadFromDb()` |
| 5 | All 3 files compile, plain and with Windows macro pollution | pass |
| 6 | Declared symbols implemented | 58 defined (was 56), 0 undefined |
| 7 | Full suite | 27 of 27 |

Previously a wrong spell id produced one `TC_LOG_ERROR` line during startup,
buried in thousands of lines of loading output, and a bot that quietly never
used that ability. It is now a question answered in-game in a few seconds.

## 27. PlayerBots - the core patch for socket-less sessions

Modifying engine files is the riskiest thing in this kit: a bad edit breaks the
build, and a subtle one breaks every player's session, not just bots'. So the
patch was verified before anything was built on top of it.

| # | Check | Result |
|---|-------|--------|
| 1 | Patch applies to a clean checkout | pass |
| 2 | Both files carry the change | pass |
| 3 | Applying a second time is a no-op | pass |
| 4 | `WorldSession.cpp` compiles patched **and** unpatched | 0 errors both |
| 5 | `CharacterHandler.cpp`, a heavy consumer of the header | 15 errors both - pre-existing GCC include gaps, identical either way |
| 6 | Revert restores both files byte for byte | pass |
| 7 | Installer applies it to a tree holding real WorldSession files | pass |
| 8 | Both `.before-playerbots` backups written first | pass |
| 9 | A failed patch no longer aborts the rest of the install | pass |

Check 5 is the one that matters most: the patched and unpatched error counts are
**identical**, so the patch provably changes nothing about compilability. The 15
errors are core headers relying on transitive includes that MSVC provides and
GCC does not - they exist in the stock tree and are unrelated.

**A bug caught by this run.** The first version of the installer section called
`Die` when the patch could not be applied, which aborted the database and
config work that follows it. The end-to-end test caught it immediately, because
its fixture is a stub source tree. Two fixes: the failure is now a warning, and
the fixture carries real `WorldSession` files so the patch path is actually
exercised instead of silently skipped.

Suite is now **34 checks, 34 passing**.

## 28. PlayerBots stage 2 - real Player bots

| # | Check | Result |
|---|-------|--------|
| 1 | 4 translation units compile, plain | pass |
| 2 | Same 4 with `<windows.h>` macro pollution | pass |
| 3 | Declared symbols implemented | 73 defined (was 58), 0 undefined |
| 4 | Core functions called exist | 89/89 (was 74) |
| 5 | Config block grew 23 -> 26 settings, lands in the live conf | pass |
| 6 | Installer copies the new file (count no longer hardcoded) | pass |
| 7 | Core patch applied by the installer, backups written | pass |
| 8 | Full suite | 34 of 34 |

**Not tested, and cannot be from here:** that a socket-less session survives a
real world tick, that `BotLogin` completes, that the character appears in game,
or that the player tooltip is correct. Those need a running world server.

Two things reduce the blast radius: `PlayerBots.RealPlayers.Enable` defaults to
**0**, and the only way to create one is an admin command. An existing server
picking up this build behaves exactly as before until both are used.

**Stale data caught this run.** The recorded SQL hash in TROUBLESHOOTING was
still `D244944...` from before the display-ID fix changed the file. It is now
`0B8899B7F5538F2535A5C9C30C37D6423C2B3E09`, matching what the installer records.

## 29. PlayerBots - the module must never break the build

Kit v1.7 shipped a module that could only compile against a patched core, while
the installer treated a failed patch as a warning and carried on. The two
together guarantee a build failure for anyone without Python on PATH.

| # | Check | Result |
|---|-------|--------|
| 1 | Reproduce `SetBot is not a member` against a stock core | reproduced at the same line the user reported |
| 2 | All 4 files compile against a **stock, unpatched** core | pass |
| 3 | All 4 files compile against a **patched** core | pass |
| 4 | Detection reports ABSENT on a stock tree | pass |
| 5 | Detection reports PRESENT on a patched tree | pass |
| 6 | Installer verifies `SetBot` is really in the header after applying | pass |
| 7 | Installer prints a closing `core patch: APPLIED / NOT APPLIED` line | pass |
| 8 | Full suite | 36 of 36 |

`if constexpr` does not solve this: in a non-template function the discarded
branch is still type-checked, so a call to a missing member is still an error.
The module uses overload resolution on a dummy `int`/`long` argument instead,
with the real call in a trailing return type, so the overload simply drops out
when the method does not exist.

**Root cause of the miss:** every compile test ran against a patched tree. The
unpatched case - the one every user hits if the patch step is skipped - was
never built. Group 15 now compiles all four files against a stock core on every
run.

## 30. PlayerBots - config upgrades must deliver new settings

Shipping a setting is not the same as the user receiving it. The installer
skipped the entire config block whenever `PlayerBots.Enable` was already
present, so the three settings added in stage 2 never reached an existing
install, and real player-bots looked switched off.

| # | Check | Result |
|---|-------|--------|
| 1 | Config holding only the 23 pre-stage-2 settings | starting state |
| 2 | Run the installer over it | 23 -> 26 settings |
| 3 | `PlayerBots.RealPlayers.Enable` present afterwards | pass |
| 4 | Existing values preserved, not reset to defaults | pass |
| 5 | Second run | adds nothing, duplicates nothing |
| 6 | Fresh install with no block at all | full block written, 26 settings |
| 7 | Full suite | 40 of 40 |

**Root cause of the miss:** every config test used either a file with no
PlayerBots block or one already carrying the current block. The in-between case
- an older block missing newer keys, which is what every upgrading user has -
was never tested. Group 16 now builds exactly that state and asserts the delta.

This is the third instance of the same underlying mistake in this project:
shipping a change the user cannot actually receive. The earlier two were the
stale `Find-MySqlClient` copy and the config written to a path the server never
reads. The common lesson: test the **upgrade** path, not just the clean install.

## 31. PlayerBots - removing the Python dependency

A build step that needs a tool the user may not have is a defect, not a
prerequisite. `tools/patch-core.py` needed Python 3 on PATH; without it the
core silently went unpatched, the build succeeded, and `.bots player` reported
the feature missing. Everything else in this kit is PowerShell.

`tools/Patch-Core.ps1` is a pure-PowerShell port. The Python version is kept
for the Linux verification harness only.

| # | Check | Result |
|---|-------|--------|
| 1 | PowerShell and Python patchers produce **byte-identical** files | pass |
| 2 | PowerShell patcher applied twice | no-op |
| 3 | PowerShell revert restores both files byte for byte | pass |
| 4 | Patched tree still compiles | 0 errors |
| 5 | Installer never invokes Python | pass |
| 6 | Full suite | 44 of 44 |

Check 1 is what makes the port trustworthy: the two implementations are
compared on a real checkout and must agree to the byte. Getting there exposed a
real difference - the first PowerShell version omitted three blank lines - so
both now derive their insertions from the file's own line ending, which also
means a CRLF checkout on Windows stays CRLF instead of gaining stray LF lines.

**Root cause of the miss:** the Linux harness always had Python, so the
dependency was invisible in testing. Group 17 now asserts the installer never
invokes it.

## 32. Bot identities are characters the server will actually accept (group 18)

The first live `.bots player 1` failed three ways at once. Group 18 exists so
that class of failure cannot ship again. It checks the generated SQL, not the
generator's intentions:

| Check | Result |
|---|---|
| every name fits `characters.name varchar(12)` | 120/120, longest `ThoribalT002` (12) |
| every name unique (the column is a unique index) | 0 duplicates |
| every (race, class) allowed by `playercreateinfo` | 120/120 |
| every class id is a real player class (1-12) | 120/120 |
| re-applying repairs rows an older kit left behind | 24 long names, 2 bad pairs -> 0 |
| module refuses a bad profile before the INSERT | guards present |

The valid pairs are not hard-coded from memory - they are read out of
`playercreateinfo` in the official world dump, the same table the core checks
on character creation (149 pairs; race 7 allows classes 1,3,4,5,6,8,9,10 and
notably **not** 2).

The extractor also asserts it matched every profile row before judging them:
an earlier version of this very check silently inspected a subset.

**Suite total: 18 groups, 50 checks, 50 passing.**
