# Troubleshooting

Includes source-code messages, executed test output, and a user-reported download failure.

---

## 1. `worldserver.exe` / `bnetserver.exe` closes instantly or shows an error about a DLL

**Symptom:** window flashes, or `The code execution cannot proceed because libmysql.dll
was not found`.

The four runtime DLLs must sit **next to the exe** in `C:\LegionCore\server`:

| DLL | Comes from |
|---|---|
| `libmysql.dll` | `C:\libs\mysql-8.0\lib\libmysql.dll` |
| `libssl-3-x64.dll` | `C:\libs\openssl\bin\libssl-3-x64.dll` |
| `libcrypto-3-x64.dll` | `C:\libs\openssl\bin\libcrypto-3-x64.dll` |
| `legacy.dll` | `C:\libs\openssl\bin\legacy.dll` |

`2-Build-Core.ps1` copies them automatically. Also install the
[Visual C++ 2015-2022 x64 redistributable](https://aka.ms/vs/17/release/vc_redist.x64.exe).

---

## 2. `>> File "LegionCore_world_735.26972_2024_10_23.sql" is missing, download it from .../releases`

The core's updater expects the base world/hotfixes dump **in the directory the exe is
running from** (`C:\LegionCore\server`) — it does not download it for you.
Run `3-Setup-Databases.ps1`; it downloads, verifies and extracts both dumps there.
(If you already ran step 3, the database also already contains the tables and the
updater will simply log `database is up-to-date`.)

---

## 3. `ERROR 1153 / 2006: Got a packet bigger than 'max_allowed_packet' bytes`

The 237 MB world dump needs a big packet limit. Check and fix:

```powershell
& C:\libs\mysql-8.0\bin\mysql.exe -u root -padmin -e "SELECT @@max_allowed_packet/1024/1024;"
```

`1-Install-Prerequisites.ps1` writes `max_allowed_packet=1G` into
`C:\libs\mysql-8.0\my.ini`. If you changed it, edit that file and restart the service:
`Restart-Service LegionCoreMySQL`.

---

## 4. `Access denied for user 'root'@'localhost'`

The password in MySQL and the password in `kit-config.ps1` (and the two `.conf` files)
must match. Either edit `kit-config.ps1` to your real password and re-run
`3-Setup-Databases.ps1`, or reset MySQL's root password:

```powershell
# stop the service first
Stop-Service LegionCoreMySQL
& C:\libs\mysql-8.0\bin\mysqld.exe --defaults-file=C:\libs\mysql-8.0\my.ini --skip-grant-tables
# in a second window:
& C:\libs\mysql-8.0\bin\mysql.exe -u root -e "FLUSH PRIVILEGES; ALTER USER 'root'@'localhost' IDENTIFIED BY 'admin'; CREATE USER IF NOT EXISTS 'root'@'127.0.0.1' IDENTIFIED BY 'admin'; GRANT ALL PRIVILEGES ON *.* TO 'root'@'127.0.0.1' WITH GRANT OPTION;"
# then close mysqld and Start-Service LegionCoreMySQL
```

---

## 5. Login fails in the client

Checklist, in order:

1. **`bnetserver.exe` running?** It handles logins on port **8081***; `worldserver.exe`
   handles the game on **8085**. Both windows must stay open.
2. **Exact login name.** The core uppercases what you type and looks it up in
   `auth.account.username`. Use the `name@name` style (default `GM@GM`) with ASCII only.
3. **Client build.** Must be 7.3.5 **build 26972**. `auth.realmlist.gamebuild` is 26972.
4. **`connection_patcher.exe`** must be applied to your `Wow.exe` (see README) and you
   must launch the patched exe; otherwise the client rejects the self-signed certificate
   and you get "connecting… / disconnected".
5. **Portal address** in `WTF\Config.wtf` must be `SET portal "127.0.0.1"` (or your LAN IP).
6. Re-check the row directly:
   ```powershell
   & C:\libs\mysql-8.0\bin\mysql.exe -u root -padmin -e "SELECT id,username,expansion,locked,failed_logins FROM auth.account; SELECT * FROM auth.realmlist;"
   ```
   `locked` must be 0; `address`/`port` must match where worldserver listens.

---

## 6. World server complains about missing `maps` / `vmaps` / `dbc`, or creatures don't move

You have not run `5-Extract-Client-Data.ps1` yet (or it was interrupted).
`worldserver.conf` → `DataDir` must point at the folder containing
`dbc`, `maps`, `vmaps`, `mmaps`, `cameras`, `gt` (the kit uses `C:\LegionCore\ClientData`).
Creatures standing still / falling through the floor = missing `mmaps`.

---

## 7. Build errors

| Message | Fix |
|---|---|
| `Could NOT find Boost (missing: filesystem...)` | `BOOST_ROOT` must point at the folder containing **`boost\version.hpp`** (the kit uses `C:\libs\boost\boost`). The Boost build must be **vc143 (VS2022), static, x64**. |
| `Could NOT find OpenSSL` | `OPENSSL_ROOT_DIR=C:\libs\openssl`, must contain `include\openssl\ssl.h`. |
| `Could NOT find MySQL` | `MYSQL_ROOT_DIR=C:\libs\mysql-8.0` must contain `include\mysql.h` and `lib\`. |
| `cl.exe not found` | Build Tools are missing the "Desktop development with C++" workload, or you did not run the script from an admin PowerShell (it loads `VsDevCmd.bat` itself). |
| `error C1060: compiler is out of heap space` | Add RAM/close other apps, or build with `-Jobs 2`. |
| Ninja fails on paths with spaces | Install to `C:\LegionCore` (default) — avoid folders with spaces. |

Read the complete configure/build log first. For the native-warning/argument bug,
apply the repair in section 15 and reuse the existing build tree. Use `-Clean` only
when a diagnosed cache/generator change intentionally requires replacing the build
folder; it deletes previous build work, not a remedy for every CMake warning.

---

## 8. Database updates fail with `Unknown column ...` / `Table ... does not exist`

Your `sql` folder does not match your database. Two rules:

* Keep the kit's `sql\` tree (it belongs to the **2024_10_23** world dump) — do not mix
  in update files from a newer commit of the repo.
* `SourceDirectory` in `worldserver.conf` / `bnetserver.conf` must point at the folder
  that contains that `sql` folder (`C:\LegionCore\source`, where the kit's `sql` tree was
  copied by the build script; the kit's own `sql\` folder works too).
* Updates are applied in **byte order** (that is what the core does). The kit replicates
  this exactly — this matters, e.g. `..._difficulty.sql` must run **before**
  `..._difficulty_data.sql`. Do not rename files.

If a run was interrupted mid-way, simply re-run `3-Setup-Databases.ps1` — it skips what
is already applied and continues where it stopped.

---

## 9. `mmaps_generator.exe` runs for hours

Normal. It builds movement maps for every map; 1–4 hours on a desktop. It is
resumable — run it again and it continues where it stopped. To speed it up:
`5-Extract-Client-Data.ps1 -Threads 8`.

---

## 10. Starting over

```powershell
powershell -ExecutionPolicy Bypass -File .\3-Setup-Databases.ps1 -Force   # rebuild databases
Remove-Item C:\LegionCore\build -Recurse -Force                            # clean build
```


---

## 11. Step 1: Oracle "Technical Difficulties" / `Invoke-WebRequest` fails downloading MySQL

This is a failure of Oracle's download endpoint, before MySQL extraction or database
creation. The original URL redirects through `dev.mysql.com`; that redirect returned
an Oracle error page on the user's Windows PC.

The repaired `1-Install-Prerequisites.ps1` (2026-10-11) uses this direct official URL:

https://cdn.mysql.com/archives/mysql-8.0/mysql-8.0.43-winx64.zip

It works with the original `kit-config.ps1`; **keep your edited configuration**. Copy
all files in the latest repair ZIP, including `tools/MySql-Client.ps1`, into your
existing kit folder. Run the installer again in an Administrator PowerShell. Existing prerequisites
are detected; an invalid cached MySQL ZIP is discarded automatically. Downloads use
TLS 1.2, retry, and must match the pinned size and SHA256 before extraction. A failed
transfer is stored as `.download`, never as the usable ZIP.

If automated requests still fail, download the ZIP in your browser and pass it explicitly:

```powershell
powershell -ExecutionPolicy Bypass -File .\1-Install-Prerequisites.ps1 -MySqlZipPath "$env:USERPROFILE\Downloads\mysql-8.0.43-winx64.zip"
```

Do not extract the ZIP yourself. The script verifies and extracts it and then continues
with the original service setup. A supplied local ZIP is not deleted.

Verified archive: **244,242,563 bytes** (233 MiB), SHA256:
`745B4A9535992705AC43A5645B84D213A579C8FD866D1B5DCE8D6EE5A2FC7728`.
The full file was downloaded and its MD5 matched Oracle's published `.md5` file;
all ZIP entries passed CRC verification. Windows service setup has not been executed
in this Linux environment. No database SQL or account settings changed in this repair.


---

## 12. Step 1: MySQL password warning becomes `NativeCommandError`

**Symptom:** `mysql: [Warning] Using a password on the command line interface can be insecure.`
followed by a PowerShell `NativeCommandError` at the MySQL readiness/password checks.

The MySQL message is a security advisory; it does not corrupt data or by itself mean
MySQL failed. Windows PowerShell 5.1 can convert native stderr into PowerShell error
records when redirected/captured. With the original `$ErrorActionPreference = 'Stop'`,
a harmless stderr warning can therefore abort the script before root credentials are
configured or verified. A running service alone does not prove that setup completed.

**Repair:** copy the contents of `LegionCore-MySQL-PowerShell-Fix.zip` into the existing
kit folder, replacing the included scripts and merging the `tools` folder. It contains:

- `1-Install-Prerequisites.ps1` (also retains the Oracle direct-download repair)
- `3-Setup-Databases.ps1`
- `6-Create-Account.ps1`
- `tools/MySql-Client.ps1` (required by the three scripts above)

The ZIP omits `kit-config.ps1` and all SQL files; keep your edited settings and data.
Run step 1 again in an Administrator PowerShell. It detects existing prerequisites,
tries the configured root password first, handles an initial empty root password,
and requires a successful `SELECT 1` before reporting SQL verification. Existing
passwords are not overwritten on a successful rerun. Real auth/SQL failures stop
setup with the client's diagnostic; do not globally change error handling to Ignore.

The new helper uses a private temporary option file instead of a command-line password,
streams SQL through stdin, and captures stdout and stderr separately using .NET's
process API. Success depends on the actual exit code. Credential files are deleted
in `finally`; Windows ACL setup is fail-closed. No database drop/reset is part of
applying this patch or rerunning step 1.

### Check your actual Windows instance

Run these from the kit folder (after applying/rerunning the repair):

```powershell
. .\kit-config.ps1
Get-Service LegionCoreMySQL
& (Join-Path $MySqlRoot 'bin\mysql.exe') -h $MySqlHost -P $MySqlPort -u $MySqlUser -p -e 'SELECT 1 AS connection_ok;'
"MySQL exit code: $LASTEXITCODE"
```

Enter `$MySqlPass` from your configuration when prompted (default `admin`). Here `-p`
has **no password attached** and prompts interactively; do not use `-padmin` for this check.
`Running`, `connection_ok = 1` and exit code `0` confirm that the MySQL service and
configured credentials work. They do not verify the not-yet-built LegionCore binaries
or a game-client login. Access denied means the credentials are not yet usable; do not
wipe the data directory to solve it. Share the error output, not your password.

### Verification scope

The transport, bootstrap, full four-database setup, idempotent rerun and account creation
were executed on PowerShell 7.4.6 / MariaDB 11.8.6 on Linux. The original Windows warning
was diagnosed from the user's trace. Windows PowerShell 5.1, NTFS ACL execution, service
creation, MSVC build and client login have not been executed here. See test-report section 14.


---

## 13. Step 1: `ERROR 1130: Host '127.0.0.1' is not allowed to connect`

This is a real **host-access** error, before password authentication. Both the
configured password and empty-password probe get the same result because neither
is checked yet. MySQL is responding, but this does not prove that the responding
instance is the kit's service until the service/process/port are matched.

### Cause in the original kit

The generated `my.ini` enabled `skip-name-resolve` before the installer created
`root@127.0.0.1`. Native MySQL initializes only `root@localhost`. With name resolution
disabled, that initial account cannot accept TCP connections from `127.0.0.1`.
The previous MariaDB tests did not reproduce this MySQL difference. Oracle explicitly
documents the case under
[skip_name_resolve](https://dev.mysql.com/doc/refman/8.0/en/server-system-variables.html#sysvar_skip_name_resolve).

### Apply the repair

Copy **all** files from `LegionCore-MySQL-Host-Fix.zip` into your existing kit folder,
including its `tools` subfolder, and replace the included scripts. Keep your existing
`kit-config.ps1`, `C:\libs\mysql-8.0\data`, libraries and SQL files. Then run step 1
again from Administrator PowerShell:

```powershell
cd "C:\Users\Andy\Downloads\LegionCore-Server-Kit"
powershell -ExecutionPolicy Bypass -File .\1-Install-Prerequisites.ps1
```

The new installer:

1. Confirms the Windows service uses the kit's `mysqld.exe` and `my.ini` and owns the
   local TCP listener on the configured port. An unrelated instance/port stops the
   repair before configuration/account changes.
2. Backs up an existing `my.ini`, comments the legacy `skip-name-resolve` setting,
   and restarts **only** `LegionCoreMySQL` if the file changed. The brief restart can
   interrupt existing connections to that service.
3. Authenticates using the configured or initial empty root password; no grant-table
   bypass, password guessing, wildcard root account or database reinitialization.
4. Creates/grants the exact `root@127.0.0.1` account if it is missing, even when the
   initial localhost account already has the configured password. An existing working
   localhost password is not reset. A still-empty initial root is secured as intended.
5. Requires `SELECT 1` to succeed before reporting verification.

Expected final lines:

```text
[ok] TCP loopback root account ready (root@127.0.0.1)
[ok] MySQL connection verified (SELECT 1 -> 1)
```

The default new configuration leaves name resolution enabled. `bind-address=127.0.0.1`
remains unchanged, so MySQL is still local-only. No `root@%` account is created and
normal password authentication stays enabled. The backup path is printed during repair.
If the service command line explicitly enables `skip-name-resolve`, or a different
process owns the port, the script stops with a specific message rather than editing
an unrelated server. Share that output if it happens; do not delete data or disable
security to solve it.

### Verification scope

The **exact error was reproduced using Oracle MySQL 8.0.43**, not MariaDB, on Linux.
After applying the actual config migration and restarting that test instance, the
actual bootstrap code authenticated, created the loopback account and verified the
configured password. A sentinel table/row survived restart and bootstrap; a rerun
preserved the existing localhost password; bad passwords remained rejected. Windows
service/CIM/port-ownership calls were tested with mocks, not executed on Windows.
See test-report section 15.


---

## 14. `Port 3306 belongs to a different process` from the old ownership check

**Do not stop another database service or change ports based on that message alone.**
The original check compared the TCP listener PID directly to `Win32_Service.ProcessId`.
That is too strict for native Windows MySQL 8: it normally runs a service monitor
and a child server process, with different PIDs. Oracle confirms this default behavior
[2](https://bugs.mysql.com/bug.php?id=92683). The kit's previous ownership check can
therefore falsely report a conflict even when the listener is the kit's own server.
This explains a possible cause, not proof of the actual process tree on your PC.

### Repair

Copy all files from `LegionCore-MySQL-Monitor-Fix.zip` into the existing kit folder,
including the `tools` folder, and rerun step 1 in Administrator PowerShell. Keep your
configuration, libraries, SQL and data. The earlier download/warning/host repairs
are retained. No ports are changed and no unrelated services are stopped.

The corrected guard verifies the actual running service-monitor executable/config,
then accepts either the service process itself (no-monitor mode) or a **direct child**
that uses the exact expected executable/config and was created after the currently
running monitor. An unrelated mysqld process is not accepted just because its name
or executable path matches. Ambiguous localhost listeners, missing identity evidence
and actual port conflicts still stop setup before config/account changes.

### If the corrected check still stops

Run the included **read-only** diagnostic from the kit folder:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\Show-MySql-Port.ps1
```

Share its output. It reports listener PIDs, process parent PIDs, executable paths,
creation times and associated service names, but not passwords or command lines.
It does not connect to MySQL, restart/stop services, edit files or change ports.
With the actual owner identified, choose whether to keep that instance and use a
separate port for LegionCore or use the existing instance intentionally. Do not
blindly stop `MySQL80`, MariaDB, Docker or XAMPP services: they may contain other data.
Changing only `kit-config.ps1` is not sufficient for an existing port migration;
`my.ini` and the server `.conf` database connections must agree too.

### Validation scope

The normal monitor+child and single-process cases, exact quoting/path checks and
real-conflict rejection paths passed deterministic fixtures using the actual guard
code under PowerShell 7.4.6 on Linux. MySQL's pinned 8.0.43 Windows monitor source
was inspected. Windows CIM/service/process enumeration has not been executed here;
the diagnostic establishes the actual state on your PC. See test-report section 16.


---

## 15. Step 2: `CMake Warning:` / `NativeCommandError`

**User report:** step 1 now completes on Windows. Step 2 cloned the source and found
Boost/OpenSSL/MySQL headers and `cl.exe`, but stopped at its redirected CMake output
pipeline before showing the warning body. Ninja was absent, so VS2022 was selected.
The fallback itself is valid; this trace does not establish CMake's real exit code.

### Confirmed script defects

1. Native stderr entered PowerShell's error stream through `2>&1`. Under Windows
   PowerShell's `$ErrorActionPreference = 'Stop'`, a warning can terminate the script
   before the warning continuation and final exit code are visible.
2. Four unparenthesized concatenations inside the CMake argument array split
   `-DNAME=` from its path. Executing the original expression produced **20** VS
   arguments, with empty definitions and separate path tokens, rather than the
   corrected **16** (or **13** for Ninja). Those extra paths can generate CMake
   warnings. The actual warning body on the user's PC remains unknown.
3. The VS/MSBuild fallback did not pass `--config RelWithDebInfo` to the build.
   `CMAKE_BUILD_TYPE` alone does not select a multi-configuration generator's build.

### Apply the focused repair

Extract **all** of `LegionCore-Build-Fix.zip` into the existing kit folder and replace
its two code files:

- `2-Build-Core.ps1`
- `tools/Native-Tools.ps1` (new, required; merge the `tools` folder)

The patch deliberately omits configuration, prerequisite/database scripts, libraries,
SQL and data. Keep them. No need to repeat step 1, reinstall prerequisites or delete
`C:\LegionCore\build`. From the kit folder, run:

```powershell
cd "C:\Users\Andy\Downloads\LegionCore-Server-Kit"
powershell -ExecutionPolicy Bypass -File .\2-Build-Core.ps1
```

The corrected script captures native streams through .NET, drains both concurrently,
shows **all configure output**, and writes complete UTF-8 logs under `$InstallRoot\logs`
(default `C:\LegionCore\logs`). Success depends on the real exit code, not whether
stderr has any text. It preserves strict PowerShell error handling and does not
suppress genuine CMake/compiler/linker errors. Existing Ninja/VS2022 caches are reused;
unsupported/missing cached generators stop with an actionable message rather than
silently deleting the build. Both builds select `RelWithDebInfo`; MSBuild-only flags
are not passed to Ninja. The executable `--version` checks have a 30-second timeout.

If a real failure remains, share the appropriate **complete** log:

```powershell
Get-Content C:\LegionCore\logs\cmake-configure.log
# If configure succeeded but compilation/linking failed instead:
Get-Content C:\LegionCore\logs\cmake-build.log -Tail 120
```

These build logs contain no MySQL passwords. They do include local paths and Git
remote/build-tool output; redact any private information before sharing.
Only proceed to `3-Setup-Databases.ps1` after step 2 finishes successfully.

### Verification scope

13 test groups passed using the actual runner/argument/generator-selection code on
PowerShell 7.4.6/Linux. A real small CMake 3.31.6 warning configure and a Ninja
Multi-Config C++ build completed in `RelWithDebInfo`, and its produced binary ran.
That is **not** a Windows PowerShell 5.1/MSVC LegionCore build or a server/client test.
See test-report section 17. The user has separately reported step 1 completing on
Windows; no Windows compile result has been supplied yet.


---

## 16. Step 2: linker errors for `DB2Record` / `VMAP` in the extraction tools

**User log:** CMake configured/generated successfully, exit **0**. MSBuild linked
`bnetserver.exe`, `worldserver.exe` and many libraries/scripts, but failed linking
`mapextractor`, `vmap4extractor` and `mmaps_generator` with `LNK2019`/`LNK2001` and
`LNK1120`. The missing functions include `DB2Record` destructor/getters and `VMAP`
liquid/model/tree methods. Build exit **1** is a real tool-linking failure; the
Boost toolset messages and revision-header `C4005` warnings are not its reported
fatal errors. Linked files are not proof that either server has been run.

### Cause and correction

The kit incorrectly forced `SCRIPTS=dynamic`. The repository's Windows CI passes
`TOOLS=ON` and otherwise uses the project's default `SCRIPTS=static`, with dynamic
core linking off. Selecting dynamic scripts forces shared core libraries even if
`WITH_DYNAMIC_LINKING` is off. The named classes lack DLL export annotations for
the tool-used methods, so definitions compiled into `common.dll` are not usable
through its import library on Windows.

The corrected step 2 uses:

```text
-DTOOLS=ON -DSCRIPTS=static -DWITH_DYNAMIC_LINKING=OFF -DSERVERS=ON
```

Every default script module is compiled into the server; this is **not** a minimal
script build and no extraction tool is disabled. MySQL/OpenSSL runtime DLLs are
still copied: static here describes the core/game-script libraries, not all third-
party/runtime dependencies. No source-header export patch, Boost replacement or
MySQL reinstall is needed to apply this correction.

### Apply

Extract **all contents** of `LegionCore-Linker-Fix.zip` into the existing kit folder,
replace `2-Build-Core.ps1` and merge `tools/Native-Tools.ps1`. The patch omits your
configuration, prerequisite/database scripts, SQL, libraries and data. Keep them.
`LegionCore-Build-Fix.zip` has also been refreshed with this same latest repair.

```powershell
cd "C:\Users\Andy\Downloads\LegionCore-Server-Kit"
powershell -ExecutionPolicy Bypass -File .\2-Build-Core.ps1
# Optional if you want to limit CPU/RAM use: append -Jobs 2
```

Do **not** add `-Clean` just for this repair. CMake changes library/script linkage
in the existing VS2022/Ninja tree and affected targets must rebuild; existing source,
prerequisites, databases and client data are not deleted. The normal cache from this
kit has per-module choices set to `default`, so all modules follow the new static
setting. A custom explicit `SCRIPTS_<module>=dynamic` cache override stops with its
name instead of silently editing/deleting a custom build configuration.

The new collection phase uses `cmake --install` for **current RelWithDebInfo targets**
rather than manually copying a partial list or stale DLLs from old build outputs.
It requires both servers, all five tools, and the TLS certificate/key. Already-edited
runtime `.conf` files are preserved; missing configs are seeded from the kit. A failed
server `--version` probe is now fatal instead of printing a misleading next-step
success. These probes only check executable launch/version, not live server/database
operation or a client login.

Check the configure summary now says:

```text
* Build with scripts     : Yes (static)
* Script configuration (static):
    +- worldserver
       ...all default modules...
```

For any remaining failure, share the final error section of the relevant log:

- Configure: `C:\LegionCore\logs\cmake-configure.log`
- Compile/link: `C:\LegionCore\logs\cmake-build.log`
- Deployment: `C:\LegionCore\logs\cmake-install.log`
- Executable launch: `bnetserver.exe-version.log` / `worldserver.exe-version.log`
  in the same folder.

### Executed verification and limits

13 native-output/argument/generator regression groups and 9 actual static-cache/
install/guard/version-probe groups passed on PowerShell 7.4.6/Linux. The unmodified
repository's actual `mapextractor`, `vmap4extractor`, `vmap4assembler`,
`mmaps_generator` and `connection_patcher` targets also **compiled and linked** on
Linux in static-core mode with default PCH enabled. Their dependent libraries resolved,
and the missing function definitions were found in the static common archive.
A safe `mapextractor -h` launch reached usage without extracting anything.

These are Linux ELF tool binaries, **not Windows executables**. The Windows/MSVC
retry, server version probes on the user's PC, full server startup and game-client
login remain unverified here. No client extraction was performed. See test-report
section 18 for the exact environment and evidence.

## 17. Step 5: the client has no `.build.info` (`FILE_NOT_FOUND` from every extractor)

**Symptom**

```
Error opening casc storage 'C:\World of Warcraft 7.3.5': FILE_NOT_FOUND
```

or, with the older kit, step 5 refused to start:

```
[XX] 'C:\World of Warcraft 7.3.5' does not look like a WoW client (missing .build.info)
```

Your `Data\config` and `Data\data` folders are there, but the small `.build.info`
file at the top of the client folder is not. Repacks, clients copied between PCs
and clients restored from backups frequently lack it.

**Why it happens**

`.build.info` is CASC's entry point, not game data. `CheckGameDirectory()` in
`dep/CascLib/src/CascFiles.cpp` looks for `.build.info` (or the older `.build.db`)
and gives up with `ERROR_FILE_NOT_FOUND` when neither exists — so `mapextractor`,
`vmap4extractor` and `mmaps_generator` cannot read a single file. The check cannot
simply be skipped: that file is what tells CascLib *which* configuration inside
`Data\config` describes your installation.

**The fix (automatic since this kit version)**

`5-Extract-Client-Data.ps1` + `tools/Casc-BuildInfo.ps1` rebuild the file from your
own client:

1. every file under `Data\config\xx\yy\<32 hex>` is MD5-verified against its
   filename, exactly as CascLib does, and is then classified as a build
   configuration (it has `encoding = <key> <key>` and a `build-name`) or a CDN
   configuration (it has `archives = ...`);
2. candidates are ordered — client build **26972** first, then configurations with
   a `root` key, then the highest build number;
3. a two-line `.build.info` is written with the `Active=1` row and the exact column
   layout `ParseFile_BuildInfo` expects, tagged with your client's locale;
4. a short self-test (`mapextractor -e 8`) confirms the storage opens before the
   multi-hour extraction starts, and the next candidate is tried if it does not.

Nothing is downloaded and no game file is modified; the only new file is
`.build.info`. Delete it to undo.

**Options**

| Situation | What to run |
|---|---|
| The client folder must stay untouched (read-only drive, shared install) | `.\5-Extract-Client-Data.ps1 -NoClientWrite` — the generated file goes to `C:\LegionCore\client-root`, which links to your client's `Data` folder |
| Extraction produced `maps` but the `dbc` folder is empty | wrong language detected: `.\5-Extract-Client-Data.ps1 -ClientLocale deDE` (enUS koKR frFR deDE zhCN esES zhTW enGB enCN enTW itIT ptPT esMX ptBR ruRU) |
| An existing `.build.info` is itself broken | `.\5-Extract-Client-Data.ps1 -RebuildBuildInfo` (your file is backed up to `.build.info.bak-<timestamp>` first) |
| You want to skip the self-test | `-SkipProbe` |

**Related messages**

- `Data\data contains no .idx index files` — the client download is incomplete.
  The kit stops here on purpose: with an empty index folder CascLib does not
  report an error, it crashes.
- `No usable build configuration was found in ...\Data\config` — the config tree
  is damaged (the kit prints which files it ignored and why). Let the game
  launcher repair the client, or copy `.build.info` from the original install.
- `mapextractor` exiting 0 while printing `No locales detected` is now treated as a
  failure; the kit also counts the produced `.map`/`.db2`/vmap/mmap files before
  reporting success.

## 18. Worldserver: `Reapplying update ... (it changed)` then `ERROR 1051 Unknown table`

**Symptom** — bnetserver is fine, worldserver stops during startup:

```
Updating Auth database...
>> Reapplying update "2024_11_24_drop_transferts.sql" '33553C5' -> 'A6D52F8' (it changed)...
ERROR 1051 (42S02) ... Unknown table 'auth.transferts'
Applying of file '...\2024_11_24_drop_transferts.sql' to database 'auth' failed!
Could not update the Login database, see log for details.
```

**Why it happens**

Each database has an `updates` table holding one row per applied .sql file with a
SHA1 of that file. At every start the core hashes the files again and re-applies
the ones whose hash changed. The update really was applied, but the recorded
hash was wrong, so the core ran the file a second time — and the second `DROP
TABLE transferts` fails, because the first run already dropped it.

The two hashes in the message prove it exactly:

| Hash | What it is |
|---|---|
| `33553C5…` (stored) | SHA1 of the file's bytes **with CRLF** line endings |
| `A6D52F8…` (computed) | SHA1 of the same file **with LF** line endings |

Earlier versions of `3-Setup-Databases.ps1` recorded the hash with
`Get-FileHash`, which hashes the raw bytes. The core reads .sql files with a
text-mode `std::ifstream` (`UpdateFetcher::ReadSQLUpdate`), and on Windows that
turns every CRLF into a single LF before hashing. Git for Windows checks the
repository out with CRLF (`core.autocrlf=true`), so **every** recorded hash was
one byte-form out of step, and the server wanted to re-apply every update.

**The fix**

```
powershell -ExecutionPolicy Bypass -File .\Repair-Update-Hashes.ps1
```

It recomputes each hash the way the core does and corrects the rows. It never
runs an update file again, it touches nothing but the `hash` column, and it
writes a rollback script to `C:\LegionCore\logs\updates-hash-backup-<time>.sql`
first. Then start the server again with `4-Start-Server.bat`.

| Switch | Use |
|---|---|
| `-DryRun` | list what would change, change nothing |
| `-Force` | also rehash files whose **content** really differs (by default those are reported and left alone, because re-applying them is the correct behaviour after a `git pull`) |
| `-SourceDir <dir>` | use another checkout (normally taken from `Updates.SourcePath` in `worldserver.conf`) |

`3-Setup-Databases.ps1` now records the core-compatible hash (via
`tools/Sql-Updates.ps1`), so a fresh install does not hit this at all.

**If a content-changed update really does fail**

That means the file was edited after it was applied. Look at what the file does:
if the change is already in your database, mark it as applied with
`Repair-Update-Hashes.ps1 -Force`; otherwise undo the object it fails on and let
the server apply it.

## 19. `7-Install-PlayerBots.ps1`: "The term 'Find-MySqlClient' is not recognized"

**Symptom.** Section 1 (source tree) succeeds, then section 2 stops immediately:

```
Find-MySqlClient : The term 'Find-MySqlClient' is not recognized as the name of
a cmdlet, function, script file, or operable program.
```

**Cause.** A bug in the first release of `7-Install-PlayerBots.ps1`. It called a
helper, `Find-MySqlClient`, that is **not** part of `tools\MySql-Client.ps1`.
That helper is defined privately inside `3-Setup-Databases.ps1` and
`6-Create-Account.ps1`; the shared file only exports `Invoke-LegionMySql`. The
installer dot-sourced the shared file and called a function that was never there.

**If you already replaced the kit and still get this error**, the old file is
still on disk. Extracting a zip *over* an existing folder leaves the old copy
whenever Windows asks "Replace or Skip?" and Skip is chosen, and it is easy to
end up with a second, nested copy of the folder. Check with:

```powershell
powershell -ExecutionPolicy Bypass -File .\Check-Kit-Files.ps1 -Root $env:USERPROFILE\Downloads
```

It lists every copy it can find and marks each one `[ok]` or `[OLD]`. The
reliable cure is to delete the kit folder entirely and extract the new zip into
an **empty** folder - nothing in `C:\LegionCore` is touched, the kit folder only
holds scripts. From v1.1 the installer prints its version in the header:

```
  LegionCore - install PlayerBots   (installer v1.1 (2026-10-13))
```

If you do not see a version there, you are running v1.0.

**Fix.** Use the corrected `7-Install-PlayerBots.ps1` from this kit (it locates
the client itself and runs every statement through `Invoke-LegionMySql`, the same
transport the other scripts use - no password on the command line, real exit
codes). Then simply run it again:

```powershell
powershell -ExecutionPolicy Bypass -File .\7-Install-PlayerBots.ps1
```

**Nothing needs undoing first.** The run that crashed had already finished
section 1 correctly, and every step is idempotent: re-running re-copies the same
sources, re-applies the same SQL with `REPLACE INTO`/`INSERT ... WHERE NOT EXISTS`,
and leaves `custom_script_loader.cpp` and `worldserver.conf` with exactly one copy
of their edits. Running it three times in a row produces the same result as once.

**How to confirm it worked.** Section 2 should print:

```
  [ok] applied: 120 creatures, 120 profiles, 11 areas, 20 rotation steps
  [ok] recorded in world.updates (hash D0AABF6) - the updater will leave it alone
```

## 20. Build fails: `error C2513: 'uint32_t': no variable declared before '='` in PlayerBotMgr.cpp

**Symptom.** Step 2 (`2-Build-Core.ps1`) stops with four errors in a row:

```
PlayerBotMgr.cpp(660,21): error C2513: 'uint32_t': no variable declared before '='
PlayerBotMgr.cpp(662,21): error C2059: syntax error: '<'
PlayerBotMgr.cpp(665,9):  error C2143: syntax error: missing ';' before '{'
PlayerBotMgr.cpp(669,19): error C2059: syntax error: ';'
```

**Cause.** A bug in the first release of the module. Line 660 declared a local
variable called `near`:

```cpp
uint32 near = CountActiveBotsNear(player, _config.ActivationRadius);
```

`near` is not a normal identifier on Windows. `WinDef.h`, pulled in by every
`<windows.h>`, contains `#define near` with an empty body - a leftover from
16-bit memory models. The preprocessor deletes the word, MSVC sees
`uint32 = CountActiveBotsNear(...)`, and the three following errors are the
same deletion rippling through the `while` loop. `WIN32_LEAN_AND_MEAN` and
`NOMINMAX`, both of which this core sets, do not suppress it.

It built fine on Linux/GCC because `<windows.h>` does not exist there, which is
why the module was shipped without this being caught.

**Fix.** Use the module from this kit: the variable is now `nearbyBots`, the
matching parameter in `PlayerBots.h` was renamed, and the verification suite
gained a second compile pass that force-includes a header defining `near`,
`far` and `pascal` exactly as Windows does - the failure now reproduces on
Linux. Install and rebuild:

```powershell
powershell -ExecutionPolicy Bypass -File .\7-Install-PlayerBots.ps1
.\4-Stop-Server.bat
powershell -ExecutionPolicy Bypass -File .\2-Build-Core.ps1
.\4-Start-Server.bat
```

The installer is idempotent, so re-running it simply overwrites the four module
sources with the corrected ones. The database rows and the config block are
unchanged and will not be duplicated.

**Other identifiers to avoid in this codebase**, for the same reason:
`near`, `far`, `pascal`, `cdecl`, `huge`, `small`, `interface`, and -
if `NOMINMAX` is ever dropped - `min` and `max`.

## 21. In game: `.bots` says PlayerBots is disabled, even though the install succeeded

**Symptom.** The build worked, the server starts, `.bots` is a recognised
command, but it reports:

```
PlayerBots: disabled (PlayerBots.Enable = 0)
```

and `.bots spawn 20` refuses to do anything.

**Cause.** A bug in installer versions 1.0-1.2. They appended the PlayerBots
block to `<ServerDir>\etc\worldserver.conf`. The server does not read that file.
Every other part of the kit uses `<ServerDir>\worldserver.conf`:

| What | File it uses |
|------|--------------|
| `2-Build-Core.ps1` seeds the runtime config | `<ServerDir>\worldserver.conf` |
| `Repair-Update-Hashes.ps1` reads the DB credentials | `<ServerDir>\worldserver.conf` |
| `4-Start-Server.bat` runs `worldserver.exe` with `<ServerDir>` as its working directory | `<ServerDir>\worldserver.conf` |

CMake's install step also drops a copy under `etc\`, so the installer found a
file there, wrote to it, and reported success. The settings simply never
reached the server, so `PlayerBots.Enable` fell back to its default of `0`.

**Fix.** Installer v1.3 looks at both locations, treats any file containing a
`WorldDatabaseInfo` line as a live config, writes to those, and warns about a
PlayerBots block sitting in a file the server ignores.

```powershell
powershell -ExecutionPolicy Bypass -File .\7-Install-PlayerBots.ps1
```

**No rebuild is needed.** The config is read at startup, not compile time:

```
.\4-Stop-Server.bat
.\4-Start-Server.bat
```

Then `.bots status` should report `enabled`, and `.bots spawn 20` will work.

**Doing it by hand instead.** Append
`module\PlayerBots\playerbots.conf.snippet` to `C:\LegionCore\server\worldserver.conf`
and restart the world server. Make sure the file ends with a line break first,
or the first appended line will be glued onto the last existing one.

The stale block in `etc\worldserver.conf` is harmless and can be left alone.

## 22. Bots spawn fully white, and the world server crashes shortly after

**Symptom.** `.bots spawn 20` produces 20 featureless white figures, and the
world server dies soon after - often as they are summoned or first enter combat.

**Two causes, both in module versions before 1.4.**

### White models

The module overrode each bot's model with `ChrRacesEntry::MaleDisplayID` /
`FemaleDisplayID`. Those are **player character** display IDs. The client builds
a character's skin, face and hair by compositing textures from the customisation
data carried on a *Player* object; a creature has none of that, so the model
renders as an untextured white figure.

Checked against the official world dump: display IDs 49, 50, 51 ... exist in
`creature_model_info` but are used by **zero** creatures - nothing in the game
world wears them. The module now uses NPC display IDs taken from real creatures
in that same dump:

| Race | Display | Also used by |
|------|---------|--------------|
| Human | 3167 | Stormwind City Guard, Northshire Guard |
| Orc | 4259 | Orgrimmar Grunt, Stonebreaker Grunt |
| Dwarf | 1598 | Ironforge Mountaineer, Coldridge Mountaineer |
| Night Elf | 4841 | Astranaar Sentinel, Ashenvale Sentinel |
| Undead | 7117 | Deathguard Elite, Tirisfal Deathguard |
| Tauren | 2141 | Bluffwatcher, Thunder Bluff Brave |
| Gnome | 46504 | Gnome Laborer |
| Troll | 31737 | Darkspear Warrior, Sen'jin Guardian |
| Blood Elf | 15511 | Silvermoon Guardian, Sunstrider Guardian |
| Draenei | 17372 | Exodar Peacekeeper, Azuremyst Peacekeeper |

### The crash

```cpp
creature->SetUInt32Value(UNIT_FIELD_SEX, profile.Gender);
```

`UNIT_FIELD_SEX` is an **alias for `UNIT_FIELD_BYTES_0`** - a single packed
`uint32` holding race (byte 0), class (byte 1), power type (byte 2) and gender
(byte 3). Writing the whole field with a value of 0 or 1 sets the creature's
**class to 0**. `Creature::UpdateEntry` had just set it correctly from
`creature_template.unit_class`.

A class of 0 is fatal, because `Unit::UpdateAttackPowerAndDamage` in
`StatSystem.cpp` does:

```cpp
ChrClassesEntry const* entry = sChrClassesStore.LookupEntry(getClass());
val2 = (level + ...) * entry->RangedAttackPowerPerAgility;   // no null check
```

`LookupEntry(0)` returns `nullptr` and the next line dereferences it. The module
now writes only the single gender byte:

```cpp
creature->SetByteValue(UNIT_FIELD_BYTES_0, UNIT_BYTES_0_OFFSET_GENDER, profile.Gender);
```

**Fix.** Re-run the installer, then rebuild - the C++ changed this time:

```powershell
powershell -ExecutionPolicy Bypass -File .\7-Install-PlayerBots.ps1
.\4-Stop-Server.bat
powershell -ExecutionPolicy Bypass -File .\2-Build-Core.ps1
.\4-Start-Server.bat
```

The SQL deletes and reinserts entries 800000-800119, so the old white display
IDs are replaced; no cleanup is needed.

### `Creature (entry: 220010) has no model defined` is NOT this module

Those entries are nothing to do with PlayerBots - bot entries are 800000-800119.
**365 creature_template rows in the official LegionCore dump have no matching
`creature_template_wdb` row**, including 220010, 220011, 230000, 230005 and
230007. The server logs one line per entry as the grid loads and carries on.
It is pre-existing upstream data, harmless, and safe to ignore.

## 23. Build fails: `error C2039: 'SetBot': is not a member of 'WorldSession'`

**Symptom.** `2-Build-Core.ps1` stops with:

```
PlayerBotReal.cpp(117,14): error C2039: 'SetBot': is not a member of 'WorldSession'
```

**Cause.** The core patch was not applied to your source tree, but the
PlayerBots module from kit v1.7 called the patched methods unconditionally.

Almost always this means **Python 3 was not on PATH** when
`7-Install-PlayerBots.ps1` ran. `tools/patch-core.py` needs it. Version 1.7
only printed a one-line warning, which scrolls past easily, and then the build
failed later with no obvious connection.

**Fix.** Kit v1.8 onward the module detects the patch at compile time and
builds either way:

* patch applied - real player-bots work
* patch not applied - the module still compiles, `.bots player` tells you the
  patch is missing, and everything else works as normal

Just install the new kit and rebuild. Nothing else is needed:

```powershell
powershell -ExecutionPolicy Bypass -File .\7-Install-PlayerBots.ps1
.\4-Stop-Server.bat
powershell -ExecutionPolicy Bypass -File .\2-Build-Core.ps1
.\4-Start-Server.bat
```

**Note:** kit 2.0 onward the patch is applied by `tools\Patch-Core.ps1`, pure
PowerShell. **Python is no longer needed for anything.** Just re-run
`7-Install-PlayerBots.ps1`; its closing line says either
`[ok] core patch: APPLIED` or `[!!] core patch: NOT APPLIED`. Then rebuild.

**Applying the patch by hand** (no Python): in
`src\server\game\Server\WorldSession.h`, after
`bool PlayerLoading() const ...` add

```cpp
        bool IsBot() const { return _isBot; }
        void SetBot(bool on) { _isBot = on; }
        void BotLogin(ObjectGuid guid) { m_playerLoading = guid; HandleContinuePlayerLogin(); }
        void BotFinishLogin() { m_playerLoading.Clear(); }
```

and next to `bool m_playerLogout;` in the private section add

```cpp
        bool _isBot = false;
```

Then in `WorldSession.cpp`, in `WorldSession::Update`, change

```cpp
        if (!m_Socket[CONNECTION_TYPE_REALM])
```
to
```cpp
        if (!m_Socket[CONNECTION_TYPE_REALM] && !IsBot())
```

Rebuild afterwards.

## 24. `.bots status` says real player-bots are disabled after upgrading the kit

**Symptom.** You installed a newer kit, rebuilt, logged in, and `.bots status`
reports:

```
  real player-bots: disabled, 0 logged in (max 50)
```

even though you never turned them off.

**Cause.** Installers up to 1.8 treated the config block as all-or-nothing: if
`PlayerBots.Enable` was already in `worldserver.conf`, the whole block was left
alone. That protects your edited values, but it also means **settings added by
a later kit were never delivered**. `PlayerBots.RealPlayers.Enable` was not set
to 0 - it was absent, so it fell back to its default of off.

**Fix.** Installer 1.9 compares setting by setting and appends only the ones
that are missing, keeping each with its documentation comment. Your existing
values are untouched.

```powershell
powershell -ExecutionPolicy Bypass -File .\7-Install-PlayerBots.ps1
```

It will report something like:

```
  23 of 26 settings already there; adding 3 new one(s):
      PlayerBots.RealPlayers.Enable
      PlayerBots.RealPlayers.Max
      PlayerBots.RealPlayers.Accounts
```

Then set `PlayerBots.RealPlayers.Enable = 1` in
`C:\LegionCore\server\worldserver.conf` and restart the world server.
**No rebuild is needed** - config is read at startup.

**By hand instead**, append to `C:\LegionCore\server\worldserver.conf`:

```
PlayerBots.RealPlayers.Enable = 1
PlayerBots.RealPlayers.Max = 50
PlayerBots.RealPlayers.Accounts = 20
```

Make sure the file ends with a line break first, then restart the world server.

**Checking it worked.** `.bots status` should show
`real player-bots: enabled, 0 logged in (max 50)`. If it instead shows
`disabled [CORE PATCH MISSING]`, the setting is fine but the build lacks the
core patch - see §23.

## 25. `.bots player` says the worldserver was built without the core patch

**Symptom.** The build succeeds, the server runs, but:

```
This worldserver was built WITHOUT the PlayerBots core patch,
so real player-bots are unavailable.
```

**Meaning.** The binary you are running was compiled from a `WorldSession.h`
that does not have the patch. The module detects this at compile time, which is
why the build no longer fails - but the feature is genuinely absent from the
executable.

**Cause.** Up to kit 1.9 the patch was applied by `tools/patch-core.py`, which
needs Python 3 on PATH. If Python was missing, the installer warned and carried
on, and the next build produced exactly this.

**Fix.** Kit 2.0 applies the patch with `tools\Patch-Core.ps1` - pure
PowerShell, no Python, nothing to install:

```powershell
powershell -ExecutionPolicy Bypass -File .\7-Install-PlayerBots.ps1
.\4-Stop-Server.bat
powershell -ExecutionPolicy Bypass -File .\2-Build-Core.ps1
.\4-Start-Server.bat
```

Before rebuilding, check the installer's closing line:

```
  [ok] core patch: APPLIED - real player-bots available after a rebuild
```

If it says NOT APPLIED, stop and read the message above it rather than
rebuilding.

**Confirming the patch is in your source** (PowerShell):

```powershell
Select-String -Path C:\LegionCore\source\src\server\game\Server\WorldSession.h -Pattern 'void SetBot'
```

One match means the source is patched. If that matches but `.bots player` still
complains, the binary predates the patch - rebuild.

**Checking or undoing it directly:**

```powershell
.\tools\Patch-Core.ps1 -Action Check  -SourceDir C:\LegionCore\source
.\tools\Patch-Core.ps1 -Action Revert -SourceDir C:\LegionCore\source
```

## 26. ".bots player 1" fails: "Data too long for column 'name'" or "Player::Create failed"

Three symptoms, two causes, both fixed in kit v2.1. If you are on an older kit,
re-run `7-Install-PlayerBots.ps1` and **restart the world server**.

```
[1406] Data too long for column 'name' ... INSERT INTO characters
[1406] Data too long for column 'characterName' ... account_last_played_character
PlayerBots: Player::Create failed for FizzwickH021 (race 7 class 2)
```

**Cause 1 - names over 12 characters.** `characters`.`name` and
`account_last_played_character`.`characterName` are both `varchar(12)`; WoW
caps player names at 12. 24 of the 120 shipped identities were 13-14 characters
(`ThoribaldH017`, `WinterhoofT064`), so the insert failed after the character
row was half built. Names are now generated to fit: `ThoribalH017`.

**Cause 2 - impossible race/class pairs.** `playerbot_profile`.`class` was
being filled with the *creature* `unit_class` (1/2/4/8 = warrior/paladin/rogue/
mage), which is right for a creature but meaningless for a player: class 2 on a
Gnome is a Gnome Paladin, which does not exist. The core checks the pair against
`playercreateinfo` and refuses it as a hacking attempt. Each profile now gets a
real player class valid for its race, chosen to suit its role.

**Is my database already fixed?** Re-running the installer rewrites the rows.
To confirm:

```sql
SELECT COUNT(*) FROM playerbot_profile WHERE CHAR_LENGTH(name) > 12;        -- expect 0
SELECT COUNT(*) FROM playerbot_profile p WHERE NOT EXISTS
  (SELECT 1 FROM playercreateinfo c WHERE c.race = p.race AND c.class = p.class);  -- expect 0
```

The module now also refuses a bad profile *before* touching the database and
logs which profile and why, instead of letting the insert fail halfway.

Any bot character created before the fix is harmless; it is simply orphaned.
`.bots logout` removes bots from the world, and the `LCBOT...` accounts can be
deleted with `.account delete LCBOT000` if you want a clean slate.
