# PlayerBots for LegionCore 7.3.5 — milestone 1: a populated world

This is a custom module written against **your** LegionCore tree. It is not a
port of mod-playerbots (that is AzerothCore 3.3.5 and does not compile against
7.3.5 — different Player API, sessions, packets and LFG), and it is not the
SPPNXT repack (binary only, no source).

---

## What it does today

* **Wanderers.** Bots appear around connected players, walk around their patch
  of the world, pick fights with hostile creatures and — if world PvP is on —
  with the other faction, including you.
* **Levels follow the players.** The reference level is the average level of
  everyone connected. Most bots sit within ±10 of it, a configurable slice are
  "stragglers" anywhere in the level range, and when players are at the cap most
  bots are at the cap with a few still levelling below it. Exactly the behaviour
  you described.
* **Role-aware rotations, data-driven.** Four roles ship today — tank, healer,
  melee DPS, ranged DPS — as rows in `playerbot_rotation`. Priority order, range
  bands, health thresholds and cooldowns are all columns, so you can retune any
  of it with SQL and `.bots reload`, without rebuilding.
* **No AoE on a single target.** Area spells (Thunder Clap, Whirlwind, Frost
  Nova) carry `condition = 5` (enemies around ≥ N), so a bot duelling one player
  uses its single-target abilities instead. That rule is data, not code — change
  the threshold or add your own gated spells freely.
* **In-game control.** `.bots status | spawn N | despawn | level | addarea | reload | spells`.

## What it does *not* do yet

Being straight with you, because you asked for a lot in one go:

| Requested | Status |
|---|---|
| Wandering, level-scaled world population | **done** (this milestone) |
| Role-based rotations, AoE discipline | **done**, 4 roles; not 36 specs |
| World PvP | **partly** — bots fight the other faction on sight; no objectives, no organised groups |
| Questing | **not yet** — bots fight and roam, they do not take or hand in quests |
| Dungeon / raid / BG / arena queues | **not yet** — that is milestone 2, and it needs real player-bots (see below) |
| 5000 bots at once | **not as literally stated** — see Performance |

## Architecture, and why

Two kinds of bot, because no single kind can do both jobs:

* **Wanderers (this milestone)** are creatures wearing player models. They cost a
  fraction of what a real `Player` costs, which is what makes a *populated world*
  affordable. They cannot enter the LFG/BG queue, because the queue only accepts
  real players.
* **Real player-bots (milestone 2)** will be actual DB-backed characters with
  sessions, spawned a few dozen at a time, purely to fill your queues. That is
  the only way a dungeon or battleground pop can be instant.

## Performance — the honest numbers

`PlayerBots.World.Max` is a **roster**: identities (name, race, role, level).
Those are nearly free; set it to 5000 if you like.

`PlayerBots.Active.Max` is how many of them exist as real creatures at once, and
that is the number that costs CPU. A Legion creature with AI, movement and spell
casting is not free, and continent maps update on one thread.

| Active.Max | What to expect on a Windows 10 desktop |
|---|---|
| 100–300 | comfortable; this is the default range |
| ~500 | ambitious; watch your tick time |
| 1000+ | the world tick will stutter |

Watch the `Update time diff` line in the worldserver console. If it climbs past
roughly 100 ms, lower `Active.Max` or `Active.PerPlayer`. Because bots only
materialise near players, a roster of 2000 with `Active.Max = 300` *looks* like a
busy world while only ever simulating 300.

## Install

```
powershell -ExecutionPolicy Bypass -File .\7-Install-PlayerBots.ps1
.\4-Stop-Server.bat
.\2-Build-Core.ps1
.\4-Start-Server.bat
```

`-DryRun` shows what it would do. The installer is safe to run twice: it copies
the module sources, adds one line to `custom_script_loader.cpp` (keeping a
`.before-playerbots` backup), applies the SQL, records it in `world.updates` with
the hash the core itself computes, and appends the config block only if absent.

The rebuild is required — the module is C++ compiled into `worldserver.exe`. It
is incremental, so expect minutes, not the original hour.

## Commands

| Command | What it does |
|---|---|
| `.bots status` | what is loaded, active count, level band, radii |
| `.bots spawn 20` | put 20 bots around you immediately |
| `.bots despawn` | remove every active bot |
| `.bots level` | how roster levels are distributed, in bands of 10 |
| `.bots addarea 20 30 120` | record where you stand as a spawn area for levels 20–30, radius 120 |
| `.bots reload` | re-read the three tables; no restart |
| `.bots spells` | every rotation spell with the name **this server** resolves it to, plus any dropped as unknown |

## The data

Three world-database tables. All of it is yours to edit.

**`playerbot_profile`** — one row per bot identity (creature entry, race, gender,
role, team, name). Ships with 120 identities in entries 800000–800119; the range
800000–800999 is reserved for bots and is empty in the official world DB.

**`playerbot_area`** — where wanderers may appear: map, zone, x/y/z, radius,
level band, which faction, weight. Eleven starter areas ship (classic zones and
both capitals). **The ground height is recalculated at spawn**, so a slightly
wrong Z is harmless — and if no area matches, bots simply appear around the
player, so the module works even with the table empty. Use `.bots addarea` to
record exact spots instead of trusting coordinates.

**`playerbot_rotation`** — the spell priority list per role:

| Column | Meaning |
|---|---|
| `role` | 0 tank, 1 healer, 2 melee, 3 ranged |
| `priority` | lower runs first |
| `spell_id` | validated at load; unknown ids are logged and skipped, never crashed on |
| `condition` | 0 always · 1 self HP% below · 2 self HP% above · 3 target HP% below · 4 target HP% above · 5 enemies around ≥ · 6 target is a player · 7 target is not a player |
| `value` | the number that condition compares against |
| `cooldown_ms` | the module's own throttle on top of the real spell cooldown |
| `min_range` / `max_range` | yards |
| `target_self` | 1 for heals and defensives |
| `triggered` | 1 ignores power cost — set for melee rows, since a creature never builds rage |

### A note on the spell IDs that ship

They are the long-stable IDs (Frostbolt 116, Flash Heal 2061, Mortal Strike
12294, and so on) which 7.3.5 still uses. I could not verify them against *your*
`Spell.db2` from here, so the module checks every one at startup and logs the
ones your client data does not have:

```
PlayerBots: rotation spell 12345 (Some Ability) does not exist in Spell data, skipped.
```

If you see that line, fix the row and run `.bots reload`. A wrong id costs you
one ability, not stability.

**Checking the spell ids on your own build.** The shipped ids come from
knowledge of 7.3.5, not from your `Spell.db2`, so the authority is your own
server. Log in and run:

```
.bots spells
```

It prints each rotation step with the name the server resolved it to, so a
wrong id is obvious - a tank step showing something that is not a warrior
ability, or a line reporting the id was dropped entirely. `.bots status` also
warns when any step was dropped. Correct a bad id with:

```sql
UPDATE playerbot_rotation SET spell_id = <correct id> WHERE spell_id = <wrong id>;
```

then `.bots reload`.

## Tuning the level band

| Setting | Effect |
|---|---|
| `Level.Spread` | the "about 10 levels from me" window |
| `Level.StragglerPercent` | share that ignores the band, so low zones are not dead |
| `Level.MaxLevelFocusPercent` | share sitting exactly at the cap once players are at the cap |
| `Level.ResyncSeconds` | how often it recalculates (login, logout and level-up also force it) |

## What is next

1. **Milestone 2 — queues.** Real player-bot characters with sessions, joining
   LFG/BG/arena queues so your pops are instant.
2. **Milestone 3 — more specs.** The rotation engine already handles any number
   of rows; the work is filling in specs and adding conditions (dispels, interrupts,
   positioning).
3. **Questing.** Honest warning: Legion quests are heavily scripted and phased,
   so this is the hardest item on your list and will arrive last.

---

# Real player-bots (in progress)

The bots described above are **creatures**. They populate the world cheaply, but
the client decides what a tooltip says from the object's GUID type: a creature
GUID gets the creature tooltip, a player GUID gets the player one. No display,
flag or name trick changes that. To read as a player, a bot has to *be* a
`Player` with a `WorldSession`.

## Why the core needs patching

`WorldSession::Update` ends with:

```cpp
if (!m_Socket[CONNECTION_TYPE_REALM])
{
    m_sUpdate = false;
    return false;        //Will remove this session from the world session map
}
```

Both callers - `World::UpdateSessions` and `Map::Update` - respond to `false` by
calling `LogoutPlayer(true)` and erasing the session. A bot has no socket, so it
would log itself out on the next tick.

`tools/Patch-Core.ps1` adds an opt-in flag and makes that one condition respect
it (pure PowerShell - no Python needed; `tools/patch-core.py` is the equivalent
used by the Linux verification harness):

```cpp
if (!m_Socket[CONNECTION_TYPE_REALM] && !IsBot())
```

Seven lines in `WorldSession.h`, three in `WorldSession.cpp`. A session without
the flag behaves exactly as before. `7-Install-PlayerBots.ps1` applies it, with
`*.before-playerbots` backups.

```powershell
.\7-Install-PlayerBots.ps1                   # applies it
.\7-Install-PlayerBots.ps1 -NoCorePatch      # skips it
.\7-Install-PlayerBots.ps1 -RevertCorePatch  # undoes it and exits
```

No extra tooling is required. The installer's closing line states plainly
whether the patch was applied.

**Verified**: applies, applying twice is a no-op, revert restores both files
byte for byte, and `WorldSession.cpp` compiles with exactly the same result
patched and unpatched. Any core change means a rebuild with `2-Build-Core.ps1`.

## What is built, and what is not

| Stage | State |
|-------|-------|
| 1. Core patch so a socket-less session survives | **done, verified** |
| 2. Bot accounts, characters, login without a client | **done, compiles - not yet run in game** |
| 3. Gear: varied quality per bot, from `item_template` | not started |
| 4. Player-bot AI: movement, combat, grouping | not started |
| 5. Queues: dungeon, raid, battleground, arena | not started |

Stage 1 changes nothing you can see in game. It is the foundation the rest
needs, and it was done first because modifying engine files is the riskiest
part of this work - better to prove it compiles and reverts cleanly before
building on it.

Decisions taken for the stages ahead: real player-bots **replace** the creature
wanderers rather than running alongside them, and gear quality **varies per
bot** so some look well equipped and others look like they are still levelling.

## Stage 2: real Player bots

`module/PlayerBots/PlayerBotReal.cpp` adds `PlayerBotRealMgr`, which makes
genuine `Player` objects:

1. **Accounts** - created on demand through `AccountMgr::CreateAccount`, named
   `LCBOT000`, `LCBOT001` and so on, 10 characters each.
2. **Characters** - a temporary session is made so `Player::Create` has
   something to hang off, the character is levelled with `GiveLevel` and written
   with `SaveToDB(true)`, then that temporary Player is destroyed. Existing
   characters are reused by name, so re-running does not pile up duplicates.
3. **Login** - a `WorldSession` with a null socket, flagged `SetBot(true)`
   *before* it reaches the world, handed to `sWorld->AddSession`, then
   `BotLogin(guid)` starts the normal login path without a client packet.
4. **Finishing** - the world tick calls `BotFinishLogin()` once the bot is in
   world, clearing the loading state the client would normally clear.

### Using it

```
PlayerBots.RealPlayers.Enable   = 1     # off by default
PlayerBots.RealPlayers.Max      = 50    # hard cap on logged-in bots
PlayerBots.RealPlayers.Accounts = 20    # 10 characters each
```

The module compiles with or without the core patch. Without it the build still
succeeds and `.bots player` explains what is missing; with it, real player-bots
work. The installer's last line states plainly whether the patch was applied.

With the patch applied and the server rebuilt, in game:

```
.bots player 1      # start with one
.bots status        # shows "real player-bots: enabled, N logged in"
.bots logout        # log them all out
```

`.bots player` is admin-only and capped at 20 per command, because each bot
creates an account, a character and a session.

### What to expect, honestly

A bot logged in this way should read as a **player** on mouseover, with its
class, race and level. It will **stand still** - stage 4 is the AI. It has
**no gear** yet beyond whatever `Player::Create` grants - that is stage 3.

This code compiles cleanly, including under simulated Windows macro pollution,
and every core function it calls exists. None of it has been run against a live
world server. **Start with `.bots player 1`**, watch the log, and only scale up
once one works.


### Bot identities (why your bot names look the way they do)

Every bot identity has to be a character the server would let a human create:

* **Name <= 12 characters, unique.** `characters`.`name` is `varchar(12)`.
  Identities are generated as `<base><RoleLetter><NNN>` trimmed to fit, e.g.
  `ThoribalH017` - H for healer, 017 the profile index.
* **A race/class pair that exists.** Taken from `playercreateinfo` in the
  official world data, then narrowed to classes that suit the bot's role, so a
  tank gets warrior/paladin/DK/druid/monk/DH and a Gnome never gets paladin.

Both rules are enforced three times over: in the generator, by the shipped SQL,
and at runtime - a profile that breaks either rule is skipped with a log line
naming it, rather than failing halfway through a database insert.
