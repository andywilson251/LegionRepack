/*
 * PlayerBots - stage 2: real Player bots.
 *
 * A creature can never read as a player: the client picks the tooltip from the
 * object's GUID type. So these bots are genuine Player objects, each with its
 * own account, its own character row and a WorldSession that has no socket.
 *
 * The session is the delicate part. WorldSession::Update treats a missing
 * socket as a dropped connection and returns false, which makes both
 * World::UpdateSessions and Map::Update log the player out and erase the
 * session. tools/patch-core.py adds an IsBot() flag that exempts bot sessions
 * from exactly that one check, plus BotLogin()/BotFinishLogin() so login can
 * start without a client packet. Nothing here works without that patch.
 *
 * Everything is opt-in: PlayerBots.RealPlayers.Enable defaults to 0 and the
 * only entry point is the .bots player command.
 */

#include "PlayerBots.h"

#include "AccountMgr.h"
#include "Config.h"
#include "DatabaseEnv.h"
#include "Log.h"
#include "Map.h"
#include "ObjectGuid.h"
#include "ObjectMgr.h"
#include "Player.h"
#include "SharedDefines.h"
#include "World.h"
#include "WorldSession.h"
#include "CharacterPackets.h"

#include <algorithm>
#include <type_traits>
#include <string>
#include <utility>
#include <vector>

namespace
{
    // Characters per bot account. The client caps a realm at 12 per account and
    // there is no reason to go near it.
    constexpr uint32 BOT_CHARS_PER_ACCOUNT = 10;
    constexpr char const* BOT_ACCOUNT_PREFIX = "LCBOT";
    constexpr char const* BOT_ACCOUNT_PASSWORD = "legioncorebot";

    // characters.name is varchar(12); so is account_last_played_character.characterName.
    constexpr size_t MAX_BOT_NAME_LEN = 12;

    // ----------------------------------------------------------------------
    // The core patch may or may not be applied. These three helpers detect the
    // bot hooks at compile time, so this file builds against a stock core as
    // well as a patched one - a missing patch disables real player-bots at
    // runtime instead of breaking the build.
    //
    // if constexpr is no use here: in a non-template function the discarded
    // branch is still type-checked, so a call to a non-existent member is
    // still an error. Overload resolution on a dummy int/long argument is.
    // ----------------------------------------------------------------------
    template <typename S>
    auto MarkBotSession(S* s, int) -> decltype(s->SetBot(true), bool())
    {
        s->SetBot(true);
        return true;
    }
    template <typename S>
    bool MarkBotSession(S*, long) { return false; }

    template <typename S>
    auto StartBotLogin(S* s, ObjectGuid guid, int) -> decltype(s->BotLogin(guid), bool())
    {
        s->BotLogin(guid);
        return true;
    }
    template <typename S>
    bool StartBotLogin(S*, ObjectGuid, long) { return false; }

    template <typename S>
    auto FinishBotLogin(S* s, int) -> decltype(s->BotFinishLogin(), bool())
    {
        s->BotFinishLogin();
        return true;
    }
    template <typename S>
    bool FinishBotLogin(S*, long) { return false; }

    template <typename T, typename = void>
    struct HasBotHooks : std::false_type {};
    template <typename T>
    struct HasBotHooks<T, std::void_t<decltype(std::declval<T&>().SetBot(true))>> : std::true_type {};

    // True only when tools/patch-core.py has been applied to this source tree.
    constexpr bool CORE_PATCH_PRESENT = HasBotHooks<WorldSession>::value;

    std::string MakeAccountName(uint32 index)
    {
        char buf[32];
        snprintf(buf, sizeof(buf), "%s%03u", BOT_ACCOUNT_PREFIX, index);
        return std::string(buf);
    }
}

PlayerBotRealMgr* PlayerBotRealMgr::instance()
{
    static PlayerBotRealMgr instance;
    return &instance;
}

bool PlayerBotRealMgr::CorePatchPresent() const
{
    return CORE_PATCH_PRESENT;
}

void PlayerBotRealMgr::LoadConfig()
{
    _enabled  = sConfigMgr->GetBoolDefault("PlayerBots.RealPlayers.Enable", false);
    _maxBots  = sConfigMgr->GetIntDefault("PlayerBots.RealPlayers.Max", 50);
    _accounts = sConfigMgr->GetIntDefault("PlayerBots.RealPlayers.Accounts", 20);

    if (_maxBots > 1000)
        _maxBots = 1000;                    // a Player each; this is not a roster count
    if (_accounts < 1)
        _accounts = 1;

    if (_enabled && !CORE_PATCH_PRESENT)
    {
        TC_LOG_ERROR("server.loading", "PlayerBots: RealPlayers.Enable is on, but this worldserver "
            "was built WITHOUT the core patch. Real player-bots are unavailable. "
            "Run 7-Install-PlayerBots.ps1 (it needs Python 3 on PATH) and rebuild.");
    }
    else if (_enabled)
    {
        TC_LOG_INFO("server.loading", "PlayerBots: real player-bots enabled (max %u, %u accounts).",
            _maxBots, _accounts);
    }
}

uint32 PlayerBotRealMgr::EnsureAccount(uint32 index)
{
    std::string name = MakeAccountName(index);

    if (uint32 existing = AccountMgr::GetId(name))
        return existing;

    // async = false: the id is needed immediately.
    AccountOpResult result = AccountMgr::CreateAccount(name, BOT_ACCOUNT_PASSWORD, false);
    if (result != AccountOpResult::AOR_OK)
    {
        TC_LOG_ERROR("server.loading", "PlayerBots: could not create bot account %s (result %u).",
            name.c_str(), uint32(result));
        return 0;
    }

    uint32 id = AccountMgr::GetId(name);
    if (!id)
    {
        TC_LOG_ERROR("server.loading", "PlayerBots: bot account %s was created but cannot be looked up.",
            name.c_str());
        return 0;
    }

    TC_LOG_INFO("server.loading", "PlayerBots: created bot account %s (id %u).", name.c_str(), id);
    return id;
}

ObjectGuid PlayerBotRealMgr::EnsureCharacter(uint32 accountId, PlayerBotProfile const& profile,
                                             uint8 level, std::string const& name)
{
    if (!accountId || name.empty())
        return ObjectGuid::Empty;

    // `characters`.`name` and `account_last_played_character`.`characterName`
    // are both varchar(12). A longer name reaches the database and fails with
    // "Data too long for column 'name'", after the character row is half built.
    if (name.size() > MAX_BOT_NAME_LEN)
    {
        TC_LOG_ERROR("server.loading", "PlayerBots: profile name '%s' is %u characters; the limit is %u. "
            "Fix playerbot_profile.name and run .bots reload.",
            name.c_str(), uint32(name.size()), uint32(MAX_BOT_NAME_LEN));
        return ObjectGuid::Empty;
    }

    // The server refuses an invalid race/class pair as a hacking attempt.
    // GetPlayerInfo is the same data it checks against, so ask first.
    if (!sObjectMgr->GetPlayerInfo(profile.RaceId, profile.ClassId))
    {
        TC_LOG_ERROR("server.loading", "PlayerBots: race %u / class %u is not a valid combination "
            "(profile '%s'). Fix playerbot_profile and run .bots reload.",
            uint32(profile.RaceId), uint32(profile.ClassId), name.c_str());
        return ObjectGuid::Empty;
    }

    // Already made on a previous run? Reuse it rather than piling up characters.
    if (ObjectGuid existing = ObjectMgr::GetPlayerGUIDByName(name))
        return existing;

    // Player::Create needs a session to hang off. This one is temporary: it
    // exists only so the character row can be written.
    WorldSessionPtr scratch = std::make_shared<WorldSession>(
        accountId, std::string(name), nullptr, SEC_PLAYER, CURRENT_EXPANSION,
        time_t(0), std::string(""), LOCALE_enUS, 0, false, AT_AUTH_FLAG_NONE,
        std::unordered_map<uint8, int64>());
    MarkBotSession(scratch.get(), 0);

    WorldPackets::Character::CharacterCreateInfo createInfo;
    createInfo.Name           = name;
    createInfo.Race           = profile.RaceId;
    createInfo.Class          = profile.ClassId;
    createInfo.Sex            = profile.Gender;
    createInfo.Skin           = 0;
    createInfo.Face           = 0;
    createInfo.HairStyle      = 0;
    createInfo.HairColor      = 0;
    createInfo.FacialHairStyle = 0;
    createInfo.OutfitId       = 0;
    createInfo.CustomDisplay.fill(0);

    ObjectGuid::LowType guidLow = sObjectMgr->GetGenerator<HighGuid::Player>()->Generate();

    Player* bot = new Player(scratch.get());
    if (!bot->Create(guidLow, &createInfo))
    {
        TC_LOG_ERROR("server.loading", "PlayerBots: Player::Create failed for %s (race %u class %u).",
            name.c_str(), uint32(profile.RaceId), uint32(profile.ClassId));
        delete bot;
        return ObjectGuid::Empty;
    }

    if (level > 1)
        bot->GiveLevel(level);

    bot->SaveToDB(true);
    ObjectGuid guid = bot->GetGUID();

    // The Player is only a vehicle for writing the row; it is not logged in.
    delete bot;

    TC_LOG_INFO("server.loading", "PlayerBots: created character %s (level %u) on account %u.",
        name.c_str(), uint32(level), accountId);
    return guid;
}

bool PlayerBotRealMgr::LoginOne(PlayerBotProfile const& profile, uint8 level, uint32 slot)
{
    uint32 accountIndex = slot / BOT_CHARS_PER_ACCOUNT;
    if (accountIndex >= _accounts)
        accountIndex = accountIndex % _accounts;

    uint32 accountId = EnsureAccount(accountIndex);
    if (!accountId)
        return false;

    std::string name = profile.Name;
    if (name.empty())
        return false;

    ObjectGuid guid = EnsureCharacter(accountId, profile, level, name);
    if (guid.IsEmpty())
        return false;

    // One live session per bot, kept alive here for as long as the bot is in.
    WorldSessionPtr session = std::make_shared<WorldSession>(
        accountId, std::string(name), nullptr, SEC_PLAYER, CURRENT_EXPANSION,
        time_t(0), std::string(""), LOCALE_enUS, 0, false, AT_AUTH_FLAG_NONE,
        std::unordered_map<uint8, int64>());

    // Must be set before the session reaches the world, or the first update
    // tick will treat the absent socket as a disconnect and drop it.
    if (!MarkBotSession(session.get(), 0))
    {
        TC_LOG_ERROR("server.loading", "PlayerBots: the core patch is not applied to this build, "
            "so a bot session cannot be flagged and would be dropped immediately. "
            "Run 7-Install-PlayerBots.ps1 and rebuild.");
        return false;
    }

    sWorld->AddSession(session);

    if (!StartBotLogin(session.get(), guid, 0))
    {
        TC_LOG_ERROR("server.loading", "PlayerBots: the core patch is not applied, so bot login "
            "cannot be started. Run 7-Install-PlayerBots.ps1 and rebuild.");
        return false;
    }

    _sessions.push_back(session);
    return true;
}

uint32 PlayerBotRealMgr::SpawnPlayerBots(Player* owner, uint32 count)
{
    if (!_enabled || !owner || !CorePatchPresent())
        return 0;

    std::vector<PlayerBotProfile> const& profiles = sPlayerBotMgr->GetProfiles();
    if (profiles.empty())
        return 0;

    uint32 spawned = 0;
    for (uint32 i = 0; i < count; ++i)
    {
        if (CountLoggedIn() >= _maxBots)
        {
            TC_LOG_INFO("server.loading", "PlayerBots: real-player cap %u reached.", _maxBots);
            break;
        }

        PlayerBotProfile const& profile = profiles[(_nextProfile++) % profiles.size()];
        uint8 level = sPlayerBotMgr->PickLevelForBot();

        if (LoginOne(profile, level, _nextSlot++))
            ++spawned;
    }

    return spawned;
}

uint32 PlayerBotRealMgr::CountLoggedIn() const
{
    uint32 n = 0;
    for (WorldSessionPtr const& s : _sessions)
        if (s && s->GetPlayer())
            ++n;
    return n;
}

uint32 PlayerBotRealMgr::LogoutAll()
{
    uint32 n = 0;
    for (WorldSessionPtr& s : _sessions)
    {
        if (!s)
            continue;
        if (s->GetPlayer())
            ++n;
        s->LogoutPlayer(true);
    }
    _sessions.clear();
    return n;
}

void PlayerBotRealMgr::Update(uint32 /*diff*/)
{
    if (!_enabled || _sessions.empty())
        return;

    // Clear the "still loading" state the client would normally clear, and drop
    // any session whose player has gone away.
    for (auto itr = _sessions.begin(); itr != _sessions.end(); )
    {
        WorldSessionPtr& s = *itr;
        if (!s)
        {
            itr = _sessions.erase(itr);
            continue;
        }

        if (Player* bot = s->GetPlayer())
        {
            if (s->PlayerLoading() && bot->IsInWorld())
                FinishBotLogin(s.get(), 0);
            ++itr;
        }
        else
        {
            ++itr;      // still logging in; the query holder completes later
        }
    }
}
