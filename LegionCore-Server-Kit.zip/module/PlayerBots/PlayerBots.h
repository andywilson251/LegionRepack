/*
 * LegionCore PlayerBots - world population module
 *
 * Milestone 1: "wanderers" - lightweight creature-backed bots that populate the
 * open world, scale their level to the players who are actually connected, and
 * fight with a data-driven, role-aware spell rotation.
 *
 * Everything here lives in the Custom script module, so the only core file that
 * changes is custom_script_loader.cpp (one line). That keeps `git pull` clean.
 */

#ifndef LEGIONCORE_PLAYERBOTS_H
#define LEGIONCORE_PLAYERBOTS_H

// Standard headers first: core headers below rely on some of these being
// present already (MSVC pulls them in transitively, other compilers do not).
#include <map>
#include <set>
#include <memory>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "Define.h"
#include "ObjectGuid.h"

class Creature;
class WorldSession;
class Player;
class Unit;

enum PlayerBotRole : uint8
{
    BOT_ROLE_TANK   = 0,
    BOT_ROLE_HEALER = 1,
    BOT_ROLE_MELEE  = 2,
    BOT_ROLE_RANGED = 3,
    BOT_ROLE_MAX
};

enum PlayerBotTeam : uint8
{
    BOT_TEAM_ALLIANCE = 0,
    BOT_TEAM_HORDE    = 1,
    BOT_TEAM_MAX
};

// Conditions a rotation step can require. Kept small and explicit: the point is
// that a server owner can retune rotations in SQL without recompiling.
enum PlayerBotCondition : uint8
{
    BOT_COND_ALWAYS                 = 0,
    BOT_COND_SELF_HP_BELOW_PCT      = 1,
    BOT_COND_SELF_HP_ABOVE_PCT      = 2,
    BOT_COND_TARGET_HP_BELOW_PCT    = 3,
    BOT_COND_TARGET_HP_ABOVE_PCT    = 4,
    BOT_COND_ENEMIES_AROUND_MIN     = 5,    // value = how many enemies within 8 yards
    BOT_COND_TARGET_IS_PLAYER       = 6,    // real player or another bot: a "PvP" target
    BOT_COND_TARGET_IS_NOT_PLAYER   = 7,
    BOT_COND_MAX
};

struct PlayerBotProfile
{
    uint32      Entry       = 0;        // creature_template.entry
    uint8       ClassId     = 0;        // CLASS_WARRIOR ...
    uint8       RaceId      = 0;        // RACE_HUMAN ...
    uint8       Gender      = 0;        // 0 male, 1 female
    uint8       Role        = BOT_ROLE_MELEE;
    uint8       Team        = BOT_TEAM_ALLIANCE;
    std::string Name;                   // informational; the client shows creature_template_wdb.Name1
};

struct PlayerBotRotationStep
{
    uint32      SpellId     = 0;
    uint8       Role        = BOT_ROLE_MELEE;
    uint8       Priority    = 0;        // lower runs first
    uint8       Condition   = BOT_COND_ALWAYS;
    float       Value       = 0.0f;     // meaning depends on Condition
    uint32      CooldownMs  = 0;        // our own throttle, on top of the real spell cooldown
    float       MinRange    = 0.0f;
    float       MaxRange    = 40.0f;
    bool        TargetSelf  = false;    // heals / defensives
    bool        Triggered   = false;    // bypass power cost/cooldown (melee resources a creature never builds)
    std::string Comment;
};

struct PlayerBotArea
{
    uint32      Id          = 0;
    uint32      MapId       = 0;
    uint32      ZoneId      = 0;
    float       X           = 0.0f;
    float       Y           = 0.0f;
    float       Z           = 0.0f;
    float       Radius      = 80.0f;
    uint8       MinLevel    = 1;
    uint8       MaxLevel    = 110;
    uint8       TeamMask    = 3;        // 1 alliance, 2 horde, 3 both
    uint32      Weight      = 1;
    std::string Name;
};

struct PlayerBotConfig
{
    bool     Enable                 = false;

    // roster / materialisation
    uint32   RosterMin              = 200;
    uint32   RosterMax              = 2000;
    uint32   ActiveMax              = 300;      // creatures alive at once
    uint32   ActivePerPlayer        = 40;
    uint32   SpawnPerTickMax        = 5;
    uint32   UpdateIntervalMs       = 2000;
    float    ActivationRadius       = 250.0f;   // spawn within this distance of a player
    float    DeactivationRadius     = 450.0f;   // despawn past this distance (hysteresis)

    // level band
    uint8    MaxLevel               = 110;
    uint8    MinLevel               = 1;
    uint8    LevelSpread            = 10;       // "within about 10 levels of me"
    uint8    StragglerPct           = 15;       // % of bots that ignore the band
    uint8    MaxLevelFocusPct       = 70;       // % sitting at max when players are at max
    uint32   LevelResyncSeconds     = 60;

    // behaviour
    bool     CombatEnable           = true;
    bool     WorldPvpEnable         = true;
    float    WanderRadius           = 60.0f;
    uint32   WanderPauseMinMs       = 4000;
    uint32   WanderPauseMaxMs       = 15000;

    // factions (0 = resolve from the client's own ChrRaces/FactionTemplate data)
    uint32   FactionAlliance        = 0;
    uint32   FactionHorde           = 0;

    bool     DebugLog               = false;
};

struct PlayerBotRosterEntry
{
    uint32      ProfileIndex    = 0;
    uint8       Level           = 1;
    ObjectGuid  Guid;                   // empty while dormant
    uint32      AreaId          = 0;
    bool        Active          = false;
};

namespace PlayerBotUtil
{
    // Gives a creature a specific level and the matching base stats, the same way
    // Creature::SelectLevel does it, but for a level we choose instead of a random
    // one out of creature_template.
    void ApplyLevel(Creature* creature, uint8 level);

    // Player race/gender model, pulled from the server's own ChrRaces data so we
    // never hardcode display ids that differ between builds.
    void ApplyAppearance(Creature* creature, PlayerBotProfile const& profile, PlayerBotConfig const& config);
}

class PlayerBotMgr
{
public:
    static PlayerBotMgr* instance();

    void RegisterBot(Creature* creature);
    void UnregisterBot(ObjectGuid guid);

    void LoadConfig(bool reload);
    void LoadFromDb();
    void OnWorldStartup();
    void Update(uint32 diff);

    void OnPlayerLevelChanged();

    // forced spawn/despawn for the .bots commands
    uint32 SpawnBatch(Player* player, uint32 count);
    uint32 DespawnAll();

    PlayerBotConfig const& GetConfig() const { return _config; }
    std::vector<PlayerBotProfile> const& GetProfiles() const { return _profiles; }
    uint8 PickLevelForBot() const;

    std::vector<PlayerBotRotationStep> const& GetRotation(uint8 role) const;

    // rotation steps dropped at load because the spell id is not in this
    // build's Spell data; kept so '.bots spells' can report them
    struct DroppedSpell { uint32 SpellId; uint8 Role; std::string Comment; };
    std::vector<DroppedSpell> const& GetDroppedSpells() const { return _droppedSpells; }
    PlayerBotProfile const* GetProfileForEntry(uint32 entry) const;

    uint8  GetReferenceLevel() const { return _referenceLevel; }
    uint32 GetRosterSize() const { return uint32(_roster.size()); }
    uint32 GetActiveCount() const { return _activeCount; }
    uint32 GetProfileCount() const { return uint32(_profiles.size()); }
    uint32 GetAreaCount() const { return uint32(_areas.size()); }
    uint32 GetRotationStepCount() const { return _rotationStepCount; }
    void   GetLevelHistogram(std::vector<uint32>& buckets) const;

    uint32 ResolveFactionTemplate(uint8 raceId, uint8 team) const;
    uint8  RollLevelForBand(uint8 areaMin, uint8 areaMax) const;

private:
    PlayerBotMgr() { }

    void RefreshReferenceLevel();
    void BuildRoster();
    void DespawnDistantBots();
    void SpawnNearPlayers();
    bool SpawnOneNear(Player* player);
    uint32 CountActiveBotsNear(Player* player, float radius) const;
    PlayerBotArea const* PickAreaNear(Player* player) const;
    int32 PickDormantRosterEntry(uint8 wantedLevel, uint8 teamMask) const;

    PlayerBotConfig                     _config;
    std::vector<PlayerBotProfile>       _profiles;
    std::vector<PlayerBotArea>          _areas;
    std::vector<PlayerBotRotationStep>  _rotations[BOT_ROLE_MAX];
    std::vector<PlayerBotRosterEntry>   _roster;
    std::unordered_map<uint32, uint32>  _profileByEntry;    // creature entry -> index into _profiles
    std::vector<DroppedSpell> _droppedSpells;
    std::unordered_map<ObjectGuid, Creature*> _activeBots;  // materialised bots, maintained by the AI
    std::unordered_map<ObjectGuid, uint32>    _guidToRoster;

    uint32  _rotationStepCount  = 0;
    uint32  _updateTimer        = 0;
    uint32  _levelTimer         = 0;
    uint8   _referenceLevel     = 1;
    uint32  _activeCount        = 0;
    bool    _loaded             = false;
};

#define sPlayerBotMgr PlayerBotMgr::instance()

// ---------------------------------------------------------------------------
// Stage 2: real Player bots.
//
// Needs the core patch from tools/patch-core.py. Opt-in via
// PlayerBots.RealPlayers.Enable; the only entry point is ".bots player N".
// ---------------------------------------------------------------------------
class PlayerBotRealMgr
{
public:
    static PlayerBotRealMgr* instance();

    void LoadConfig();
    void Update(uint32 diff);

    uint32 SpawnPlayerBots(Player* owner, uint32 count);
    uint32 LogoutAll();
    uint32 CountLoggedIn() const;

    bool   IsEnabled() const { return _enabled; }
    bool   CorePatchPresent() const;
    uint32 GetMax() const { return _maxBots; }

private:
    uint32     EnsureAccount(uint32 index);
    ObjectGuid EnsureCharacter(uint32 accountId, PlayerBotProfile const& profile,
                               uint8 level, std::string const& name);
    bool       LoginOne(PlayerBotProfile const& profile, uint8 level, uint32 slot);

    bool   _enabled     = false;
    uint32 _maxBots     = 50;
    uint32 _accounts    = 20;
    uint32 _nextProfile = 0;
    uint32 _nextSlot    = 0;
    std::vector<std::shared_ptr<WorldSession>> _sessions;
};

#define sPlayerBotRealMgr PlayerBotRealMgr::instance()


#endif // LEGIONCORE_PLAYERBOTS_H
