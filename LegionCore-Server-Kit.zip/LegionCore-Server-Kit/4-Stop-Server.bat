@echo off
REM ============================================================================
REM  LegionCore 7.3.5 - stop the server (closes both server windows cleanly)
REM ============================================================================
taskkill /FI "WINDOWTITLE eq LegionCore WorldServer*" /T /F >nul 2>&1
taskkill /FI "WINDOWTITLE eq LegionCore BnetServer*"  /T /F >nul 2>&1
REM fall back to killing by image name (in case the windows were renamed)
taskkill /IM worldserver.exe /F >nul 2>&1
taskkill /IM bnetserver.exe  /F >nul 2>&1
echo Server stopped.
timeout /t 3 /nobreak >nul
