<#
Native build-tool runner for Windows PowerShell 5.1. Native stdout/stderr never
enter PowerShell's error stream. All output is logged, output is streamed live,
and the real process exit code decides success. No global error preference is
weakened. This helper does not handle MySQL credentials or modify services.
#>
#Requires -Version 5.1

function ConvertTo-LegionToolArgument {
    param([AllowEmptyString()][string]$Value)
    if ($Value.IndexOf([char]0) -ge 0) { throw 'A process argument cannot contain a NUL character.' }
    $escaped = [regex]::Replace($Value, '(\\*)"', '$1$1\"')
    $escaped = [regex]::Replace($escaped, '(\\+)$', '$1$1')
    return ('"' + $escaped + '"')
}

function Invoke-LegionNativeTool {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Executable,
        [AllowEmptyCollection()][string[]]$Arguments = @(),
        [string]$WorkingDirectory = '',
        [Parameter(Mandatory=$true)][string]$LogPath,
        [ValidateSet('All','Build','Quiet')][string]$OutputMode = 'All',
        [switch]$CaptureOutput,
        [ValidateRange(0,2147483647)][int]$TimeoutSeconds = 0
    )
    $parent = Split-Path $LogPath -Parent
    if ($parent) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
    $utf8 = New-Object Text.UTF8Encoding $false
    $log = $null
    $process = $null
    $started = $false
    $timedOut = $false
    $clock = [Diagnostics.Stopwatch]::StartNew()
    $outLines = New-Object 'Collections.Generic.List[string]'
    $errLines = New-Object 'Collections.Generic.List[string]'
    try {
        $log = New-Object IO.StreamWriter -ArgumentList @($LogPath, $false, $utf8)
        $log.AutoFlush = $true
        $quoted = @($Arguments | ForEach-Object { ConvertTo-LegionToolArgument $_ })
        $log.WriteLine('Started: ' + [DateTime]::UtcNow.ToString('o'))
        $log.WriteLine('Executable: ' + $Executable)
        $log.WriteLine('Arguments: ' + ($quoted -join ' '))
        $log.WriteLine('Working directory: ' + $WorkingDirectory)
        $log.WriteLine('--- tool output ---')

        $psi = New-Object Diagnostics.ProcessStartInfo
        $psi.FileName = $Executable
        $psi.Arguments = $quoted -join ' '
        if ($WorkingDirectory) { $psi.WorkingDirectory = $WorkingDirectory }
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true
        $psi.RedirectStandardInput = $true
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true
        $psi.StandardOutputEncoding = $utf8
        $psi.StandardErrorEncoding = $utf8
        $process = New-Object Diagnostics.Process
        $process.StartInfo = $psi
        $started = $process.Start()
        if (-not $started) { throw "Could not start $Executable" }
        $process.StandardInput.Close()

        # Read both streams concurrently. PowerShell event callbacks on background
        # threads are deliberately avoided (they have no PowerShell runspace).
        $outTask = $process.StandardOutput.ReadLineAsync()
        $errTask = $process.StandardError.ReadLineAsync()
        while ($null -ne $outTask -or $null -ne $errTask) {
            if ($TimeoutSeconds -gt 0 -and $clock.Elapsed.TotalSeconds -ge $TimeoutSeconds -and -not $process.HasExited -and -not $timedOut) {
                $timedOut = $true
                $log.WriteLine('--- tool timeout reached; terminating this tool process ---')
                $process.Kill()
            }
            $progress = $false
            foreach ($stream in @('stdout','stderr')) {
                $task = if ($stream -eq 'stdout') { $outTask } else { $errTask }
                if ($null -eq $task -or -not $task.IsCompleted) { continue }
                $line = $task.GetAwaiter().GetResult()
                $progress = $true
                if ($null -eq $line) {
                    if ($stream -eq 'stdout') { $outTask = $null } else { $errTask = $null }
                    continue
                }
                if ($stream -eq 'stderr') { $log.WriteLine('[stderr] ' + $line) }
                else { $log.WriteLine($line) }
                if ($CaptureOutput) {
                    if ($stream -eq 'stdout') { $outLines.Add($line) }
                    else { $errLines.Add($line) }
                }
                $display = $OutputMode -eq 'All' -or ($OutputMode -eq 'Build' -and (
                    $stream -eq 'stderr' -or $line -match '\[[0-9]+/[0-9]+\]|Building|Built target|Linking|\.cpp|\.c\b|warning|error|fatal|LNK|failed|MSBuild|^\s*[0-9]+>'
                ))
                if ($display) {
                    if ($line -match '(?i)error|fatal|failed') { Write-Host $line -ForegroundColor Red }
                    elseif ($line -match '(?i)warning') { Write-Host $line -ForegroundColor Yellow }
                    else { Write-Host $line }
                }
                if ($stream -eq 'stdout') { $outTask = $process.StandardOutput.ReadLineAsync() }
                else { $errTask = $process.StandardError.ReadLineAsync() }
            }
            if (-not $progress) { Start-Sleep -Milliseconds 20 }
        }
        $process.WaitForExit()
        $exitCode = $process.ExitCode
        $log.WriteLine('--- exit code: ' + $exitCode + ' ---')
        return [pscustomobject]@{
            ExitCode = $exitCode
            TimedOut = $timedOut
            LogPath  = $LogPath
            StdOut   = ($outLines -join "`n")
            StdErr   = ($errLines -join "`n")
        }
    } finally {
        if ($process) {
            if ($started -and -not $process.HasExited) {
                try { $process.Kill(); $process.WaitForExit() } catch {}
            }
            $process.Dispose()
        }
        if ($log) { $log.Dispose() }
    }
}
