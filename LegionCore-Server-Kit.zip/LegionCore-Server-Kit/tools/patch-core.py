#!/usr/bin/env python3
"""
Apply or revert the PlayerBots core patch.

Real player-bots need a WorldSession with no socket. WorldSession::Update ends
with an unconditional

    if (!m_Socket[CONNECTION_TYPE_REALM])
        return false;          // Will remove this session from the world session map

and both callers - World::UpdateSessions and Map::Update - respond by calling
LogoutPlayer(true) and erasing the session. A socket-less bot would therefore
log itself out on the very next tick.

This adds an explicit opt-in flag and makes that one condition respect it.
Nothing else in the engine changes, and a session without the flag behaves
exactly as before.

    patch-core.py apply  <source-root>
    patch-core.py revert <source-root>
    patch-core.py check  <source-root>

Idempotent: applying twice is a no-op, and revert restores the original bytes.
"""
import sys
import pathlib
import hashlib

MARK = "PlayerBots:"

HDR_ANCHOR = "        bool PlayerLoading() const { return !m_playerLoading.IsEmpty(); }"
HDR_ADD = """
        // PlayerBots: a bot session owns no socket. Flagging it keeps
        // WorldSession::Update from treating the missing socket as a dropped
        // connection. Untouched for every normal session.
        bool IsBot() const { return _isBot; }
        void SetBot(bool on) { _isBot = on; }

        // PlayerBots: begin login for a bot character. The normal path is
        // driven by CMSG_PLAYER_LOGIN followed by the client reconnecting on
        // the instance socket; a bot has no client, so it sets the pending
        // guid and continues directly.
        void BotLogin(ObjectGuid guid) { m_playerLoading = guid; HandleContinuePlayerLogin(); }

        // PlayerBots: the client clears the loading state with the load-screen
        // packet. Without this a bot stays "logging in" forever.
        void BotFinishLogin() { m_playerLoading.Clear(); }
"""
# Full line including its trailing comment: anchoring on the prefix alone would
# insert mid-line and split that comment onto a line of its own.
HDR_FIELD_ANCHOR = "        bool m_playerLogout;                                // code processed in LogoutPlayer"
HDR_FIELD_ADD = "        bool _isBot = false;                                // PlayerBots: socket-less bot session\n"

CPP_OLD = """        if (!m_Socket[CONNECTION_TYPE_REALM])
        {
            m_sUpdate = false;
            return false;                                       //Will remove this session from the world session map
        }"""
CPP_NEW = """        // PlayerBots: a bot session legitimately has no socket, so an absent
        // one must not be read as a dropped connection.
        if (!m_Socket[CONNECTION_TYPE_REALM] && !IsBot())
        {
            m_sUpdate = false;
            return false;                                       //Will remove this session from the world session map
        }"""


def files(root):
    root = pathlib.Path(root)
    return (root / "src/server/game/Server/WorldSession.h",
            root / "src/server/game/Server/WorldSession.cpp")


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()[:16]


def state(root):
    hdr, cpp = files(root)
    for p in (hdr, cpp):
        if not p.is_file():
            return "missing", f"{p} not found"
    h, c = hdr.read_text(encoding="utf-8", errors="surrogateescape"), \
           cpp.read_text(encoding="utf-8", errors="surrogateescape")
    hp, cp = "bool IsBot() const" in h, "!IsBot()" in c
    if hp and cp:
        return "applied", "both files carry the patch"
    if not hp and not cp:
        return "clean", "neither file is patched"
    return "partial", f"header patched={hp}, source patched={cp}"


def apply(root):
    st, why = state(root)
    if st == "applied":
        print(f"[ok] already applied ({why})")
        return 0
    if st == "missing":
        print(f"[xx] {why}")
        return 1
    if st == "partial":
        print(f"[xx] refusing to touch a half-patched tree: {why}")
        print("     restore the .before-playerbots backups, or re-extract the core source")
        return 1

    hdr, cpp = files(root)
    for p in (hdr, cpp):
        b = p.with_suffix(p.suffix + ".before-playerbots")
        if not b.exists():
            b.write_bytes(p.read_bytes())

    h = hdr.read_text(encoding="utf-8", errors="surrogateescape")
    if HDR_ANCHOR not in h:
        print("[xx] header anchor not found - core version differs from the one this patch targets")
        return 1
    h = h.replace(HDR_ANCHOR, HDR_ANCHOR + "\n" + HDR_ADD, 1)
    if HDR_FIELD_ANCHOR not in h:
        print("[xx] header field anchor not found")
        return 1
    h = h.replace(HDR_FIELD_ANCHOR, HDR_FIELD_ANCHOR + "\n" + HDR_FIELD_ADD, 1)
    hdr.write_text(h, encoding="utf-8", errors="surrogateescape")

    c = cpp.read_text(encoding="utf-8", errors="surrogateescape")
    if CPP_OLD not in c:
        print("[xx] source anchor not found - core version differs from the one this patch targets")
        return 1
    c = c.replace(CPP_OLD, CPP_NEW, 1)
    cpp.write_text(c, encoding="utf-8", errors="surrogateescape")

    print(f"[ok] patched WorldSession.h  ({sha(hdr)})")
    print(f"[ok] patched WorldSession.cpp ({sha(cpp)})")
    print("     backups: *.before-playerbots")
    return 0


def revert(root):
    hdr, cpp = files(root)
    done = 0
    for p in (hdr, cpp):
        b = p.with_suffix(p.suffix + ".before-playerbots")
        if b.exists():
            p.write_bytes(b.read_bytes())
            b.unlink()
            print(f"[ok] restored {p.name}")
            done += 1
        else:
            print(f"[!!] no backup for {p.name}, left as is")
    return 0 if done else 1


if __name__ == "__main__":
    if len(sys.argv) != 3 or sys.argv[1] not in ("apply", "revert", "check"):
        print(__doc__)
        sys.exit(2)
    cmd, root = sys.argv[1], sys.argv[2]
    if cmd == "check":
        st, why = state(root)
        print(f"{st}: {why}")
        sys.exit(0 if st in ("applied", "clean") else 1)
    sys.exit(apply(root) if cmd == "apply" else revert(root))
