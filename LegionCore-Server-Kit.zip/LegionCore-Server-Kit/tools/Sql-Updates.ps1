<#
================================================================================
 Sql-Updates.ps1 - shared helpers for the core's SQL update bookkeeping
================================================================================
 worldserver/bnetserver keep a row per applied .sql file in each database's
 `updates` table, together with a SHA1 of the file. On every start they hash the
 files again and re-apply the ones whose hash changed.

 The core reads those files with a text-mode std::ifstream (UpdateFetcher.cpp,
 ReadSQLUpdate) and hashes the result with CalculateSHA1Hash. On Windows a
 text-mode read turns every CRLF into a single LF before the hash is taken, so
 the stored hash must be the hash of the LF form of the file - NOT the hash of
 the bytes on disk, which is what Get-FileHash returns for a CRLF checkout.
================================================================================
#>

function Get-LegionSqlUpdateHash {
    <#
    Returns the SHA1 the core computes for one .sql file: CRLF collapsed to LF,
    content cut at a Ctrl-Z (the text-mode end-of-file marker), uppercase hex.
    #>
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][string]$Path)

    $bytes = [IO.File]::ReadAllBytes($Path)
    # Latin-1 maps every byte 0x00-0xFF to one char and back without loss, so
    # the text replacement below cannot corrupt non-UTF8 bytes.
    $latin1 = [Text.Encoding]::GetEncoding(28591)
    $text = $latin1.GetString($bytes)
    $eof = $text.IndexOf([char]0x1A)
    if ($eof -ge 0) { $text = $text.Substring(0, $eof) }
    $text = $text.Replace("`r`n", "`n")
    $sha1 = [Security.Cryptography.SHA1]::Create()
    try { $digest = $sha1.ComputeHash($latin1.GetBytes($text)) } finally { $sha1.Dispose() }
    return ([BitConverter]::ToString($digest) -replace '-', '').ToUpperInvariant()
}

function Get-LegionSqlFileHashRaw {
    <#
    SHA1 of the bytes exactly as they are on disk. Only used to recognise the
    old, wrong hashes written by earlier versions of 3-Setup-Databases.ps1.
    #>
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][string]$Path)
    $sha1 = [Security.Cryptography.SHA1]::Create()
    try { $digest = $sha1.ComputeHash([IO.File]::ReadAllBytes($Path)) } finally { $sha1.Dispose() }
    return ([BitConverter]::ToString($digest) -replace '-', '').ToUpperInvariant()
}

function Get-LegionUpdatesSourceDir {
    <#
    The folder the core itself uses for SQL updates: Updates.SourcePath from
    worldserver.conf when it is set, otherwise the fallback passed in.
    #>
    [CmdletBinding()]
    param(
        [AllowEmptyString()][string]$ConfigPath = '',
        [AllowEmptyString()][string]$Fallback = ''
    )
    if ($ConfigPath -and (Test-Path -LiteralPath $ConfigPath)) {
        foreach ($line in (Get-Content -LiteralPath $ConfigPath)) {
            if ($line -match '^\s*Updates\.SourcePath\s*=\s*"?([^"]*?)"?\s*$') {
                $value = $Matches[1].Trim()
                if ($value) { return [pscustomobject]@{ Path = $value; Source = "Updates.SourcePath in $(Split-Path $ConfigPath -Leaf)" } }
            }
        }
    }
    return [pscustomobject]@{ Path = $Fallback; Source = 'kit-config.ps1' }
}

function Get-LegionSqlUpdateFiles {
    <#
    Builds the same file list the core builds: every .sql file under each
    directory from `updates_include` (recursively, max depth 10), keyed by file
    name. Duplicate names are fatal for the core, so they are reported.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][object[]]$IncludeDirectories,   # objects with Path + State
        [Parameter(Mandatory = $true)][string]$SourceDir
    )
    $files = [ordered]@{}
    $duplicates = @()
    $missingDirs = @()
    foreach ($entry in $IncludeDirectories) {
        $raw = [string]$entry.Path
        $dir = if ($raw.StartsWith('$')) { Join-Path $SourceDir $raw.Substring(1).TrimStart('/', '\') } else { $raw }
        if (-not (Test-Path -LiteralPath $dir -PathType Container)) { $missingDirs += $dir; continue }
        foreach ($file in (Get-ChildItem -LiteralPath $dir -Recurse -File -Filter '*.sql' -Depth 9 -ErrorAction SilentlyContinue)) {
            if ($files.Contains($file.Name)) {
                $duplicates += [pscustomobject]@{ Name = $file.Name; First = $files[$file.Name].Path; Second = $file.FullName }
                continue
            }
            $files[$file.Name] = [pscustomobject]@{ Name = $file.Name; Path = $file.FullName; State = $entry.State; Directory = $dir }
        }
    }
    return [pscustomobject]@{ Files = $files; Duplicates = $duplicates; MissingDirectories = $missingDirs }
}
