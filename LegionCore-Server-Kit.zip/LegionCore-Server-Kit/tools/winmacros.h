#ifndef WINMACROS_EMULATION_H
#define WINMACROS_EMULATION_H
/* WinDef.h defines these as empty macros on every MSVC build. Any identifier
   with one of these names silently vanishes. NOMINMAX does not affect them. */
#define near
#define far
#define pascal
#endif
