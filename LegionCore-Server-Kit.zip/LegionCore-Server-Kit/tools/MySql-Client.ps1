<#
LegionCore kit - MySQL client transport (Windows PowerShell 5.1 compatible).

Do not invoke mysql.exe with a command-line password, merge stderr into query
results, or let a native stderr warning decide whether a query succeeded.

This helper uses a private temporary option file, streams SQL through stdin,
reads stdout/stderr separately using System.Diagnostics.Process, and reports the
actual exit code. The option file is removed in finally. SQL imports are streamed,
not loaded into memory. Windows ACL setup is intentionally fail-closed.
#>
#Requires -Version 5.1

function ConvertTo-LegionMySqlOption {
    param([AllowEmptyString()][string]$Value)
    if ($Value.IndexOf([char]0) -ge 0) { throw 'A MySQL option cannot contain a NUL character.' }
    $escaped = $Value.Replace('\', '\\').Replace('"', '\"').Replace("`r", '\r').Replace("`n", '\n').Replace("`t", '\t')
    return ('"' + $escaped + '"')
}

function ConvertTo-LegionNativeArgument {
    param([AllowEmptyString()][string]$Value)
    if ($Value.IndexOf([char]0) -ge 0) { throw 'A process argument cannot contain a NUL character.' }
    # Quote every argument using the Windows CRT rules. This also works with
    # ProcessStartInfo.Arguments on .NET used by PowerShell 7 in Linux tests.
    $escaped = [regex]::Replace($Value, '(\\*)"', '$1$1\"')
    $escaped = [regex]::Replace($escaped, '(\\+)$', '$1$1')
    return ('"' + $escaped + '"')
}

function New-LegionPrivateDirectory {
    param([string]$Path)
    [IO.Directory]::CreateDirectory($Path) | Out-Null
    if ($env:OS -eq 'Windows_NT') {
        $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User
        $acl = New-Object Security.AccessControl.DirectorySecurity
        $acl.SetOwner($sid)
        $acl.SetAccessRuleProtection($true, $false)
        foreach ($identity in @($sid, (New-Object Security.Principal.SecurityIdentifier 'S-1-5-18'))) {
            $rule = New-Object Security.AccessControl.FileSystemAccessRule -ArgumentList @(
                $identity,
                [Security.AccessControl.FileSystemRights]::FullControl,
                ([Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [Security.AccessControl.InheritanceFlags]::ObjectInherit),
                [Security.AccessControl.PropagationFlags]::None,
                [Security.AccessControl.AccessControlType]::Allow
            )
            $acl.AddAccessRule($rule)
        }
        Set-Acl -LiteralPath $Path -AclObject $acl -ErrorAction Stop
    } else {
        # Only used for the Linux/PowerShell 7 test environment, not Windows 5.1.
        [IO.File]::SetUnixFileMode($Path, ([IO.UnixFileMode]::UserRead -bor [IO.UnixFileMode]::UserWrite -bor [IO.UnixFileMode]::UserExecute))
    }
}

# Locate a mysql client. Historically each numbered script defined its own copy
# of this; it now lives here so every script - including older ones that only
# dot-source this file - can rely on it being present.
function Find-MySqlClient {
    param([string]$MySqlRoot = $(if (Get-Variable -Name MySqlRoot -Scope Global -ErrorAction SilentlyContinue) { $global:MySqlRoot } else { '' }))
    $cand = @()
    if ($MySqlRoot) { $cand += (Join-Path $MySqlRoot 'bin\mysql.exe') }
    $cand += @(
        "$env:ProgramFiles\MySQL\MySQL Server 8.0\bin\mysql.exe",
        "$env:ProgramFiles\MySQL\MySQL Server 8.4\bin\mysql.exe",
        "${env:ProgramFiles(x86)}\MySQL\MySQL Server 8.0\bin\mysql.exe"
    )
    foreach ($c in $cand) { if ($c -and (Test-Path $c)) { return $c } }
    foreach ($n in 'mysql.exe', 'mysql', 'mariadb') {
        $g = Get-Command $n -ErrorAction SilentlyContinue
        if ($g) { return $g.Source }
    }
    return $null
}

function Invoke-LegionMySql {
    [CmdletBinding(DefaultParameterSetName='Query')]
    param(
        [Parameter(Mandatory=$true)][string]$Executable,
        [string]$HostName = '127.0.0.1',
        [int]$Port = 3306,
        [string]$User = 'root',
        [AllowEmptyString()][string]$Password = '',
        [Parameter(Mandatory=$true, ParameterSetName='Query')][AllowEmptyString()][string]$Query,
        [Parameter(Mandatory=$true, ParameterSetName='Import')][string]$InputFile,
        [string]$Database = ''
    )
    if ($PSCmdlet.ParameterSetName -eq 'Import' -and -not (Test-Path -LiteralPath $InputFile -PathType Leaf)) {
        throw "SQL input file not found: $InputFile"
    }

    $privateDir = Join-Path ([IO.Path]::GetTempPath()) ('LegionCore-MySql-' + [Guid]::NewGuid().ToString('N'))
    $process = $null
    $started = $false
    $inputStream = $null
    try {
        New-LegionPrivateDirectory $privateDir
        $optionsFile = Join-Path $privateDir 'client.cnf'
        $options = @(
            '[client]',
            ('host=' + (ConvertTo-LegionMySqlOption $HostName)),
            ('port=' + $Port),
            ('user=' + (ConvertTo-LegionMySqlOption $User)),
            ('password=' + (ConvertTo-LegionMySqlOption $Password)),
            'default-character-set=utf8mb4',
            'max_allowed_packet=1G'
        ) -join "`n"
        $utf8 = New-Object Text.UTF8Encoding $false
        [IO.File]::WriteAllText($optionsFile, $options + "`n", $utf8)
        if ($env:OS -ne 'Windows_NT') {
            [IO.File]::SetUnixFileMode($optionsFile, ([IO.UnixFileMode]::UserRead -bor [IO.UnixFileMode]::UserWrite))
        }

        # --defaults-file must be the FIRST option. No password or SQL query is
        # present in the process command line, including ALTER USER statements.
        $arguments = @(('--defaults-file=' + $optionsFile), '--batch', '--skip-column-names', '--connect-timeout=5')
        if ($Database -ne '') { $arguments += $Database }
        $quotedArguments = @($arguments | ForEach-Object { ConvertTo-LegionNativeArgument $_ })
        $psi = New-Object Diagnostics.ProcessStartInfo
        $psi.FileName = $Executable
        $psi.Arguments = $quotedArguments -join ' '
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true
        $psi.RedirectStandardInput = $true
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true
        $psi.StandardOutputEncoding = $utf8
        $psi.StandardErrorEncoding = $utf8
        $process = New-Object Diagnostics.Process
        $process.StartInfo = $psi
        $started = $process.Start()
        if (-not $started) { throw 'Could not start the MySQL client.' }

        # Drain both streams concurrently to avoid a pipe-buffer deadlock.
        $stdoutTask = $process.StandardOutput.ReadToEndAsync()
        $stderrTask = $process.StandardError.ReadToEndAsync()
        $writeError = $null
        try {
            if ($PSCmdlet.ParameterSetName -eq 'Import') {
                $inputStream = [IO.File]::OpenRead((Resolve-Path -LiteralPath $InputFile).ProviderPath)
                $inputStream.CopyTo($process.StandardInput.BaseStream, 65536)
            } else {
                $bytes = $utf8.GetBytes($Query + "`n")
                $process.StandardInput.BaseStream.Write($bytes, 0, $bytes.Length)
            }
        } catch {
            # A client that exits early (e.g. access denied) can close stdin.
            # Retain its real exit code and diagnostic instead of losing them
            # behind a broken-pipe exception.
            $writeError = $_.Exception.Message
        } finally {
            if ($inputStream) { $inputStream.Dispose(); $inputStream = $null }
            try { $process.StandardInput.Close() } catch { if (-not $writeError) { $writeError = $_.Exception.Message } }
        }
        $process.WaitForExit()
        $stdout = $stdoutTask.GetAwaiter().GetResult()
        $stderr = $stderrTask.GetAwaiter().GetResult()
        $exitCode = $process.ExitCode
        if ($writeError -and $exitCode -eq 0) {
            throw "MySQL exited successfully but SQL input could not be fully sent: $writeError"
        }
        return [pscustomobject]@{
            ExitCode = $exitCode
            StdOut   = $stdout
            StdErr   = $stderr
        }
    } finally {
        if ($inputStream) { $inputStream.Dispose() }
        if ($process) {
            if ($started -and -not $process.HasExited) {
                try { $process.Kill(); $process.WaitForExit() } catch {}
            }
            $process.Dispose()
        }
        if (Test-Path -LiteralPath $privateDir) {
            Remove-Item -LiteralPath $privateDir -Recurse -Force -ErrorAction Stop
        }
    }
}
