# Static guard: every command invoked by every kit script must resolve to
# a function defined in that script, a function in a file it dot-sources,
# an external .exe/.bat the kit ships or installs, or a real cmdlet.
# This is the check that would have caught the Find-MySqlClient crash.
param([string]$KitRoot = '/home/user/LegionCore-Server-Kit')

$ExternalAllowed = @('cmake','ninja','git','mysql','mysqld','msbuild','cmd','robocopy','7z','curl','powershell','pwsh','openssl','worldserver','authserver','winget')

# Cmdlets that exist on Windows PowerShell but not on the Linux pwsh used to
# run this harness. They are real built-ins on the target machine, so they are
# not evidence of a missing helper. Anything NOT on this list and not defined
# anywhere is a genuine unresolved call (this is how Find-MySqlClient escaped).
$WindowsOnly = @(
    'Get-Acl','Set-Acl','Get-CimInstance','Invoke-CimMethod','Get-NetTCPConnection',
    'Get-Service','Start-Service','Stop-Service','Restart-Service','Set-Service',
    'New-Service','Get-WmiObject','Get-ScheduledTask','Register-ScheduledTask',
    'New-NetFirewallRule','Get-NetFirewallRule','Get-HotFix','Get-ComputerInfo'
)
$failures = 0
$scripts = Get-ChildItem -Path $KitRoot -Filter *.ps1 -Recurse | Sort-Object FullName

foreach ($s in $scripts) {
    $tokens = $null; $errors = $null
    $ast = [System.Management.Automation.Language.Parser]::ParseFile($s.FullName, [ref]$tokens, [ref]$errors)
    if ($errors.Count) {
        Write-Host "  [FAIL] $($s.Name): $($errors.Count) parse error(s)"
        $errors | ForEach-Object { Write-Host "         line $($_.Extent.StartLineNumber): $($_.Message)" }
        $failures++
        continue
    }

    # functions defined locally
    $defined = @($ast.FindAll({ param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst] }, $true) |
                 ForEach-Object { $_.Name })

    # follow dot-souradvanced files: . (Join-Path $PSScriptRoot 'tools\X.ps1')
    $sourced = @()
    foreach ($cmd in $ast.FindAll({ param($n) $n -is [System.Management.Automation.Language.CommandAst] }, $true)) {
        if ($cmd.InvocationOperator -ne 'Dot') { continue }
        $text = $cmd.Extent.Text
        if ($text -match "'([^']+\.ps1)'") {
            $rel = $Matches[1] -replace '\\', '/'
            $cand = Join-Path (Split-Path $s.FullName) $rel
            if (Test-Path $cand) { $sourced += (Resolve-Path $cand).Path }
        }
    }
    foreach ($f in ($sourced | Sort-Object -Unique)) {
        $a = [System.Management.Automation.Language.Parser]::ParseFile($f, [ref]$null, [ref]$null)
        $defined += @($a.FindAll({ param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst] }, $true) |
                      ForEach-Object { $_.Name })
    }

    $unresolved = @()
    foreach ($cmd in $ast.FindAll({ param($n) $n -is [System.Management.Automation.Language.CommandAst] }, $true)) {
        $name = $cmd.GetCommandName()
        if (-not $name) { continue }                       # & $variable - cannot check statically
        if ($name -match '^\$') { continue }
        $bare = [IO.Path]::GetFileNameWithoutExtension($name)
        if ($defined -contains $name) { continue }
        if ($ExternalAllowed -contains $bare.ToLower()) { continue }
        if ($WindowsOnly -contains $name) { continue }
        if (Get-Command $name -ErrorAction SilentlyContinue) { continue }
        $unresolved += "$name (line $($cmd.Extent.StartLineNumber))"
    }

    $rel = $s.FullName.Substring($KitRoot.Length).TrimStart('/','\')
    if ($unresolved.Count) {
        Write-Host "  [FAIL] $rel"
        $unresolved | Sort-Object -Unique | ForEach-Object { Write-Host "         unresolved: $_" }
        $failures++
    } else {
        Write-Host ("  [ok]   {0,-34} {1,3} commands, all resolve" -f $rel, @($ast.FindAll({ param($n) $n -is [System.Management.Automation.Language.CommandAst] }, $true)).Count)
    }
}

Write-Host ''
if ($failures) { Write-Host "  $failures script(s) FAILED"; exit 1 }
Write-Host "  all $($scripts.Count) kit scripts pass"; exit 0
