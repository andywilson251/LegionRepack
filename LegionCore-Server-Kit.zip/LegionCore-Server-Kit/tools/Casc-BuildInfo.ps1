<#
Rebuilds the CASC storage metadata (".build.info") that the extraction tools
need when a client folder does not contain one.

Nothing is downloaded and the client's game data is never modified: the build
and CDN configuration files that already exist inside <client>\Data\config are
located, MD5-verified exactly the way the bundled CascLib verifies them, and
then referenced from a small generated text file. If the client folder cannot
be written to, a separate "shadow root" folder is used instead, which only
contains the generated file plus a directory link to the client's Data folder.

Column/field layout follows CascLib's ParseFile_BuildInfo() in
dep/CascLib/src/CascFiles.cpp (Active/Build Key/CDN Key/CDN Hosts/CDN Path/Tags).
#>
#Requires -Version 5.1

# Locale tags understood by CascLib's GetLocaleMask().
$script:LegionCascLocales = [ordered]@{
    'enus' = 'enUS'; 'kokr' = 'koKR'; 'frfr' = 'frFR'; 'dede' = 'deDE'
    'zhcn' = 'zhCN'; 'zhtw' = 'zhTW'; 'eses' = 'esES'; 'esmx' = 'esMX'
    'ruru' = 'ruRU'; 'ptbr' = 'ptBR'; 'itit' = 'itIT'; 'ptpt' = 'ptPT'
    'engb' = 'enGB'; 'encn' = 'enCN'; 'entw' = 'enTW'
}

# Locales the extractors can actually select (WowLocaleToCascLocaleFlags).
$script:LegionToolLocales = @('enUS','koKR','frFR','deDE','zhCN','zhTW','esES','esMX','ruRU','ptBR','itIT','enGB')

function Get-LegionCascBuildNumber {
    <# Mirrors CascLib GetBuildNumber(): the first run of at least three digits. #>
    param([AllowEmptyString()][string]$BuildName)
    if ([string]::IsNullOrWhiteSpace($BuildName)) { return [uint32]0 }
    $match = [regex]::Match($BuildName, '[0-9]{3,}')
    if (-not $match.Success) { return [uint32]0 }
    [uint32]$value = 0
    if ([uint32]::TryParse($match.Value, [ref]$value)) { return $value }
    return [uint32]0
}

function Get-LegionCascConfigFiles {
    <#
    Returns every usable configuration file in <Data>\config, classified as a
    build configuration ("encoding = <ckey> <ekey>") or a CDN configuration
    ("archives = ..."), after verifying the CASC naming and MD5 rules.
    #>
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][string]$ConfigDir)

    $found = New-Object 'Collections.Generic.List[object]'
    $rejected = New-Object 'Collections.Generic.List[object]'
    if (-not (Test-Path -LiteralPath $ConfigDir)) { return [pscustomobject]@{ Files = $found; Rejected = $rejected } }
    $md5 = [Security.Cryptography.MD5]::Create()
    try {
        foreach ($file in Get-ChildItem -LiteralPath $ConfigDir -Recurse -File -ErrorAction SilentlyContinue) {
            $key = $file.Name.ToLowerInvariant()
            if ($key -notmatch '^[0-9a-f]{32}$') { continue }
            # CascLib only ever looks for config\<first 2>\<next 2>\<key>.
            $parent = Split-Path -Path $file.FullName -Parent
            $level2 = (Split-Path -Path $parent -Leaf).ToLowerInvariant()
            $level1 = (Split-Path -Path (Split-Path -Path $parent -Parent) -Leaf).ToLowerInvariant()
            if ($level1 -ne $key.Substring(0, 2) -or $level2 -ne $key.Substring(2, 2)) {
                $rejected.Add([pscustomobject]@{ Key = $key; Path = $file.FullName; Reason = 'not stored in the config\xx\yy\<key> layout CascLib looks up' })
                continue
            }
            if ($file.Length -lt 16 -or $file.Length -gt 4MB) {
                $rejected.Add([pscustomobject]@{ Key = $key; Path = $file.FullName; Reason = "unexpected size ($($file.Length) bytes) for a text configuration file" })
                continue
            }
            $bytes = [IO.File]::ReadAllBytes($file.FullName)
            $hash = ([BitConverter]::ToString($md5.ComputeHash($bytes)) -replace '-', '').ToLowerInvariant()
            if ($hash -ne $key) {
                # CascLib's ListFile_VerifyMD5() ignores files whose content does not hash to their name.
                $rejected.Add([pscustomobject]@{ Key = $key; Path = $file.FullName; Reason = "content MD5 $hash does not match the file name (damaged or incomplete file)" })
                continue
            }
            $text = [Text.Encoding]::ASCII.GetString($bytes)
            if ($text -match '[\x00-\x08\x0E-\x1F]') {
                $rejected.Add([pscustomobject]@{ Key = $key; Path = $file.FullName; Reason = 'binary content, not a text configuration file' })
                continue
            }
            $kind = $null
            if ($text -match '(?im)^[ \t]*encoding[ \t]*=[ \t]*([0-9a-f]{32})[ \t]+([0-9a-f]{32})') { $kind = 'build' }
            elseif ($text -match '(?im)^[ \t]*archives[ \t]*=[ \t]*[0-9a-f]{32}') { $kind = 'cdn' }
            else { continue }
            $buildName = ''
            if ($text -match '(?im)^[ \t]*build-name[ \t]*=[ \t]*(.+?)[ \t]*$') { $buildName = $Matches[1] }
            $buildUid = ''
            if ($text -match '(?im)^[ \t]*build-uid[ \t]*=[ \t]*(.+?)[ \t]*$') { $buildUid = $Matches[1] }
            $found.Add([pscustomobject]@{
                Key              = $key
                Kind             = $kind
                Path             = $file.FullName
                BuildName        = $buildName
                BuildUid         = $buildUid
                BuildNumber      = (Get-LegionCascBuildNumber $buildName)
                HasRoot          = [bool]($text -match '(?im)^[ \t]*root[ \t]*=[ \t]*[0-9a-f]{32}')
                LastWriteTimeUtc = $file.LastWriteTimeUtc
            })
        }
    } finally { $md5.Dispose() }
    return [pscustomobject]@{ Files = $found; Rejected = $rejected }
}

function Resolve-LegionClientLocale {
    <# Determines which locale tag to advertise in the generated .build.info. #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$ClientDir,
        [AllowEmptyString()][string]$RequestedLocale = ''
    )
    if (-not [string]::IsNullOrWhiteSpace($RequestedLocale)) {
        $key = $RequestedLocale.Trim().ToLowerInvariant()
        if (-not $script:LegionCascLocales.Contains($key)) {
            throw "Unknown client locale '$RequestedLocale'. Supported values: $($script:LegionCascLocales.Values -join ', ')."
        }
        return [pscustomobject]@{ Locale = $script:LegionCascLocales[$key]; Source = 'the -ClientLocale value you passed' }
    }
    $configWtf = Join-Path $ClientDir 'WTF\Config.wtf'
    if (Test-Path -LiteralPath $configWtf) {
        foreach ($line in (Get-Content -LiteralPath $configWtf -ErrorAction SilentlyContinue)) {
            if ($line -match '^\s*SET\s+(?:text|audio)?locale\s+"?([A-Za-z]{4})"?') {
                $key = $Matches[1].ToLowerInvariant()
                if ($script:LegionCascLocales.Contains($key)) {
                    return [pscustomobject]@{ Locale = $script:LegionCascLocales[$key]; Source = 'WTF\Config.wtf' }
                }
            }
        }
    }
    foreach ($base in @((Join-Path $ClientDir 'Data'), $ClientDir)) {
        foreach ($value in $script:LegionCascLocales.Values) {
            if (Test-Path -LiteralPath (Join-Path $base $value)) {
                return [pscustomobject]@{ Locale = $value; Source = "the $value folder in $base" }
            }
        }
    }
    return [pscustomobject]@{ Locale = 'enUS'; Source = 'default (no locale information found in the client)' }
}

function Get-LegionClientCascLayout {
    <# Resolves the client folder the way CascLib walks up from <client>\Data. #>
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][string]$ClientDir)

    if (-not (Test-Path -LiteralPath $ClientDir)) { throw "Client folder not found: $ClientDir" }
    $root = (Resolve-Path -LiteralPath $ClientDir).ProviderPath.TrimEnd('\', '/')
    $dataDir = Join-Path $root 'Data'
    if (-not (Test-Path -LiteralPath $dataDir)) { throw "Client folder has no Data sub-folder: $root" }
    $existing = $null
    $search = $dataDir
    while ($search) {
        foreach ($name in '.build.info', '.build.db') {
            $candidate = Join-Path $search $name
            if ((Test-Path -LiteralPath $candidate -PathType Leaf) -and -not $existing) {
                $existing = [pscustomobject]@{ Path = $candidate; Directory = $search; Length = (Get-Item -LiteralPath $candidate -Force).Length }
            }
        }
        $search = Split-Path -Path $search -Parent
    }
    return [pscustomobject]@{
        Root              = $root
        DataDir           = $dataDir
        ConfigDir         = (Join-Path $dataDir 'config')
        IndexDir          = (Join-Path $dataDir 'data')
        ExistingBuildFile = $existing
    }
}

function New-LegionCascBuildInfoText {
    <#
    Builds the .build.info text. CDN host/path are only used by CascLib to
    compose an URL string it never requests locally, but ParseFile_BuildInfo
    rejects the file when they are empty, so placeholders are written.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][ValidatePattern('^[0-9a-f]{32}$')][string]$BuildKey,
        [Parameter(Mandatory = $true)][ValidatePattern('^[0-9a-f]{32}$')][string]$CdnKey,
        [Parameter(Mandatory = $true)][string]$Locale,
        [AllowEmptyString()][string]$Version = ''
    )
    $header = 'Branch!STRING:0|Active!DEC:1|Build Key!HEX:16|CDN Key!HEX:16|CDN Hosts!STRING:0|CDN Path!STRING:0|Tags!STRING:0|Version!STRING:0'
    $values = 'us|1|{0}|{1}|level3.blizzard.com|tpr/wow|Windows x86_64 {2}|{3}' -f $BuildKey, $CdnKey, $Locale, $Version
    return ($header + "`r`n" + $values + "`r`n")
}

function New-LegionShadowClientRoot {
    <#
    Creates a folder that contains the generated .build.info plus a directory
    link to the real client Data folder, for clients that must stay untouched.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$ClientDataDir,
        [Parameter(Mandatory = $true)][string]$ShadowRootDir
    )
    New-Item -ItemType Directory -Force -Path $ShadowRootDir | Out-Null
    $link = Join-Path $ShadowRootDir 'Data'
    $item = Get-Item -LiteralPath $link -Force -ErrorAction SilentlyContinue
    if ($item) {
        $isLink = [bool]($item.Attributes -band [IO.FileAttributes]::ReparsePoint)
        if (-not $isLink) {
            throw "$link already exists and is a real folder. Remove it yourself (it is not a link, so it may contain files) or pass a different shadow root."
        }
        $target = @($item.Target) | Select-Object -First 1
        if ($target -and ($target.TrimEnd('\', '/') -eq $ClientDataDir.TrimEnd('\', '/'))) { return $ShadowRootDir }
        [IO.Directory]::Delete($link, $false)   # removes only the link, never the client data
    }
    # A junction needs no administrator rights on Windows and is the first
    # choice there; elsewhere a symbolic link is the one that works. Some
    # platforms fail silently instead of raising an error, so each attempt is
    # verified by looking through the link before it is accepted.
    $firstChild = Get-ChildItem -LiteralPath $ClientDataDir -Force -ErrorAction SilentlyContinue | Select-Object -First 1
    $probeChild = if ($firstChild) { [string]$firstChild.Name } else { '' }
    $onWindows = $IsWindows -or ($PSVersionTable.PSVersion.Major -lt 6)
    $strategies = if ($onWindows) { @('Junction', 'SymbolicLink') } else { @('SymbolicLink', 'Junction') }
    $problems = @()
    foreach ($strategy in $strategies) {
        try { New-Item -ItemType $strategy -Path $link -Value $ClientDataDir -ErrorAction Stop | Out-Null }
        catch { $problems += "$strategy : $($_.Exception.Message)" }
        $linked = Test-Path -LiteralPath $link -PathType Container
        if ($linked -and $probeChild) { $linked = Test-Path -LiteralPath (Join-Path $link $probeChild) }
        if ($linked) { return $ShadowRootDir }
        if (Test-Path -LiteralPath $link) {
            $stale = Get-Item -LiteralPath $link -Force -ErrorAction SilentlyContinue
            if ($stale -and ($stale.Attributes -band [IO.FileAttributes]::ReparsePoint)) { [IO.Directory]::Delete($link, $false) }
        }
        if ($problems.Count -eq 0 -or $problems[-1] -notlike "$strategy :*") { $problems += "$strategy : no link was created" }
    }
    throw ("Could not link $link to $ClientDataDir ($($problems -join ' / ')).`n" +
           "Run this script as Administrator, or allow it to write .build.info into the client folder (drop -NoClientWrite).")
}

function Get-LegionCascRepairPlan {
    <#
    Inspects the client and returns what would be needed to rebuild .build.info:
    the ordered build-configuration candidates, the CDN configuration and the
    locale. Nothing is written by this function.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$ClientDir,
        [uint32]$PreferredBuild = 0,
        [AllowEmptyString()][string]$RequestedLocale = ''
    )
    $layout = Get-LegionClientCascLayout -ClientDir $ClientDir
    $locale = Resolve-LegionClientLocale -ClientDir $layout.Root -RequestedLocale $RequestedLocale
    $scan = Get-LegionCascConfigFiles -ConfigDir $layout.ConfigDir
    $builds = @($scan.Files | Where-Object { $_.Kind -eq 'build' } |
        Sort-Object -Property @{ Expression = { $PreferredBuild -gt 0 -and $_.BuildNumber -eq $PreferredBuild }; Descending = $true },
                              @{ Expression = { $_.HasRoot }; Descending = $true },
                              @{ Expression = { $_.BuildNumber }; Descending = $true },
                              @{ Expression = { $_.LastWriteTimeUtc }; Descending = $true })
    $cdn = @($scan.Files | Where-Object { $_.Kind -eq 'cdn' } | Sort-Object LastWriteTimeUtc -Descending) | Select-Object -First 1
    # A CDN configuration is optional: CascLib skips the file when it is absent.
    $cdnKey = if ($cdn) { $cdn.Key } else { '0' * 32 }
    return [pscustomobject]@{
        Layout          = $layout
        Locale          = $locale.Locale
        LocaleSource    = $locale.Source
        LocaleSupported = ($script:LegionToolLocales -contains $locale.Locale)
        BuildCandidates = $builds
        CdnConfig       = $cdn
        CdnKey          = $cdnKey
        Rejected        = $scan.Rejected
        IndexDirPresent = (Test-Path -LiteralPath $layout.IndexDir)
        # CascLib crashes instead of reporting an error when the index folder
        # holds no .idx files, so the caller has to check this up front.
        IndexFileCount  = @(Get-ChildItem -LiteralPath $layout.IndexDir -File -Filter '*.idx' -ErrorAction SilentlyContinue).Count
    }
}

function Write-LegionCascBuildInfo {
    <#
    Writes the generated .build.info for one build-configuration candidate and
    returns the storage root to hand to the extraction tools.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][object]$Plan,
        [Parameter(Mandatory = $true)][object]$Candidate,
        [AllowEmptyString()][string]$ShadowRootDir = '',
        [switch]$NoClientWrite
    )
    $version = ''
    if ($Candidate.BuildNumber -gt 0) { $version = "7.3.5.$($Candidate.BuildNumber)" }
    $text = New-LegionCascBuildInfoText -BuildKey $Candidate.Key -CdnKey $Plan.CdnKey -Locale $Plan.Locale -Version $version
    $utf8 = New-Object Text.UTF8Encoding $false
    $target = $null
    $mode = 'client'
    if (-not $NoClientWrite) {
        $candidatePath = Join-Path $Plan.Layout.Root '.build.info'
        try {
            [IO.File]::WriteAllText($candidatePath, $text, $utf8)
            $target = $candidatePath
        } catch {
            Write-Verbose "Could not write $candidatePath ($($_.Exception.Message)); using a shadow root instead."
        }
    }
    if (-not $target) {
        if ([string]::IsNullOrWhiteSpace($ShadowRootDir)) { throw 'The client folder is not writable and no shadow root folder was provided.' }
        $root = New-LegionShadowClientRoot -ClientDataDir $Plan.Layout.DataDir -ShadowRootDir $ShadowRootDir
        $target = Join-Path $root '.build.info'
        [IO.File]::WriteAllText($target, $text, $utf8)
        $mode = 'shadow'
    }
    $written = [IO.File]::ReadAllText($target)
    if ($written -cne $text) { throw "Verification of the generated $target failed: the file on disk does not match what was written." }
    return [pscustomobject]@{
        StorageRoot = (Split-Path -Path $target -Parent)
        BuildInfo   = $target
        Mode        = $mode
        BuildKey    = $Candidate.Key
        CdnKey      = $Plan.CdnKey
        Locale      = $Plan.Locale
        BuildNumber = $Candidate.BuildNumber
        Text        = $text
    }
}
