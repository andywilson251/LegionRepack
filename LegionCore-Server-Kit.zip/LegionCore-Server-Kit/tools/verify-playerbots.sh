#!/usr/bin/env bash
# PlayerBots module verification.
#
#  1. compiles every module translation unit against the real LegionCore headers
#  2. compiles them AGAIN with the <windows.h> macro pollution MSVC always has
#     (this is what catches error C2513 / C2059 from a name like 'near')
#  3. lexical scan for identifiers that collide with a Windows macro
#  4. lexical scan for GCC-only extensions MSVC would reject
#  5. every std:: facility used has its header included explicitly
#  6. no symbol the module declares is left undefined
#  7. every core function the module calls exists in the core
#  8. the generated SQL against the REAL world schema on MySQL 8, strict mode
#  9. static AST walk of every kit script: no call to an undefined helper
# 10. 7-Install-PlayerBots.ps1 end to end against a live database
#
# Run tools/harness-setup.sh first. This is a Linux/GCC cross-check of code
# destined for Windows/MSVC: it is not an MSVC build and it does not run the
# server.

set -u

CORE=${CORE:-/home/user/core-repo}
MOD=$CORE/src/server/scripts/Custom/PlayerBots
GEN=${GEN:-/tmp/botgen}
OBJ=/tmp/botobj
HERE=$(cd "$(dirname "$0")" && pwd)
KIT=$(cd "$HERE/.." && pwd)
SRC=$KIT/module/PlayerBots
MBIN=$(dirname "$(find /home/user/.cache/legion-repair -maxdepth 4 -type f -name mysql -perm -u+x 2>/dev/null | head -1)")
PWSH=/home/user/.cache/legion-repair/pwsh/pwsh
DBPORT=3307
DBPASS='TestPass123!'
PASS=0; FAIL=0

ok()  { echo "PASS: $1"; PASS=$((PASS+1)); }
bad() { echo "FAIL: $1"; FAIL=$((FAIL+1)); }

if [ ! -f "$CORE/src/server/game/Entities/Creature/Creature.h" ] || [ ! -f "$CORE/src/server/game/Server/WorldSession.cpp" ]; then
    echo "FAIL: $CORE is not a LegionCore checkout - run tools/harness-setup.sh first"
    exit 1
fi
mkdir -p "$OBJ" "$MOD"; rm -f "$OBJ"/*.o
cp "$SRC"/*.cpp "$SRC"/*.h "$MOD"/ 2>/dev/null
mapfile -t INCS < "$GEN/incs.txt"
FORCE=(-include map -include set -include unordered_map -include unordered_set -include atomic -include string -include vector -include list -include deque)

compile() {   # $1 = basename, $2 = plain|winmacros
    local extra=()
    [ "$2" = "winmacros" ] && extra=(-include "$GEN/winmacros.h")
    g++ -std=c++17 -Wall -Wextra -c -o "$OBJ/$1.$2.o" -I"$GEN" "${INCS[@]}" \
        "${FORCE[@]}" "${extra[@]}" "$MOD/$1.cpp" 2>&1
}

echo "=== 1-2. compile each file, plain and with windows.h macro pollution ==="
for mode in plain winmacros; do
    n=0
    for f in PlayerBotMgr PlayerBotWandererAI PlayerBotScripts PlayerBotReal; do
        out=$(compile "$f" "$mode"); rc=$?
        mine=$(echo "$out" | grep -E 'PlayerBots/[A-Za-z]+\.(cpp|h):[0-9]+:[0-9]+: (warning|error)')
        if [ $rc -eq 0 ] && [ -z "$mine" ]; then n=$((n+1)); else
            echo "    $f.cpp ($mode):"; echo "$mine" | head -5 | sed 's/^/      /'
        fi
    done
    [ "$n" -eq 4 ] && ok "all 4 files compile clean ($mode)" || bad "$((4-n)) file(s) failed to compile ($mode)"
done

echo
echo "=== 3. identifiers that collide with a Windows macro ==="
# <windows.h> defines near/far/pascal as EMPTY. An identifier with one of those
# names simply disappears on MSVC, which is what broke the first build.
# Comments and string literals are blanked first - macros do not expand there.
rm -rf /tmp/vb_stripped && mkdir -p /tmp/vb_stripped
for f in "$SRC"/*.cpp "$SRC"/*.h; do
    python3 "$HERE/strip-code.py" "$f" > "/tmp/vb_stripped/$(basename "$f")"
done
hits=0
for m in near far pascal cdecl huge small interface; do
    out=$(grep -nE "\b$m\b" /tmp/vb_stripped/* 2>/dev/null)
    if [ -n "$out" ]; then echo "$out" | sed 's/^/    /'; hits=$((hits+1)); fi
done
[ "$hits" -eq 0 ] && ok "no identifier collides with an empty Windows macro" \
                  || bad "$hits identifier(s) would be erased by <windows.h>"

# min/max are function-like macros; NOMINMAX is set by this core, but explicit
# template arguments make the call sites immune either way.
bare=$(grep -nE 'std::(min|max)\(' /tmp/vb_stripped/* 2>/dev/null)
[ -z "$bare" ] && ok "every std::min/std::max call uses explicit template arguments" \
               || { echo "$bare" | sed 's/^/    /'; bad "bare std::min(/std::max( would break if NOMINMAX were ever dropped"; }

echo "=== 4. GCC-only extensions MSVC would reject ==="
ext=0
for pat in '__attribute__' '\btypeof\s*\(' '__builtin_' '#pragma GCC' '#warning'; do
    out=$(grep -nE "$pat" /tmp/vb_stripped/* 2>/dev/null)
    [ -n "$out" ] && { echo "$out" | sed 's/^/    /'; ext=$((ext+1)); }
done
[ "$ext" -eq 0 ] && ok "no GCC-only extension in the module sources" || bad "$ext GCC-only construct(s) present"

echo
echo "=== 5. every std:: facility used has its header included ==="
miss=0
declare -A NEEDS=( [cos]=cmath [sin]=cmath [sqrt]=cmath [floor]=cmath [ceil]=cmath
                   [min]=algorithm [max]=algorithm [sort]=algorithm
                   [swap]=utility [vector]=vector [string]=string
                   [unordered_map]=unordered_map [unordered_set]=unordered_set [map]=map [set]=set )
for f in "$SRC"/*.cpp; do
    hdrs=$(grep -oE '#include <[a-z_]+>' "$f" | sed 's/#include <//; s/>//')
    # headers reachable through PlayerBots.h count as included
    hdrs="$hdrs $(grep -oE '#include <[a-z_]+>' "$SRC/PlayerBots.h" | sed 's/#include <//; s/>//')"
    for sym in $(grep -oE 'std::[a-z_]+' "$f" | sed 's/std:://' | sort -u); do
        want=${NEEDS[$sym]:-}
        [ -z "$want" ] && continue
        echo "$hdrs" | tr ' ' '\n' | grep -qx "$want" || {
            echo "    $(basename "$f"): uses std::$sym but never includes <$want>"; miss=$((miss+1)); }
    done
done
[ "$miss" -eq 0 ] && ok "no std:: facility relies on a transitive include" || bad "$miss missing include(s)"

echo
echo "=== 6. every symbol the module declares is implemented ==="
nm -C --undefined-only "$OBJ"/*.plain.o 2>/dev/null | grep -oE '\bPlayerBot[A-Za-z]*::[A-Za-z~]+' | sort -u > /tmp/vb_undef.txt
nm -C --defined-only  "$OBJ"/*.plain.o 2>/dev/null | grep -oE '\bPlayerBot[A-Za-z]*::[A-Za-z~]+' | sort -u > /tmp/vb_def.txt
left=$(comm -23 /tmp/vb_undef.txt /tmp/vb_def.txt | wc -l)
[ "$left" -eq 0 ] && ok "no PlayerBot* symbol is left undefined ($(wc -l < /tmp/vb_def.txt) defined)" \
                  || { comm -23 /tmp/vb_undef.txt /tmp/vb_def.txt | sed 's/^/    /'; bad "$left undefined symbol(s)"; }

echo
echo "=== 7. every core function the module calls exists in the core ==="
nm -C --undefined-only "$OBJ"/*.plain.o 2>/dev/null \
  | grep -oE '\b[A-Z][A-Za-z0-9_]*::[A-Za-z_][A-Za-z0-9_]*' \
  | grep -v '^PlayerBot' | sed 's/\[abi:cxx11\]//' | sort -u > /tmp/vb_core.txt
missing=0
while read -r sym; do
    cls=${sym%%::*}; fn=${sym##*::}
    grep -rqE "\b$fn\b" "$CORE/src" "$CORE/dep" --include='*.h' --include='*.cpp' --include='*.hpp' 2>/dev/null || {
        echo "    not found in the core: $sym"; missing=$((missing+1)); }
done < /tmp/vb_core.txt
[ "$missing" -eq 0 ] && ok "all $(wc -l < /tmp/vb_core.txt) core functions the module calls exist" \
                     || bad "$missing core function(s) not found"

echo
echo "=== 8. the generated SQL against the real world schema, MySQL 8 strict mode ==="
q() { "$MBIN/mysql" --protocol=TCP -h127.0.0.1 -P"$DBPORT" -uroot -p"$DBPASS" "$@" 2>/dev/null; }
MYSQLD_OK=
if [ -n "$MBIN" ] && q -e "SELECT 1" >/dev/null 2>&1; then MYSQLD_OK=1; fi

if [ -z "$MYSQLD_OK" ]; then
    echo "SKIP: no MySQL on 127.0.0.1:$DBPORT (groups 8 and 10 need it)"
else
    MODE=$(q -N -e "SELECT @@sql_mode;")
    case "$MODE" in *STRICT_TRANS_TABLES*) ok "server is in strict mode";;
                    *) bad "server is NOT in strict mode";; esac
    q -e "DROP DATABASE IF EXISTS worldtest; CREATE DATABASE worldtest;"
    cat /tmp/wdbtest/ct.sql /tmp/wdbtest/ctw.sql | q worldtest
    A=0; for i in 1 2 3; do q worldtest < "$KIT/sql/custom/world/2026_10_13_00_playerbots.sql" && A=$((A+1)); done
    [ "$A" -eq 3 ] && ok "applies cleanly three times (idempotent)" || bad "re-applying the SQL failed"
    C=$(q -N worldtest -e "SELECT CONCAT(
        (SELECT COUNT(*) FROM creature_template WHERE entry BETWEEN 800000 AND 800999),'/',
        (SELECT COUNT(*) FROM creature_template_wdb WHERE Entry BETWEEN 800000 AND 800999),'/',
        (SELECT COUNT(*) FROM playerbot_profile),'/',
        (SELECT COUNT(*) FROM playerbot_area),'/',
        (SELECT COUNT(*) FROM playerbot_rotation));")
    [ "$C" = "120/120/120/11/20" ] && ok "row counts: $C" || bad "unexpected row counts: $C"
    AOE=$(q -N worldtest -e "SELECT COUNT(*) FROM playerbot_rotation WHERE spell_id IN (6343,1680,122) AND \`condition\`=5;")
    [ "$AOE" = "3" ] && ok "all 3 area spells gated on 'several enemies nearby'" || bad "area spells not gated ($AOE of 3)"
fi

echo
echo "=== 9. every command in every kit script resolves to something real ==="
if [ -x "$PWSH" ]; then
    if OUT=$("$PWSH" -NoProfile -File "$HERE/check-commands.ps1" -KitRoot "$KIT" 2>&1); then
        echo "$OUT" | tail -2 | sed 's/^/    /'; ok "no kit script calls an undefined helper"
    else
        echo "$OUT" | sed 's/^/    /'; bad "a kit script calls a command that does not exist"
    fi
else
    echo "SKIP: pwsh not present"
fi

echo
echo "=== 10. the installer end to end against a live database ==="
if [ -z "$MYSQLD_OK" ] || [ ! -x "$PWSH" ]; then
    echo "SKIP: needs both MySQL and pwsh"
else
    rm -rf /tmp/bot_e2e_kit /tmp/bot_e2e_tree
    cp -r "$KIT" /tmp/bot_e2e_kit
    mkdir -p /tmp/bot_e2e_tree/source/src/server/scripts/Custom /tmp/bot_e2e_tree/source/sql/custom/world /tmp/bot_e2e_tree/server/etc
    sed -e '/void AddSC_playerbots();/d' -e '/    AddSC_playerbots();/d' \
        "$CORE/src/server/scripts/Custom/custom_script_loader.cpp" > /tmp/bot_e2e_tree/source/src/server/scripts/Custom/custom_script_loader.cpp
    # real WorldSession files, unpatched, so the core-patch step is exercised
    mkdir -p /tmp/bot_e2e_tree/source/src/server/game/Server
    python3 "$HERE/patch-core.py" revert "$CORE" >/dev/null 2>&1
    cp "$CORE/src/server/game/Server/WorldSession.h"   /tmp/bot_e2e_tree/source/src/server/game/Server/
    cp "$CORE/src/server/game/Server/WorldSession.cpp" /tmp/bot_e2e_tree/source/src/server/game/Server/
    # Live config sits in server\, exactly where 2-Build-Core.ps1 seeds it and
    # where worldserver.exe reads it. The copy under etc\ is what CMake installs
    # and the server ignores; it must NOT be mistaken for the live one.
    printf 'WorldDatabaseInfo = "127.0.0.1;3306;root;admin;world"' > /tmp/bot_e2e_tree/server/worldserver.conf
    printf '# installed by cmake, not read by the server\n' > /tmp/bot_e2e_tree/server/etc/worldserver.conf
    sed -i "s|^\$MySqlPort.*|\$MySqlPort = $DBPORT|; s|^\$MySqlPass.*|\$MySqlPass = '$DBPASS'|" /tmp/bot_e2e_kit/kit-config.ps1
    q -e "DROP DATABASE IF EXISTS world; CREATE DATABASE world DEFAULT CHARSET utf8mb4;"
    cat /tmp/wdbtest/ct.sql /tmp/wdbtest/ctw.sql /tmp/wdbtest/updates.sql /tmp/wdbtest/updates_include.sql | q world
    R=0
    for i in 1 2; do
        LEGIONCORE_INSTALL_ROOT=/tmp/bot_e2e_tree LEGIONCORE_LIBS_ROOT=/tmp/bot_e2e_tree/libs PATH="$MBIN:$PATH" \
          "$PWSH" -NoProfile -ExecutionPolicy Bypass -File /tmp/bot_e2e_kit/7-Install-PlayerBots.ps1 >/tmp/bot_e2e_$i.log 2>&1 && R=$((R+1))
    done
    [ "$R" -eq 2 ] && ok "installer ran twice with the database section live" || { tail -8 /tmp/bot_e2e_2.log | sed 's/^/    /'; bad "installer failed"; }
    E=$(q -N world -e "SELECT CONCAT((SELECT COUNT(*) FROM playerbot_profile),'/',(SELECT COUNT(*) FROM playerbot_area),'/',
        (SELECT COUNT(*) FROM playerbot_rotation),'/',(SELECT COUNT(*) FROM updates WHERE name='2026_10_13_00_playerbots.sql'),'/',
        (SELECT COUNT(*) FROM updates_include WHERE path='\$/sql/custom/world'));")
    [ "$E" = "120/11/20/1/1" ] && ok "database after two runs: $E" || bad "unexpected database state: $E"
    DB=$(q -N world -e "SELECT hash FROM updates WHERE name='2026_10_13_00_playerbots.sql';")
    FH=$(python3 -c "import hashlib,sys;print(hashlib.sha1(open(sys.argv[1],'rb').read().replace(b'\r\n',b'\n')).hexdigest().upper())" \
         /tmp/bot_e2e_tree/source/sql/custom/world/2026_10_13_00_playerbots.sql)
    [ "$DB" = "$FH" ] && ok "recorded hash matches the core's own rule" || bad "hash mismatch db=$DB file=$FH"
    PATCHED=$(grep -c '!IsBot()' /tmp/bot_e2e_tree/source/src/server/game/Server/WorldSession.cpp 2>/dev/null || true)
    [ "$PATCHED" = "1" ] && ok "the installer applied the core patch to the source tree" \
                         || bad "the installer did not patch WorldSession.cpp (found $PATCHED)"
    BK=$(ls /tmp/bot_e2e_tree/source/src/server/game/Server/*.before-playerbots 2>/dev/null | wc -l)
    [ "$BK" = "2" ] && ok "both core backups written before patching" || bad "$BK of 2 core backups present"
    L=$(grep -c 'AddSC_playerbots' /tmp/bot_e2e_tree/source/src/server/scripts/Custom/custom_script_loader.cpp)
    [ "$L" = "2" ] && ok "loader has exactly one declaration and one call" || bad "loader edit not idempotent ($L)"
    LIVE=$(grep -c '^PlayerBots\.' /tmp/bot_e2e_tree/server/worldserver.conf)
    [ "$LIVE" = "26" ] && ok "the block landed in the LIVE config ($LIVE settings in server\worldserver.conf)" \
                       || bad "live config has $LIVE PlayerBots settings, expected 26"
    DEAD=$(grep -c '^PlayerBots\.' /tmp/bot_e2e_tree/server/etc/worldserver.conf 2>/dev/null || true)
    [ "$DEAD" = "0" ] && ok "the config the server ignores was left untouched" \
                      || bad "$DEAD settings written to etc\worldserver.conf, which the server never reads"
    D=$(grep '^PlayerBots\.' /tmp/bot_e2e_tree/server/worldserver.conf | cut -d= -f1 | tr -d ' ' | sort | uniq -d | wc -l)
    [ "$D" = "0" ] && ok "no duplicated PlayerBots setting after two runs" || bad "$D duplicated setting(s)"
    GLUED=$(head -1 /tmp/bot_e2e_tree/server/worldserver.conf | grep -c 'PlayerBots' || true)
    [ "$GLUED" = "0" ] && ok "nothing glued onto the last line of a config without a trailing newline" \
                       || bad "the append corrupted the existing final line"
fi

echo
echo "=== 12. packed update-fields are never written whole ==="
# UNIT_FIELD_SEX is an alias for UNIT_FIELD_BYTES_0: one uint32 packing race,
# class, power type and gender. SetUInt32Value on it zeroes class, and
# Unit::UpdateAttackPowerAndDamage then dereferences
# sChrClassesStore.LookupEntry(0) with no null check -> world server crash.
packed=$(grep -nE 'SetUInt32Value\s*\(\s*(UNIT_FIELD_SEX|UNIT_FIELD_BYTES_0|UNIT_FIELD_BYTES_1|UNIT_FIELD_BYTES_2|PLAYER_BYTES)' /tmp/vb_stripped/* 2>/dev/null)
[ -z "$packed" ] && ok "no packed byte-field is written with SetUInt32Value" \
                 || { echo "$packed" | sed 's/^/    /'; bad "a packed field is overwritten whole - this clears class and crashes the server"; }

# Player display IDs from ChrRaces render as untextured white figures on a
# creature, because character textures come from Player customisation data.
chrdisp=$(grep -nE 'MaleDisplayID|FemaleDisplayID' /tmp/vb_stripped/* 2>/dev/null)
[ -z "$chrdisp" ] && ok "no ChrRaces player display ID is applied to a creature" \
                  || { echo "$chrdisp" | sed 's/^/    /'; bad "ChrRaces display IDs are player models - creatures using them render white"; }

echo
echo "=== 13. every bot display ID is a model real NPCs already use ==="
# Checked against the shipped world dump, not against assumptions.
if [ -z "$MYSQLD_OK" ] || [ ! -s /tmp/dumps/ctw.sql ]; then
    echo "SKIP: needs MySQL plus creature_template_wdb/creature_model_info from the release dump"
else
    q -e "DROP DATABASE IF EXISTS dispcheck; CREATE DATABASE dispcheck;"
    # creature_template is needed too, or the module SQL aborts partway and the
    # orphan query below silently inspects an empty set and "passes".
    cat /tmp/dumps/cmi.sql /tmp/dumps/ctw.sql /tmp/dumps/ct.sql | q dispcheck
    q dispcheck < "$KIT/sql/custom/world/2026_10_13_00_playerbots.sql" >/dev/null 2>&1
    PRESENT=$(q -N dispcheck -e "SELECT COUNT(*) FROM creature_template_wdb WHERE Entry BETWEEN 800000 AND 800999;")
    if [ "$PRESENT" != "120" ]; then
        bad "only $PRESENT of 120 bot rows applied - the display check would be meaningless"
    fi
    ORPHAN=$(q -N dispcheck -e "SELECT COUNT(*) FROM creature_template_wdb w
        WHERE w.Entry BETWEEN 800000 AND 800999
          AND NOT EXISTS (SELECT 1 FROM creature_template_wdb x
                          WHERE x.DisplayId1=w.DisplayId1 AND x.Entry<800000);")
    [ "$ORPHAN" = "0" ] && ok "all 120 bot displays are used by existing NPCs in the official world data" \
                        || bad "$ORPHAN bot(s) use a display ID no real NPC uses - they will render white"
    NOMODEL=$(q -N dispcheck -e "SELECT COUNT(*) FROM creature_template_wdb w
        WHERE w.Entry BETWEEN 800000 AND 800999
          AND NOT EXISTS (SELECT 1 FROM creature_model_info m WHERE m.DisplayID=w.DisplayId1);")
    [ "$NOMODEL" = "0" ] && ok "every bot display has a creature_model_info row" \
                         || bad "$NOMODEL bot display(s) missing from creature_model_info"
    q -e "DROP DATABASE IF EXISTS dispcheck;"
fi

echo "=== 14. the core patch applies, is idempotent and reverts cleanly ==="
# Real player-bots need a socket-less WorldSession. Touching engine files is the
# riskiest thing this kit does, so prove: it applies, applying twice is a no-op,
# revert restores the original bytes, and compilability is unchanged.
PATCHER="$HERE/patch-core.py"
WS_H="$CORE/src/server/game/Server/WorldSession.h"
WS_C="$CORE/src/server/game/Server/WorldSession.cpp"
if [ ! -f "$PATCHER" ] || [ ! -f "$WS_C" ]; then
    echo "SKIP: patch-core.py or the core source is missing"
else
    python3 "$PATCHER" revert "$CORE" >/dev/null 2>&1
    cp "$WS_H" /tmp/vb_ws.h.orig; cp "$WS_C" /tmp/vb_ws.cpp.orig

    python3 "$PATCHER" apply "$CORE" >/dev/null 2>&1 \
      && ok "core patch applies" || bad "core patch failed to apply"

    grep -q 'IsBot()' "$WS_H" && grep -q '!IsBot()' "$WS_C" \
      && ok "both files carry the change" || bad "the change is not present in both files"

    OUT=$(python3 "$PATCHER" apply "$CORE" 2>&1)
    echo "$OUT" | grep -q 'already applied' \
      && ok "applying twice is a no-op" || { echo "$OUT" | sed 's/^/    /'; bad "second apply was not a no-op"; }

    # compilability must be identical patched vs unpatched
    FORCEC="-include map -include set -include unordered_map -include unordered_set -include atomic -include string -include vector -include list -include deque"
    cnt() { (cd "$CORE" && g++ -std=c++17 -fsyntax-only -I"$GEN" "${INCS[@]}" $FORCEC "$1" 2>&1 | grep -cE '^[^ ].*error:'); }
    P=$(cnt src/server/game/Server/WorldSession.cpp)
    python3 "$PATCHER" revert "$CORE" >/dev/null 2>&1
    U=$(cnt src/server/game/Server/WorldSession.cpp)
    [ "$P" = "$U" ] && [ "$P" = "0" ] \
      && ok "WorldSession.cpp compiles clean patched and unpatched ($P errors both)" \
      || bad "compile differs: patched=$P unpatched=$U"

    cmp -s "$WS_H" /tmp/vb_ws.h.orig && cmp -s "$WS_C" /tmp/vb_ws.cpp.orig \
      && ok "revert restores both files byte for byte" || bad "revert did not restore the originals"

    python3 "$PATCHER" apply "$CORE" >/dev/null 2>&1   # leave it applied for the rest
fi

echo "=== 11. every kit script agrees on where worldserver.conf lives ==="
# The installer once wrote the PlayerBots block to $ServerDir\etc\worldserver.conf
# while the rest of the kit - and the running server - used $ServerDir\worldserver.conf.
# The block landed in a file nobody reads and PlayerBots reported itself disabled.
# '.ServerDir' dodges shell/ERE trouble with a literal '$'.
PAT='[Jj]oin-Path .ServerDir .[^'"'"']*worldserver\.conf'
extract() { grep -oE "$PAT" "$@" 2>/dev/null | sed "s/.*['\"]\\([^'\"]*worldserver\.conf\\)/\\1/"; }

all_paths=$(extract "$KIT"/*.ps1 "$KIT"/tools/*.ps1 | sort -u)
ins_paths=$(extract "$KIT/7-Install-PlayerBots.ps1" | sort -u)
echo "    used anywhere in the kit : $(echo "$all_paths" | tr '\n' ' ')"
echo "    covered by the installer : $(echo "$ins_paths" | tr '\n' ' ')"

missing=0
while read -r k; do
    [ -z "$k" ] && continue
    echo "$ins_paths" | grep -qxF "$k" || { echo "    the installer never touches '$k'"; missing=$((missing+1)); }
done <<< "$all_paths"
[ "$missing" -eq 0 ] && ok "the installer covers every worldserver.conf path the kit uses" \
                     || bad "$missing config path(s) used elsewhere but ignored by the installer"

grep -q 'WorldDatabaseInfo' "$KIT/7-Install-PlayerBots.ps1" \
  && ok "the installer only writes to a conf containing WorldDatabaseInfo (a live config)" \
  || bad "the installer does not check that the conf it edits is the live one"

echo
echo "------------------------------------------------------------"
echo "RESULT: $PASS passed, $FAIL failed"
[ "$FAIL" -eq 0 ] || exit 1
