#!/usr/bin/env python3
"""Print a C++ file with comments and string/char literal CONTENTS blanked out,
keeping line numbers intact, so a lexical scan cannot match inside a string."""
import sys, re
src = open(sys.argv[1], encoding='utf-8', errors='replace').read()
out, i, n = [], 0, len(src)
state = None        # None | 'line' | 'block' | 'str' | 'chr'
while i < n:
    c = src[i]; nxt = src[i+1] if i + 1 < n else ''
    if state is None:
        if c == '/' and nxt == '/':  state = 'line';  out.append('  '); i += 2; continue
        if c == '/' and nxt == '*':  state = 'block'; out.append('  '); i += 2; continue
        if c == '"':                 state = 'str';   out.append('"');  i += 1; continue
        if c == "'":                 state = 'chr';   out.append("'");  i += 1; continue
        out.append(c); i += 1; continue
    if state == 'line':
        if c == '\n': state = None; out.append('\n')
        else: out.append(' ')
        i += 1; continue
    if state == 'block':
        if c == '*' and nxt == '/': state = None; out.append('  '); i += 2; continue
        out.append('\n' if c == '\n' else ' '); i += 1; continue
    if state in ('str', 'chr'):
        q = '"' if state == 'str' else "'"
        if c == '\\':  out.append('  '); i += 2; continue
        if c == q:     state = None; out.append(q); i += 1; continue
        out.append('\n' if c == '\n' else ' '); i += 1; continue
sys.stdout.write(''.join(out))
