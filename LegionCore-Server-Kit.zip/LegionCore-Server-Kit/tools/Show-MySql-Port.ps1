<#
Read-only Windows MySQL port/service/process diagnostic. It does not connect to
MySQL, request passwords, stop/restart services, edit files, or change ports.
Run from the kit folder in Administrator PowerShell:
    powershell -ExecutionPolicy Bypass -File .\tools\Show-MySql-Port.ps1
#>
#Requires -Version 5.1
[CmdletBinding()]
param()
$ErrorActionPreference='Stop'
. (Join-Path (Split-Path $PSScriptRoot -Parent) 'kit-config.ps1')

Write-Host "`n=== READ-ONLY MYSQL PORT DIAGNOSTIC ===" -ForegroundColor Cyan
Write-Host "Configured host/port: $MySqlHost / $MySqlPort"
Write-Host "Expected server: $(Join-Path $MySqlRoot 'bin\mysqld.exe')"
Write-Host "Expected configuration: $(Join-Path $MySqlRoot 'my.ini')"
$service=Get-CimInstance -ClassName Win32_Service -Filter "Name='LegionCoreMySQL'" -ErrorAction Stop
Write-Host "`nLegionCoreMySQL service:"
if ($service) { $service | Select-Object Name,State,ProcessId | Format-List | Out-Host }
else { Write-Host 'Service not found.' }
$listeners=@(Get-NetTCPConnection -State Listen -LocalPort $MySqlPort -ErrorAction SilentlyContinue)
Write-Host "`nListeners on port ${MySqlPort}:"
if ($listeners.Count) {
    $listeners | Select-Object LocalAddress,LocalPort,OwningProcess | Sort-Object LocalAddress,OwningProcess -Unique | Format-Table -AutoSize | Out-Host
} else { Write-Host 'No listeners found.' }

$ids=@($listeners | Select-Object -ExpandProperty OwningProcess -Unique)
if ($service -and $service.ProcessId) { $ids += [uint32]$service.ProcessId }
$ids=@($ids | Select-Object -Unique)
$processes=@()
foreach ($processId in $ids) {
    $p=Get-CimInstance -ClassName Win32_Process -Filter "ProcessId=$processId" -ErrorAction Stop
    if ($p) { $processes += $p }
}
$parentIds=@($processes | Select-Object -ExpandProperty ParentProcessId -Unique | Where-Object { $_ -gt 0 -and $_ -notin $ids })
foreach ($parentId in $parentIds) {
    $p=Get-CimInstance -ClassName Win32_Process -Filter "ProcessId=$parentId" -ErrorAction Stop
    if ($p) { $processes += $p }
}
Write-Host "`nListener, monitor/service and parent processes (command lines intentionally omitted):"
if ($processes.Count) {
    $processes | Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CreationDate | Sort-Object ProcessId -Unique | Format-List | Out-Host
} else { Write-Host 'No corresponding processes found.' }

$knownIds=@($processes | Select-Object -ExpandProperty ProcessId -Unique)
Write-Host "`nServices associated with those processes:"
$matched=@(Get-CimInstance -ClassName Win32_Service -ErrorAction Stop | Where-Object { $_.ProcessId -gt 0 -and $_.ProcessId -in $knownIds })
if ($matched.Count) { $matched | Select-Object Name,DisplayName,State,ProcessId | Format-Table -AutoSize | Out-Host }
else { Write-Host 'No matching services found; a listener may be manually started or hosted by another application.' }
Write-Host "`nEnd of read-only diagnostic. No passwords or command lines were printed; no configuration/service changes were made."
