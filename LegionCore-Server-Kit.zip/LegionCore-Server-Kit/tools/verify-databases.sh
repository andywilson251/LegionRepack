#!/usr/bin/env bash
# =============================================================================
#  LegionCore 7.3.5 - Database verification harness
#  Simulates what worldserver.exe does on first start (DBUpdater):
#    1. confirms all 4 databases + base schema exist
#    2. applies every SQL update listed in `updates_include` that is not yet
#       recorded in the `updates` tracking table (exactly like the core does)
#    3. reports table/row counts and any SQL errors
#
#  Usage:  ./verify-databases.sh <path-to-legioncore-source-tree>
#  (Run once against a fresh setup: it applies the pending updates just like
#   the core would, so a second run should report "0 pending".)
# =============================================================================
set -u
SRC="${1:-/home/user/core-repo}"
MYSQL="${MYSQL_CLI:-sudo mariadb}"

DBDIRS_auth="sql/old/auth sql/updates/auth"
DBDIRS_characters="sql/old/characters sql/updates/characters"
DBDIRS_world="sql/old/world sql/updates/world"
DBDIRS_hotfixes="sql/old/hotfixes sql/updates/hotfixes"

fail=0
applied_total=0

echo "========================================================================="
echo " LegionCore database verification - source tree: $SRC"
echo "========================================================================="

# --- 1. database presence + table counts -------------------------------------
echo
echo "[1/4] Databases and base schema"
for db in auth characters world hotfixes; do
    t=$(sudo mariadb -N -B -e "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='$db';" 2>/dev/null)
    if [ -z "$t" ] || [ "$t" -eq 0 ]; then
        echo "  !! $db : MISSING or EMPTY"; fail=1
    else
        printf "  ok %-11s tables=%-5s rows(updates)=%s\n" "$db" "$t" \
            "$(sudo mariadb -N -B -e "SELECT COUNT(*) FROM \`$db\`.updates;" 2>/dev/null)"
    fi
done

# --- 2/3. apply pending updates exactly like the core's updater --------------
echo
echo "[2/4] Applying pending SQL updates (mirrors core DBUpdater logic)"
for db in auth characters world hotfixes; do
    eval "dirs=\$DBDIRS_$db"
    echo "  --- $db ---"
    for d in $dirs; do
        [ -d "$SRC/$d" ] || { echo "      (dir missing, core would skip: $d)"; continue; }
        for f in "$SRC/$d"/*.sql; do
            [ -e "$f" ] || continue
            name=$(basename "$f")
            # has the core already applied this update?
            seen=$(sudo mariadb -N -B -e "SELECT COUNT(*) FROM \`$db\`.updates WHERE name='$name';" 2>/dev/null)
            [ "$seen" != "0" ] && continue
            if sudo mariadb --default-character-set=utf8mb4 --max_allowed_packet=1G \
                 --force "$db" < "$f" >/tmp/upd.log 2>&1; then
                echo "      applied $name"
                sudo mariadb -e "REPLACE INTO \`$db\`.updates (name,hash,state,speed) VALUES ('$name','TESTRUN','RELEASED',0);"
                applied_total=$((applied_total+1))
            else
                # --force: mysql returns per-statement errors in the log, check it
                if grep -qi "ERROR" /tmp/upd.log; then
                    echo "      !! ERROR in $name:"; sed -n '1,6p' /tmp/upd.log | sed 's/^/         /'
                    fail=1
                else
                    echo "      applied $name"
                    sudo mariadb -e "REPLACE INTO \`$db\`.updates (name,hash,state,speed) VALUES ('$name','TESTRUN','RELEASED',0);"
                    applied_total=$((applied_total+1))
                fi
            fi
        done
    done
done
echo "  Total updates applied this run: $applied_total"

# --- 4. key row / sanity checks ---------------------------------------------
echo
echo "[3/4] Sanity checks on core-critical tables"
check() { # db, query, label
    v=$(sudo mariadb -N -B -e "$2" 2>/dev/null)
    printf "  %-46s %s\n" "$3" "${v:-<query failed>}"
    [ -z "$v" ] && fail=1
}
check auth       "SELECT COUNT(*) FROM auth.realmlist;"                 "auth.realmlist rows"
check auth       "SELECT COUNT(*) FROM auth.account;"                   "auth.account rows"
check auth       "SELECT COUNT(*) FROM auth.updates_include;"           "auth.updates_include rows"
check characters "SELECT COUNT(*) FROM characters.updates_include;"     "characters.updates_include rows"
check world      "SELECT COUNT(*) FROM world.creature_template;"        "world.creature_template rows"
check world      "SELECT COUNT(*) FROM world.gameobject_template;"      "world.gameobject_template rows"
check world      "SELECT COUNT(*) FROM world.quest_template;"           "world.quest_template rows"
check world      "SELECT COUNT(*) FROM world.updates_include;"          "world.updates_include rows"
check hotfixes   "SELECT COUNT(*) FROM hotfixes.item;"                  "hotfixes.item rows"
check hotfixes   "SELECT COUNT(*) FROM hotfixes.updates_include;"       "hotfixes.updates_include rows"
check world      "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='world' AND table_name='updates';" "world.updates table exists"

echo
echo "[4/4] Pending updates remaining (should be 0 - core reports 'up-to-date')"
pend=0
for db in auth characters world hotfixes; do
    eval "dirs=\$DBDIRS_$db"
    for d in $dirs; do
        [ -d "$SRC/$d" ] || continue
        for f in "$SRC/$d"/*.sql; do
            [ -e "$f" ] || continue
            name=$(basename "$f")
            seen=$(sudo mariadb -N -B -e "SELECT COUNT(*) FROM \`$db\`.updates WHERE name='$name';" 2>/dev/null)
            if [ "$seen" = "0" ]; then echo "  pending: $db/$name"; pend=$((pend+1)); fi
        done
    done
done
echo "  pending total: $pend"
[ "$pend" -eq 0 ] || fail=1

echo
if [ "$fail" -eq 0 ]; then
    echo "RESULT: ALL CHECKS PASSED - databases are ready for worldserver.exe"
else
    echo "RESULT: FAILURES DETECTED - see messages above"
fi
exit $fail
