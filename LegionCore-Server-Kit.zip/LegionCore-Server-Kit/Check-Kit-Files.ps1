<#
.SYNOPSIS
    Reports which copy of each PlayerBots file is actually on disk.

.DESCRIPTION
    Extracting a new kit *over* an old folder leaves a mix of old and new files
    if Windows is told to skip duplicates. This script finds every copy of the
    PlayerBots files under a folder and says, for each one, whether it is the
    fixed version or the broken first release.

    Run it from anywhere:

        powershell -ExecutionPolicy Bypass -File .\Check-Kit-Files.ps1
        powershell -ExecutionPolicy Bypass -File .\Check-Kit-Files.ps1 -Root C:\Users\Andy\Downloads
#>

[CmdletBinding()]
param(
    [string]$Root = $PSScriptRoot
)

if (-not $Root) { $Root = (Get-Location).Path }

# file name -> text that only the FIXED version contains
$Expect = @{
    '7-Install-PlayerBots.ps1' = 'function Find-MySqlClient'
    'MySql-Client.ps1'         = 'function Find-MySqlClient'
}

Write-Host ''
Write-Host "  Searching $Root" -ForegroundColor Cyan
Write-Host ('  ' + ('-' * 72))

$found = 0
$stale = 0

foreach ($name in $Expect.Keys | Sort-Object) {
    $marker = $Expect[$name]
    $copies = @(Get-ChildItem -Path $Root -Filter $name -Recurse -File -ErrorAction SilentlyContinue)

    if ($copies.Count -eq 0) {
        Write-Host ("  {0,-26} not found under this folder" -f $name) -ForegroundColor Yellow
        continue
    }

    foreach ($c in $copies) {
        $found++
        $isFixed = Select-String -Path $c.FullName -Pattern $marker -Quiet -ErrorAction SilentlyContinue
        $sha = (Get-FileHash -Path $c.FullName -Algorithm SHA256).Hash.Substring(0, 12)

        if ($isFixed) {
            Write-Host ("  [ok]    {0}" -f $c.FullName) -ForegroundColor Green
            Write-Host ("          fixed version   {0}   sha {1}" -f $c.LastWriteTime, $sha)
        }
        else {
            $stale++
            Write-Host ("  [OLD]   {0}" -f $c.FullName) -ForegroundColor Red
            Write-Host ("          FIRST RELEASE - this is the one that crashes") -ForegroundColor Red
            Write-Host ("          {0}   sha {1}" -f $c.LastWriteTime, $sha)
        }
    }
}

Write-Host ('  ' + ('-' * 72))
if ($found -eq 0) {
    Write-Host "  Nothing found. Point -Root at the folder holding the kit." -ForegroundColor Yellow
}
elseif ($stale -gt 0) {
    Write-Host "  $stale old file(s) still present." -ForegroundColor Red
    Write-Host ''
    Write-Host "  Overwrite them with the copies from the new zip, or simply delete the"
    Write-Host "  whole kit folder and extract the new zip into an empty folder. Nothing"
    Write-Host "  in C:\LegionCore is affected - the kit folder only holds the scripts."
}
else {
    Write-Host "  All PlayerBots files are the fixed version. Safe to run:" -ForegroundColor Green
    Write-Host "      powershell -ExecutionPolicy Bypass -File .\7-Install-PlayerBots.ps1"
}
Write-Host ''
