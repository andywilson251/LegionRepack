<#
================================================================================
 LegionCore 7.3.5 - Server Kit : STEP 1  -  install everything needed to build
================================================================================
 Installs / verifies:

   * Visual Studio 2022 Build Tools  (MSVC v143 compiler)     [winget]
   * CMake + Ninja + Git + 7-Zip                              [winget]
   * Boost 1.84 prebuilt (MSVC v143, static)  -> C:\libs\boost
   * OpenSSL 3.x Win64                        -> C:\libs\openssl
   * MySQL Server 8.0 (zip, no installer)     -> C:\libs\mysql-8.0
       - initialised data directory, tuned my.ini (max_allowed_packet=1G)
       - Windows service "LegionCoreMySQL" (auto start)
       - root password set to the one in kit-config.ps1

 Run it from an *Administrator* PowerShell:
     powershell -ExecutionPolicy Bypass -File .\1-Install-Prerequisites.ps1

 Already-installed pieces are detected and skipped. MySQL downloads are size/
 SHA256 verified before extraction. A failed download is safe to retry.
 Download + native warning + host bootstrap + Windows monitor-PID repair: 2026-10-11.
 Keep the tools\MySql-Client.ps1 helper with this installer. Root credentials
 are verified using actual client exit codes; no command-line password is used.
 To use a ZIP downloaded in your browser:
     powershell -ExecutionPolicy Bypass -File .\1-Install-Prerequisites.ps1 -MySqlZipPath "C:\path\to\mysql-8.0.43-winx64.zip"
================================================================================
#>
#Requires -Version 5.1
[CmdletBinding()]
param(
    [switch]$SkipMySqlService,     # extract MySQL but don't install the service
    [string]$MySqlZipPath          # optional: use an already-downloaded MySQL 8.0.43 x64 ZIP
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'kit-config.ps1')
. (Join-Path $PSScriptRoot 'tools\MySql-Client.ps1')

# Windows PowerShell 5.1 may otherwise negotiate older TLS versions.
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

function Step($m) { Write-Host "`n=== $m" -ForegroundColor Cyan }
function Ok($m)   { Write-Host "  [ok] $m" -ForegroundColor Green }
function Info($m) { Write-Host "  $m" -ForegroundColor Gray }
function Warn($m) { Write-Host "  [!!] $m" -ForegroundColor Yellow }
function Die($m)  { Write-Host "`n  [XX] $m" -ForegroundColor Red; exit 1 }

# Backward-compatible defaults: this repaired installer also works with your
# original kit-config.ps1, so you do not have to replace your edited settings.
if (-not (Get-Variable MySqlZipSizeBytes -ErrorAction SilentlyContinue)) {
    $MySqlZipSizeBytes = 244242563
}
if (-not (Get-Variable MySqlZipSha256 -ErrorAction SilentlyContinue)) {
    $MySqlZipSha256 = '745B4A9535992705AC43A5645B84D213A579C8FD866D1B5DCE8D6EE5A2FC7728'
}
if (-not (Get-Variable MySqlZipTopFolder -ErrorAction SilentlyContinue)) {
    $MySqlZipTopFolder = 'mysql-8.0.43-winx64'
}

function Test-MySqlZip([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
    $length = (Get-Item -LiteralPath $Path).Length
    if ($length -ne $MySqlZipSizeBytes) {
        Warn "MySQL ZIP has $length bytes; expected $MySqlZipSizeBytes. It is incomplete or not the expected archive."
        return $false
    }
    $sha = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash
    if ($sha -ne $MySqlZipSha256) {
        Warn "MySQL ZIP failed SHA256 verification."
        return $false
    }
    return $true
}

function Get-VerifiedMySqlZip([string]$CachePath, [string]$LocalPath, [string[]]$Urls) {
    if ($LocalPath) {
        $local = (Resolve-Path -LiteralPath $LocalPath -ErrorAction Stop).ProviderPath
        if (-not (Test-MySqlZip $local)) {
            throw "The file supplied with -MySqlZipPath is not the verified MySQL 8.0.43 Windows x64 ZIP. Your file was not modified."
        }
        Ok "local MySQL ZIP verified (size + SHA256)"
        return $local
    }

    if (Test-Path -LiteralPath $CachePath) {
        if (Test-MySqlZip $CachePath) {
            Ok "cached MySQL ZIP verified (size + SHA256)"
            return $CachePath
        }
        Info "discarding the invalid cached MySQL download ..."
        Remove-Item -LiteralPath $CachePath -Force
    }

    $partial = $CachePath + '.download'
    $previousProgress = $ProgressPreference
    $ProgressPreference = 'SilentlyContinue'
    try {
        foreach ($url in $Urls) {
            for ($attempt = 1; $attempt -le 2; $attempt++) {
                try {
                    Remove-Item -LiteralPath $partial -Force -ErrorAction SilentlyContinue
                    Info "downloading MySQL 8.0.43 x64 (233 MiB), attempt $attempt/2 ..."
                    Info $url
                    Invoke-WebRequest -Uri $url -OutFile $partial -UseBasicParsing -TimeoutSec 900 -ErrorAction Stop
                    if (-not (Test-MySqlZip $partial)) {
                        throw "Server returned an incomplete download or an unexpected file (possibly an HTML error page)."
                    }
                    Move-Item -LiteralPath $partial -Destination $CachePath -Force
                    Ok "MySQL ZIP verified (size + SHA256)"
                    return $CachePath
                } catch {
                    Warn "MySQL download failed: $($_.Exception.Message)"
                    if ($attempt -lt 2) { Start-Sleep -Seconds 2 }
                } finally {
                    # Never cache a failed request as a usable ZIP.
                    Remove-Item -LiteralPath $partial -Force -ErrorAction SilentlyContinue
                }
            }
        }
        throw @"
Oracle's download endpoints did not provide a verified ZIP. Do not disable TLS or checksum checks.
Download mysql-8.0.43-winx64.zip in your browser from:
https://cdn.mysql.com/archives/mysql-8.0/mysql-8.0.43-winx64.zip
Then run this installer with -MySqlZipPath "C:\path\to\mysql-8.0.43-winx64.zip".
"@
    } finally {
        $ProgressPreference = $previousProgress
    }
}

function Disable-LegionBootstrapNameSkip([string]$IniPath) {
    # MySQL initializes root@localhost only. Enabling skip-name-resolve before
    # creating root@127.0.0.1 prevents the first TCP login (ERROR 1130).
    $text = [IO.File]::ReadAllText($IniPath)
    $pattern = '(?im)^[\t ]*(?:loose[-_])?skip[-_]name[-_]resolve(?:[\t ]*=[^\r\n]*)?[\t ]*(?:[#;][^\r\n]*)?\r?$'
    if (-not [regex]::IsMatch($text, $pattern)) {
        return [pscustomobject]@{ Changed = $false; BackupPath = '' }
    }
    $backup = $IniPath + '.before-host-fix-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N').Substring(0,8) + '.bak'
    Copy-Item -LiteralPath $IniPath -Destination $backup -ErrorAction Stop
    if ($env:OS -eq 'Windows_NT') {
        Set-Acl -LiteralPath $backup -AclObject (Get-Acl -LiteralPath $IniPath) -ErrorAction Stop
    }
    $fixed = [regex]::Replace($text, $pattern, '# Disabled by LegionCore host bootstrap repair: $0')
    try {
        [IO.File]::WriteAllText($IniPath, $fixed, (New-Object Text.UTF8Encoding $false))
    } catch {
        Copy-Item -LiteralPath $backup -Destination $IniPath -Force -ErrorAction Stop
        throw
    }
    return [pscustomobject]@{ Changed = $true; BackupPath = $backup }
}

function Test-LegionMySqlDefaultsArgument([string]$CommandLine, [string]$IniPath) {
    if (-not $CommandLine) { return $false }
    $command = $CommandLine.Replace('/', '\')
    $path = $IniPath.Replace('/', '\')
    # Supports --defaults-file="path", "--defaults-file=path", and unquoted
    # paths without spaces. Boundary check rejects my.ini.other / my.ini.bak.
    $pattern = '(?i)(?:^|\s)"?--defaults[-_]file="?' + [regex]::Escape($path) + '"?(?=\s|$)'
    return [regex]::IsMatch($command, $pattern)
}

function Test-LegionMySqlProcessIdentity($Process, [string]$ServerExe, [string]$IniPath) {
    if (-not $Process -or -not $Process.ExecutablePath -or -not $Process.CommandLine) { return $false }
    $actual = $Process.ExecutablePath.Replace('/', '\')
    $expected = $ServerExe.Replace('/', '\')
    if (-not [string]::Equals($actual, $expected, [StringComparison]::OrdinalIgnoreCase)) { return $false }
    if (-not (Test-LegionMySqlDefaultsArgument -CommandLine $Process.CommandLine -IniPath $IniPath)) { return $false }
    # A command-line override cannot be repaired merely by editing my.ini.
    if ($Process.CommandLine -match '(?i)(?:^|\s)"?--(?:loose[-_])?skip[-_]name[-_]resolve(?:\s|=|"|$)') { return $false }
    return $true
}

function Assert-LegionMySqlServiceTarget([string]$ServerExe, [string]$IniPath, [int]$Port, [string]$HostName) {
    # Windows MySQL 8 normally runs a service monitor plus a direct child server.
    # The listener PID need not be the Win32_Service PID. Verify both identity
    # and the parent relationship, never accept a process just named mysqld.exe.
    if ($HostName -notin @('127.0.0.1','localhost')) {
        throw 'Step 1 installs a local MySQL instance. MySqlHost must be 127.0.0.1 or localhost; no remote accounts/configuration were changed.'
    }
    $serverPath = $ServerExe.Replace('/', '\')
    for ($attempt = 1; $attempt -le 10; $attempt++) {
        $service = Get-CimInstance -ClassName Win32_Service -Filter "Name='LegionCoreMySQL'" -ErrorAction Stop
        if (-not $service -or $service.State -ne 'Running' -or $service.ProcessId -eq 0) {
            throw 'LegionCoreMySQL is not running. Check mysql-error.log; no MySQL configuration/accounts were changed.'
        }
        # Validate registry configuration AND the actually running process.
        $command = $service.PathName.Replace('/', '\')
        $exePattern = '(?i)^\s*"?' + [regex]::Escape($serverPath) + '(?:"|\s|$)'
        if (-not [regex]::IsMatch($command, $exePattern) -or
            -not (Test-LegionMySqlDefaultsArgument -CommandLine $command -IniPath $IniPath)) {
            throw "LegionCoreMySQL does not point at this kit's exact mysqld.exe and my.ini. No configuration/accounts were changed. Run tools\Show-MySql-Port.ps1 for read-only details."
        }
        $servicePid = [uint32]$service.ProcessId
        $monitor = Get-CimInstance -ClassName Win32_Process -Filter "ProcessId=$servicePid" -ErrorAction Stop
        if (-not (Test-LegionMySqlProcessIdentity -Process $monitor -ServerExe $ServerExe -IniPath $IniPath)) {
            throw "Cannot verify service PID $servicePid against the expected executable/configuration (or it has a skip-name-resolve command-line override). No configuration/accounts were changed. Run tools\Show-MySql-Port.ps1."
        }
        $addresses = if ($HostName -eq '127.0.0.1') { @('127.0.0.1','0.0.0.0','::') } else { @('127.0.0.1','0.0.0.0','::1','::') }
        $listeners = @(Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue | Where-Object {
            $_.LocalAddress -in $addresses
        })
        if ($listeners.Count -gt 0) {
            $rejections = @()
            $listenerPids = @($listeners | Select-Object -ExpandProperty OwningProcess -Unique)
            foreach ($listenerPid in $listenerPids) {
                if ($listenerPid -eq $servicePid) { continue } # --no-monitor mode
                $process = Get-CimInstance -ClassName Win32_Process -Filter "ProcessId=$listenerPid" -ErrorAction Stop
                $identityOk = Test-LegionMySqlProcessIdentity -Process $process -ServerExe $ServerExe -IniPath $IniPath
                $parentOk = $process -and $process.ParentProcessId -eq $servicePid
                # Parent PID can be reused after exit. A real child must not
                # predate the presently running service-monitor process.
                $ageOk = $process -and $process.CreationDate -and $monitor.CreationDate -and
                         ([datetime]$process.CreationDate -ge [datetime]$monitor.CreationDate)
                if ($identityOk -and $parentOk -and $ageOk) {
                    Write-Verbose "Port $Port listener PID $listenerPid is the verified MySQL server child of service-monitor PID $servicePid."
                    continue
                }
                $name = if ($process) { $process.Name } else { '<process exited or unavailable>' }
                $parent = if ($process) { $process.ParentProcessId } else { '?' }
                $path = if ($process -and $process.ExecutablePath) { $process.ExecutablePath } else { '<unavailable>' }
                $rejections += "listener PID $listenerPid; name $name; parent PID $parent; executable $path; expected service PID $servicePid"
            }
            if ($rejections.Count -eq 0) { return }
            # Do not change ports or stop another service based on PID alone.
            throw ("Port $Port has a listener that could not be verified as LegionCoreMySQL or its MySQL server child. No configuration/accounts were changed.`n" +
                   ($rejections -join "`n") + "`nRun tools\Show-MySql-Port.ps1 and share the read-only output before stopping any service or changing ports.")
        }
        if ($attempt -lt 10) { Start-Sleep -Seconds 1 }
    }
    throw "LegionCoreMySQL is running but has no loopback listener on port $Port. Check my.ini and mysql-error.log; no configuration/accounts were changed."
}

function Test-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    (New-Object Security.Principal.WindowsPrincipal $id).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
if (-not (Test-Admin)) { Die "Please run this script from an Administrator PowerShell (right-click > Run as administrator)." }

function Test-Winget { $null -ne (Get-Command winget -ErrorAction SilentlyContinue) }
function Install-WingetPackage([string]$Id, [string]$Name, [string[]]$Override) {
    $wgArgs = @('install', '--id', $Id, '--exact', '--accept-package-agreements', '--accept-source-agreements', '--disable-interactivity')
    if ($Override) { $wgArgs += @('--override', ($Override -join ' ')) }
    Info "winget install $Id ..."
    & winget @wgArgs | Out-Host
    if ($LASTEXITCODE -ne 0) { Warn "winget could not install $Id - install $Name manually if the build later complains." ; return $false }
    Ok "$Name installed"
    return $true
}

foreach ($d in @($InstallRoot, $LibsRoot, $DownloadsDir)) { New-Item -ItemType Directory -Force -Path $d | Out-Null }

# ==============================================================================
Step "1/6  Build tools (Visual Studio 2022 Build Tools, CMake, Ninja, Git, 7-Zip)"
if (-not (Test-Winget)) {
    Warn "winget is not available. Install these manually, then re-run this script:"
    Write-Host @"
       - Visual Studio 2022 Build Tools with 'Desktop development with C++'
         https://visualstudio.microsoft.com/downloads/#build-tools-for-visual-studio-2022
       - CMake:  https://cmake.org/download/    (add to PATH)
       - Ninja:  https://github.com/ninja-build/ninja/releases  (put ninja.exe in PATH)
       - Git:    https://git-scm.com/download/win
       - 7-Zip:  https://www.7-zip.org/
"@ -ForegroundColor Yellow
} else {
    $vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
    $hasVs = $false
    if (Test-Path $vswhere) {
        $vc = & $vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath 2>$null
        if ($vc) { $hasVs = $true; Ok "MSVC found: $vc" }
    }
    if (-not $hasVs) {
        Install-WingetPackage 'Microsoft.VisualStudio.2022.BuildTools' 'Visual Studio 2022 Build Tools' @(
            '--quiet','--wait','--norestart','--nocache',
            '--add','Microsoft.VisualStudio.Workload.VCTools',
            '--add','Microsoft.VisualStudio.Component.VC.Tools.x86.x64',
            '--add','Microsoft.VisualStudio.Component.Windows10SDK.19041',
            '--includeRecommended') | Out-Null
    } else { Ok "Visual Studio Build Tools already installed" }

    if (-not (Get-Command cmake -ErrorAction SilentlyContinue)) { Install-WingetPackage 'Kitware.CMake' 'CMake' | Out-Null } else { Ok "cmake: $((& cmake --version)[0])" }
    if (-not (Get-Command ninja -ErrorAction SilentlyContinue)) { Install-WingetPackage 'Ninja-build.Ninja' 'Ninja' | Out-Null } else { Ok "ninja: $((& ninja --version))" }
    if (-not (Get-Command git -ErrorAction SilentlyContinue))   { Install-WingetPackage 'Git.Git' 'Git' | Out-Null }        else { Ok "git: $((& git --version))" }
    if (-not (Get-Command 7z.exe -ErrorAction SilentlyContinue) -and -not (Test-Path "$env:ProgramFiles\7-Zip\7z.exe")) {
        Install-WingetPackage '7zip.7zip' '7-Zip' | Out-Null
    } else { Ok "7-Zip present" }
}
# refresh PATH for this session
$env:Path = [Environment]::GetEnvironmentVariable('Path','Machine') + ';' + [Environment]::GetEnvironmentVariable('Path','User')

# ==============================================================================
Step "2/6  Boost 1.84 (prebuilt, MSVC v143, static)  ->  $BoostRoot"
if (Test-Path (Join-Path $BoostRoot 'boost\lib')) {
    Ok "Boost already extracted"
} else {
    $arc = Join-Path $DownloadsDir 'boost-1.84.0.tar.gz'
    if (-not (Test-Path $arc) -or ((Get-Item $arc).Length -ne $BoostSizeBytes)) {
        Info "downloading Boost (617 MB, one time) ..."
        $ProgressPreference = 'SilentlyContinue'
        Invoke-WebRequest -Uri $BoostUrl -OutFile $arc -UseBasicParsing
    }
    if ((Get-Item $arc).Length -ne $BoostSizeBytes) { Die "Boost download incomplete - delete $arc and re-run." }
    Ok "download verified ($BoostSizeBytes bytes)"
    Info "extracting ..."
    New-Item -ItemType Directory -Force -Path $BoostRoot | Out-Null
    & tar -xzf $arc -C $BoostRoot
    if ($LASTEXITCODE -ne 0) { Die "Boost extraction failed (tar)." }
    Ok "Boost extracted to $BoostRoot\boost"
    Remove-Item $arc -Force
}
$env:BOOST_ROOT = (Join-Path $BoostRoot 'boost')
[Environment]::SetEnvironmentVariable('BOOST_ROOT', $env:BOOST_ROOT, 'Machine')
Ok "BOOST_ROOT = $env:BOOST_ROOT"

# ==============================================================================
Step "3/6  OpenSSL 3.x Win64  ->  $OpenSslRoot"
if (Test-Path (Join-Path $OpenSslRoot 'bin\libssl-3-x64.dll')) {
    Ok "OpenSSL already installed"
} else {
    Info "finding latest Win64 OpenSSL 3.x installer (slproweb) ..."
    $json = Invoke-RestMethod -Uri 'https://api.github.com/repos/slproweb/opensslhashes/contents/win32_openssl_hashes.json' `
            -Headers @{ Accept = 'application/vnd.github.raw+json' } -UseBasicParsing
    $files = $json.files.PSObject.Properties.Value | Where-Object {
        $_.arch -eq 'INTEL' -and $_.bits -eq 64 -and $_.light -eq $false -and $_.installer -eq 'exe' -and $_.basever -like '3.*'
    } | Sort-Object -Descending { [version]$_.basever }
    if (-not $files) { Die "Could not determine the OpenSSL download URL - install OpenSSL 3.x manually into $OpenSslRoot." }
    $f = $files | Select-Object -First 1
    Ok "latest: $($f.basever)"
    $exe = Join-Path $DownloadsDir 'openssl-installer.exe'
    Info "downloading $($f.url) ..."
    Invoke-WebRequest -Uri $f.url -OutFile $exe -UseBasicParsing
    $sha = (Get-FileHash $exe -Algorithm SHA256).Hash
    if ($f.sha256 -and ($sha -ne $f.sha256.ToUpper())) { Warn "OpenSSL installer hash differs from published value (continuing)." } else { Ok "installer hash verified" }
    Info "installing silently to $OpenSslRoot ..."
    Start-Process -FilePath $exe -ArgumentList '/SILENT', '/SP-', '/SUPPRESSMSGBOXES', "/DIR=$OpenSslRoot" -Wait
    Remove-Item $exe -Force
    if (-not (Test-Path (Join-Path $OpenSslRoot 'bin\libssl-3-x64.dll'))) { Die "OpenSSL install did not produce expected DLLs." }
    Ok "OpenSSL installed"
}
$env:OPENSSL_ROOT_DIR = $OpenSslRoot
[Environment]::SetEnvironmentVariable('OPENSSL_ROOT_DIR', $OpenSslRoot, 'Machine')
Ok "OPENSSL_ROOT_DIR = $OpenSslRoot"

# ==============================================================================
Step "4/6  MySQL Server 8.0 (zip, self-contained)  ->  $MySqlRoot"
$mysqld = Join-Path $MySqlRoot 'bin\mysqld.exe'
if (-not (Test-Path $mysqld)) {
    # Do not erase an existing database/configuration to repair a missing binary.
    if ((Test-Path (Join-Path $MySqlRoot 'data')) -or (Test-Path (Join-Path $MySqlRoot 'my.ini'))) {
        Die "MySQL binaries are missing but $MySqlRoot contains existing data/configuration. Nothing was deleted. Back it up and repair that installation manually."
    }

    $cacheZip = Join-Path $DownloadsDir 'mysql-8.0-winx64.zip'
    # Avoid the dev.mysql.com redirect that returned Oracle's 'Technical Difficulties'
    # page. Keep official archive redirects as fallbacks; all must pass the same hash.
    $directUrl = 'https://cdn.mysql.com/archives/mysql-8.0/mysql-8.0.43-winx64.zip'
    $oldUrl = 'https://dev.mysql.com/get/Downloads/MySQL-8.0/mysql-8.0.43-winx64.zip'
    if (($MySqlZipUrl -eq $oldUrl) -or ($MySqlZipUrl -eq $directUrl) -or (-not $MySqlZipUrl)) {
        $urls = @($directUrl, 'https://downloads.mysql.com/archives/get/p/23/file/mysql-8.0.43-winx64.zip')
    } else {
        # For a deliberately changed dependency version, edit the URL, size, hash
        # and top-folder settings together in kit-config.ps1.
        $urls = @($MySqlZipUrl)
    }
    $zip = Get-VerifiedMySqlZip -CachePath $cacheZip -LocalPath $MySqlZipPath -Urls $urls

    $stage = Join-Path $DownloadsDir ('mysql-extract-' + [Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Force -Path $stage | Out-Null
    try {
        Info "extracting verified ZIP ..."
        Expand-Archive -LiteralPath $zip -DestinationPath $stage -Force
        $inner = Join-Path $stage $MySqlZipTopFolder
        foreach ($required in @('bin\mysqld.exe', 'bin\mysql.exe', 'include\mysql.h', 'lib\libmysql.lib', 'lib\libmysql.dll')) {
            if (-not (Test-Path (Join-Path $inner $required) -PathType Leaf)) {
                throw "MySQL ZIP is missing $MySqlZipTopFolder\$required."
            }
        }
        # The data/config guard above prevents replacing an existing database.
        if (Test-Path $MySqlRoot) { Remove-Item $MySqlRoot -Recurse -Force }
        Move-Item -LiteralPath $inner -Destination $MySqlRoot
        if (-not $MySqlZipPath) { Remove-Item -LiteralPath $cacheZip -Force }
        Ok "MySQL extracted to $MySqlRoot"
    } finally {
        if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
    }
} else { Ok "MySQL already extracted" }

$dataDir = Join-Path $MySqlRoot 'data'
$myIni   = Join-Path $MySqlRoot 'my.ini'
if (-not (Test-Path $myIni)) {
    @"
[mysqld]
basedir=$($MySqlRoot -replace '\\','/')
datadir=$($dataDir -replace '\\','/')
port=$MySqlPort
bind-address=127.0.0.1
max_allowed_packet=1G
innodb_buffer_pool_size=512M
innodb_log_file_size=256M
character-set-server=utf8mb4
collation-server=utf8mb4_unicode_ci
# Leave name resolution enabled for the initial root@localhost TCP login.
# bind-address keeps this database local; root@127.0.0.1 is created after authentication.
log-error=$($MySqlRoot -replace '\\','/')/mysql-error.log
[client]
port=$MySqlPort
default-character-set=utf8mb4
"@ | Set-Content -Path $myIni -Encoding ASCII
    Ok "my.ini written (max_allowed_packet=1G - required for the 237 MB world dump)"
} else { Ok "my.ini already present" }

if (-not (Test-Path $dataDir)) {
    Info "initialising data directory ..."
    & $mysqld --defaults-file="$myIni" --initialize-insecure
    if ($LASTEXITCODE -ne 0) { Die "mysqld --initialize-insecure failed - see $MySqlRoot\mysql-error.log" }
    Ok "data directory initialised (root has empty password for the moment)"
} else { Ok "data directory already present" }

if (-not $SkipMySqlService) {
    $svc = Get-Service -Name 'LegionCoreMySQL' -ErrorAction SilentlyContinue
    if (-not $svc) {
        Info "installing Windows service 'LegionCoreMySQL' ..."
        & $mysqld --install LegionCoreMySQL --defaults-file="$myIni"
        if ($LASTEXITCODE -ne 0) { Die "Service install failed - start MySQL manually with: $mysqld --defaults-file=`"$myIni`" --console" }
    }
    $svc = Get-Service -Name 'LegionCoreMySQL' -ErrorAction SilentlyContinue
    if ($svc) {
        if ($svc.Status -ne 'Running') { Start-Service LegionCoreMySQL; Start-Sleep -Seconds 6 }
        Ok "service LegionCoreMySQL: $((Get-Service LegionCoreMySQL).Status)"
    } else {
        Die "Windows service LegionCoreMySQL was not found after installation. MySQL has not been verified."
    }
    Assert-LegionMySqlServiceTarget -ServerExe $mysqld -IniPath $myIni -Port $MySqlPort -HostName $MySqlHost
    $hostRepair = Disable-LegionBootstrapNameSkip -IniPath $myIni
    if ($hostRepair.Changed) {
        Warn "Previous kit configuration enabled skip-name-resolve before the TCP root account existed."
        Ok "my.ini backup saved: $($hostRepair.BackupPath)"
        Info "name resolution re-enabled; restarting only LegionCoreMySQL ..."
        Restart-Service -Name LegionCoreMySQL -ErrorAction Stop
        (Get-Service -Name LegionCoreMySQL).WaitForStatus([ServiceProcess.ServiceControllerStatus]::Running, [TimeSpan]::FromSeconds(30))
        Assert-LegionMySqlServiceTarget -ServerExe $mysqld -IniPath $myIni -Port $MySqlPort -HostName $MySqlHost
        Ok "LegionCoreMySQL restarted; existing data directory preserved"
    }
    $mysql = Join-Path $MySqlRoot 'bin\mysql.exe'
    function Invoke-RootMySqlQuery([string]$Password, [string]$Query) {
        Invoke-LegionMySql -Executable $mysql -HostName $MySqlHost -Port $MySqlPort `
            -User 'root' -Password $Password -Query $Query
    }

    # A rerun must first try the configured password, not assume root is still
    # passwordless. stderr is captured separately and only exit codes decide
    # success; harmless MySQL warnings cannot become NativeCommandError here.
    Info "checking MySQL readiness and root credentials ..."
    $ready = $false
    $blankRoot = $false
    $lastError = ''
    for ($i = 1; $i -le 10; $i++) {
        $configured = Invoke-RootMySqlQuery -Password $MySqlPass -Query 'SELECT 1;'
        if ($configured.ExitCode -eq 0 -and $configured.StdOut.Trim() -eq '1') {
            $ready = $true
            break
        }
        $empty = Invoke-RootMySqlQuery -Password '' -Query 'SELECT 1;'
        if ($empty.ExitCode -eq 0 -and $empty.StdOut.Trim() -eq '1') {
            $ready = $true
            $blankRoot = $true
            break
        }
        $lastError = (($configured.StdErr, $empty.StdErr) -join "`n").Trim()
        # Access denied from both probes is a credential issue, not slow startup.
        if ($configured.StdErr -match 'ERROR 1130' -or $empty.StdErr -match 'ERROR 1130') { break }
        if ($configured.StdErr -match 'ERROR 1045' -and $empty.StdErr -match 'ERROR 1045') { break }
        if ($i -lt 10) { Start-Sleep -Seconds 3 }
    }
    if (-not $ready) {
        if ($lastError -match 'ERROR 1130') {
            Die "MySQL is rejecting the loopback host BEFORE password authentication (ERROR 1130). This is not a wrong-password error. Check whether name resolution is still disabled or local account grants are missing. Do not delete data or disable authentication.`n$lastError"
        }
        Die "MySQL did not accept the configured root password or the initial empty password. Do not delete the data directory. Check `$MySqlPass in kit-config.ps1 and $MySqlRoot\mysql-error.log.`n$lastError"
    }

    # Always ensure the exact TCP loopback account exists, including reruns
    # where root@localhost already has the configured password. Never add root@%.
    $pwSql = $MySqlPass.Replace('\', '\\').Replace("'", "''").Replace("`r", '\r').Replace("`n", '\n')
    $accountSql = "SET SESSION sql_mode = ''; "
    $bootstrapPassword = $MySqlPass
    if ($blankRoot) {
        Info "setting the initial root password from kit-config.ps1 ..."
        $bootstrapPassword = ''
        $accountSql += "ALTER USER 'root'@'localhost' IDENTIFIED BY '$pwSql'; "
    } else {
        Ok "configured root password already works"
    }
    $accountSql += "CREATE USER IF NOT EXISTS 'root'@'127.0.0.1' IDENTIFIED BY '$pwSql'; "
    if ($blankRoot) {
        $accountSql += "ALTER USER 'root'@'127.0.0.1' IDENTIFIED BY '$pwSql'; "
    }
    $accountSql += "GRANT ALL PRIVILEGES ON *.* TO 'root'@'127.0.0.1' WITH GRANT OPTION;"
    $accountResult = Invoke-RootMySqlQuery -Password $bootstrapPassword -Query $accountSql
    if ($accountResult.ExitCode -ne 0) {
        Die "MySQL loopback-account setup failed (exit $($accountResult.ExitCode)).`n$($accountResult.StdErr)"
    }
    if ($blankRoot) { Ok "initial root password set" }
    Ok "TCP loopback root account ready (root@127.0.0.1)"
    $verified = Invoke-RootMySqlQuery -Password $MySqlPass -Query 'SELECT 1;'
    if ($verified.ExitCode -ne 0 -or $verified.StdOut.Trim() -ne '1') {
        Die "MySQL connection verification failed (exit $($verified.ExitCode)).`n$($verified.StdErr)"
    }
    Ok "MySQL connection verified (SELECT 1 -> 1)"

}
$env:MYSQL_ROOT_DIR = $MySqlRoot
[Environment]::SetEnvironmentVariable('MYSQL_ROOT_DIR', $MySqlRoot, 'Machine')
Ok "MYSQL_ROOT_DIR = $MySqlRoot"

# ==============================================================================
Step "5/6  Checking that the MSVC compiler is reachable"
$vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
if (Test-Path $vswhere) {
    $vcPath = & $vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
    if ($vcPath) { Ok "MSVC: $vcPath" } else { Warn "MSVC component not found - re-run the VS Build Tools installer." }
} else { Warn "vswhere not found - is Visual Studio Build Tools installed?" }

# ==============================================================================
Step "6/6  Summary"
$mySqlStatus = if ($SkipMySqlService) { "binaries only; service setup and SQL checks skipped" } else { "service: LegionCoreMySQL; SQL connection verified" }
Write-Host @"

  Installed / verified:
    Boost      : $BoostRoot\boost
    OpenSSL    : $OpenSslRoot
    MySQL      : $MySqlRoot   ($mySqlStatus)
    Downloads  : $DownloadsDir

  Next step: 2-Build-Core.ps1
"@ -ForegroundColor Green
