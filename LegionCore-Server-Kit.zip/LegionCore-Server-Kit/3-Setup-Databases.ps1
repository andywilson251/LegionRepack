<#
================================================================================
 LegionCore 7.3.5 - Server Kit : STEP 3  -  create ALL server databases
================================================================================
 Creates and fills the four databases the core needs:

    auth        - accounts, realmlist          (from sql/base/auth_database.sql)
    characters  - characters/inventory/etc.    (from sql/base/characters_database.sql)
    world       - the whole game world         (from official release asset, 237 MB)
    hotfixes    - client hotfix data           (from official release asset, 31 MB)

 It then applies every pending SQL update exactly the way worldserver.exe would
 (same file list from `updates_include`, same SHA1 tracking rows), configures the
 realmlist row and creates/updates the admin account.

 Run:   powershell -ExecutionPolicy Bypass -File .\3-Setup-Databases.ps1
 Options:  -BaseDumpDir <dir>   use already-extracted dump .sql files (skip download)
           -Force               drop and rebuild even if the databases exist
================================================================================
#>
#Requires -Version 5.1
[CmdletBinding()]
param(
    [string]$BaseDumpDir,
    [switch]$Force
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'kit-config.ps1')
. (Join-Path $PSScriptRoot 'tools\MySql-Client.ps1')
. (Join-Path $PSScriptRoot 'tools\Sql-Updates.ps1')

function Step($m) { Write-Host "`n=== $m" -ForegroundColor Cyan }
function Ok($m)   { Write-Host "  [ok] $m" -ForegroundColor Green }
function Info($m) { Write-Host "  $m" -ForegroundColor Gray }
function Warn($m) { Write-Host "  [!!] $m" -ForegroundColor Yellow }
function Die($m)  { Write-Host "`n  [XX] $m" -ForegroundColor Red; exit 1 }

$script:Fail = 0

# ------------------------------------------------------------------------------
# helpers
# ------------------------------------------------------------------------------
function Find-MySqlClient {
    $cand = @(
        (Join-Path $MySqlRoot 'bin\mysql.exe'),
        "$env:ProgramFiles\MySQL\MySQL Server 8.0\bin\mysql.exe",
        "$env:ProgramFiles\MySQL\MySQL Server 8.4\bin\mysql.exe",
        "${env:ProgramFiles(x86)}\MySQL\MySQL Server 8.0\bin\mysql.exe"
    )
    foreach ($c in $cand) { if ($c -and (Test-Path $c)) { return $c } }
    foreach ($n in 'mysql.exe','mysql','mariadb') {
        $g = Get-Command $n -ErrorAction SilentlyContinue
        if ($g) { return $g.Source }
    }
    return $null
}

function Invoke-MySqlQuery {
    param([string]$Query, [string]$Database = '')
    $result = Invoke-LegionMySql -Executable $script:MySqlExe -HostName $MySqlHost -Port $MySqlPort `
        -User $MySqlUser -Password $MySqlPass -Query $Query -Database $Database
    if ($result.ExitCode -ne 0) { throw "MySQL query failed (exit $($result.ExitCode)).`n$($result.StdErr)" }
    if ($result.StdErr) { Write-Verbose $result.StdErr.Trim() }
    return $result.StdOut.Trim()
}

function Import-SqlFile {
    param([string]$File, [string]$Database)
    if (-not (Test-Path -LiteralPath $File -PathType Leaf)) { Die "SQL file not found: $File" }
    $result = Invoke-LegionMySql -Executable $script:MySqlExe -HostName $MySqlHost -Port $MySqlPort `
        -User $MySqlUser -Password $MySqlPass -InputFile $File -Database $Database
    if ($result.ExitCode -ne 0) {
        $err = (($result.StdErr -split '\r?\n' | Select-Object -First 12) -join "`n").Trim()
        Die "Import of $(Split-Path $File -Leaf) into '$Database' failed (exit $($result.ExitCode)).`n$err"
    }
    if ($result.StdErr) { Write-Verbose $result.StdErr.Trim() }
}

function Get-SqlTree {
    if (Test-Path (Join-Path $SourceDir 'sql\updates')) { return (Join-Path $SourceDir 'sql') }
    if (Test-Path (Join-Path $PSScriptRoot 'sql\updates')) { return (Join-Path $PSScriptRoot 'sql') }
    Die "Could not find the 'sql' tree (run 2-Build-Core.ps1 first, or keep the kit's sql\ folder)."
}

function Get-DbTableCount {
    param([string]$Database)
    $v = Invoke-MySqlQuery -Query "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='$Database';"
    return [int]$v
}

# ==============================================================================
# 0. prerequisites
# ==============================================================================
Step "Checking MySQL client and server"
$script:MySqlExe = Find-MySqlClient
if (-not $script:MySqlExe) {
    Die ("mysql.exe not found. Install MySQL 8.0 (run 1-Install-Prerequisites.ps1) `n" +
         "       or edit `$MySqlRoot / `$MySqlPass in kit-config.ps1.")
}
Ok "client: $script:MySqlExe"
try {
    $ver = Invoke-MySqlQuery "SELECT VERSION();"
    Ok "server: $ver  ($MySqlHost`:$MySqlPort as $MySqlUser)"
} catch {
    Die "Cannot connect to MySQL at $MySqlHost`:$MySqlPort as '$MySqlUser'. Is the service running`n       and is `$MySqlPass correct in kit-config.ps1?  ($_)"
}
$maxPacket = Invoke-MySqlQuery "SELECT @@max_allowed_packet/1024/1024;"
if ([double]$maxPacket -lt 256) {
    Warn "server max_allowed_packet is only $maxPacket MB - the 237 MB world dump may fail.`n       Set max_allowed_packet=1G in my.ini (1-Install-Prerequisites.ps1 does this)."
} else { Ok "max_allowed_packet: $maxPacket MB" }

$SqlTree = Get-SqlTree
Ok "SQL tree: $SqlTree"

# ==============================================================================
# 1. base world/hotfixes dumps (download once, verify, reuse)
# ==============================================================================
Step "Locating the base world + hotfixes database dumps"
$worldDump = $null; $hotfixDump = $null

function Test-Dumps([string]$Dir) {
    $w = Join-Path $Dir $BaseWorldFile
    $h = Join-Path $Dir $BaseHotfixesFile
    if ((Test-Path $w) -and (Test-Path $h)) { return @($w, $h) }
    return $null
}

if ($BaseDumpDir) {
    $r = Test-Dumps $BaseDumpDir
    if (-not $r) { Die "BaseDumpDir '$BaseDumpDir' does not contain $BaseWorldFile and $BaseHotfixesFile." }
    $worldDump, $hotfixDump = $r
    Ok "using dumps from -BaseDumpDir"
} else {
    foreach ($d in @($ServerDir, $DownloadsDir, $PSScriptRoot)) {
        $r = Test-Dumps $d
        if ($r) { $worldDump, $hotfixDump = $r; break }
    }
    if ($worldDump) {
        Ok "using existing dumps in $(Split-Path $worldDump -Parent)"
    } else {
        Info "not present yet - downloading the official release asset (33 MB) ..."
        New-Item -ItemType Directory -Force -Path $DownloadsDir | Out-Null
        $arc = Join-Path $DownloadsDir 'LegionCore_full.7z'
        if (-not (Test-Path $arc)) {
            $ProgressPreference = 'SilentlyContinue'
            Invoke-WebRequest -Uri $BaseDatabaseUrl -OutFile $arc -UseBasicParsing
        }
        Info "verifying SHA256 ..."
        $h = (Get-FileHash -Path $arc -Algorithm SHA256).Hash
        if ($h -ne $BaseDatabase7zSha256) {
            Remove-Item $arc -Force
            Die "Downloaded archive is corrupt (SHA256 $h). Re-run the script to download again."
        }
        Ok "archive verified"

        Info "extracting (needs 7-Zip / tar) ..."
        New-Item -ItemType Directory -Force -Path $ServerDir | Out-Null
        $sevenZip = $null
        foreach ($c in @('7z.exe','7za.exe', "$env:ProgramFiles\7-Zip\7z.exe")) {
            $g = Get-Command $c -ErrorAction SilentlyContinue
            if ($g) { $sevenZip = $g.Source; break }
            if (Test-Path $c) { $sevenZip = $c; break }
        }
        if (-not $sevenZip) {
            $zr = Join-Path $DownloadsDir '7zr.exe'
            if (-not (Test-Path $zr)) {
                Info "downloading standalone 7zr.exe ..."
                Invoke-WebRequest -Uri $SevenZipUrl -OutFile $zr -UseBasicParsing
            }
            $sevenZip = $zr
        }
        & $sevenZip x -y "-o$ServerDir" $arc | Out-Null
        if ($LASTEXITCODE -ne 0) {
            # Windows 10's built-in bsdtar can also read .7z
            & tar -xf $arc -C $ServerDir
            if ($LASTEXITCODE -ne 0) { Die "Extraction failed. Install 7-Zip (winget install 7zip.7zip) and re-run." }
        }
        $r = Test-Dumps $ServerDir
        if (-not $r) { Die "Extraction did not produce the expected .sql files in $ServerDir." }
        $worldDump, $hotfixDump = $r
        Ok "extracted to $ServerDir (worldserver's own auto-populate can use them from here too)"
    }
}

Info "world:    $worldDump"
Info "hotfixes: $hotfixDump"
$wHash = (Get-FileHash -Path $worldDump -Algorithm SHA256).Hash
$hHash = (Get-FileHash -Path $hotfixDump -Algorithm SHA256).Hash
if ($wHash -eq $BaseWorldSha256)   { Ok "world dump SHA256 verified" }    else { Warn "world dump SHA256 differs from the official release (got $wHash)" }
if ($hHash -eq $BaseHotfixesSha256){ Ok "hotfixes dump SHA256 verified" } else { Warn "hotfixes dump SHA256 differs from the official release (got $hHash)" }

# ==============================================================================
# 2. create the four databases
# ==============================================================================
Step "Creating databases (utf8mb4 / utf8mb4_unicode_ci)"
$Dbs = @('auth','characters','world','hotfixes')
foreach ($db in $Dbs) {
    if ($Force) { Invoke-MySqlQuery "DROP DATABASE IF EXISTS ``$db``;" | Out-Null }
    Invoke-MySqlQuery "CREATE DATABASE IF NOT EXISTS ``$db`` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" | Out-Null
    Ok "$db (tables: $(Get-DbTableCount $db))"
}

# ==============================================================================
# 3. import the base data
# ==============================================================================
Step "Importing base data (skips databases that are already populated)"
$plan = @(
    @{ db='auth';       file=(Join-Path $SqlTree 'base\auth_database.sql');        label='auth base' },
    @{ db='characters'; file=(Join-Path $SqlTree 'base\characters_database.sql');  label='characters base' },
    @{ db='world';      file=$worldDump;                                           label='world base (237 MB, takes a few minutes)' },
    @{ db='hotfixes';   file=$hotfixDump;                                          label='hotfixes base (31 MB)' }
)
foreach ($p in $plan) {
    $n = Get-DbTableCount $p.db
    if ($n -gt 0) { Ok "$($p.db): already has $n tables - skipped (use -Force to rebuild)"; continue }
    $sizeMB = [math]::Round((Get-Item $p.file).Length / 1MB, 1)
    $sw = [Diagnostics.Stopwatch]::StartNew()
    Info "importing $($p.label) [$sizeMB MB] ..."
    Import-SqlFile -File $p.file -Database $p.db
    $sw.Stop()
    Ok "$($p.db): imported in $([math]::Round($sw.Elapsed.TotalSeconds,1))s - tables: $(Get-DbTableCount $p.db)"
}

# ==============================================================================
# 4. apply the SQL updates exactly like the core's DBUpdater
# ==============================================================================
Step "Applying pending SQL updates"
$totalApplied = 0
foreach ($db in $Dbs) {
    $dirPlans = @(
        @{ dir = (Join-Path $SqlTree "old\$db");     state = 'ARCHIVED' },
        @{ dir = (Join-Path $SqlTree "updates\$db"); state = 'RELEASED' }
    )
    $appliedDb = 0
    foreach ($dp in $dirPlans) {
        if (-not (Test-Path $dp.dir)) { continue }
        # IMPORTANT: sort ordinally (byte order), exactly like the core's
        # std::string path comparison does. PowerShell's default Sort-Object is
        # culture-aware and would order "x_difficulty_data.sql" BEFORE
        # "x_difficulty.sql", applying dependent updates in the wrong order.
        $byName = @{}
        foreach ($f in (Get-ChildItem -Path $dp.dir -Filter '*.sql')) { $byName[$f.Name] = $f }
        $ordered = [string[]]($byName.Keys)
        [Array]::Sort($ordered, [StringComparer]::Ordinal)
        foreach ($name in $ordered) {
            $f = $byName[$name]
            $seen = [int](Invoke-MySqlQuery -Database $db -Query "SELECT COUNT(*) FROM ``updates`` WHERE ``name``='$name';")
            if ($seen -gt 0) { continue }
            Write-Host "      $name" -ForegroundColor DarkGray
            Import-SqlFile -File $f.FullName -Database $db
            # Must match what the core computes at startup: it reads the file in
            # text mode, so on Windows CRLF becomes LF before the SHA1 is taken.
            # Get-FileHash would hash the raw bytes and every file in a CRLF
            # checkout would look "changed" on the next server start.
            $sha = Get-LegionSqlUpdateHash -Path $f.FullName
            Invoke-MySqlQuery -Database $db -Query "REPLACE INTO ``updates`` (``name``,``hash``,``state``,``speed``) VALUES ('$name','$sha','$($dp.state)',0);" | Out-Null
            $appliedDb++; $totalApplied++
        }
    }
    if ($appliedDb -eq 0) { Ok "${db}: up to date (0 pending)" } else { Ok "${db}: applied $appliedDb update(s)" }
}
Info "total updates applied this run: $totalApplied"

# ==============================================================================
# 5. realmlist
# ==============================================================================
Step "Configuring the realmlist row"
$realm = Invoke-MySqlQuery -Database 'auth' -Query "SELECT COUNT(*) FROM ``realmlist`` WHERE ``id``=1;"
if ([int]$realm -eq 0) {
    Invoke-MySqlQuery -Database 'auth' -Query "INSERT INTO ``realmlist`` (``id``,``name``,``address``,``localAddress``,``port``,``gamebuild``) VALUES (1,'$RealmName','$RealmAddress','$RealmAddress',$WorldPort,26972);" | Out-Null
    Ok "realmlist row created"
} else {
    Invoke-MySqlQuery -Database 'auth' -Query "UPDATE ``realmlist`` SET ``name``='$RealmName', ``address``='$RealmAddress', ``localAddress``='$RealmAddress', ``port``=$WorldPort, ``gamebuild``=26972 WHERE ``id``=1;" | Out-Null
    Ok "realmlist row updated"
}
$rl = Invoke-MySqlQuery -Database 'auth' -Query "SELECT CONCAT(name,' | ',address,':',port,' | build ',gamebuild) FROM ``realmlist`` WHERE id=1;"
Info "realm: $rl"

# ==============================================================================
# 6. admin account  (uses the exact hash algorithm of AccountMgr.cpp)
# ==============================================================================
Step "Creating / updating the admin account"
function Get-AccountPasswordHash {
    param([string]$User, [string]$Password)
    $u = $User.ToUpperInvariant()
    $pw = $Password.ToUpperInvariant()
    if ($u -match '[^\x20-\x7E]' -or $pw -match '[^\x20-\x7E]') {
        Warn "login/password contain non-ASCII characters - use ASCII only (core converts latin1)"
    }
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $h1  = $sha.ComputeHash([Text.Encoding]::ASCII.GetBytes($u))
        $hex = -join ($h1 | ForEach-Object { $_.ToString('X2') })
        $h2  = $sha.ComputeHash([Text.Encoding]::ASCII.GetBytes(($hex + ':' + $pw)))
        [array]::Reverse($h2)
        return (-join ($h2 | ForEach-Object { $_.ToString('X2') }))
    } finally { $sha.Dispose() }
}

$hash = Get-AccountPasswordHash -User $AdminLogin -Password $AdminPassword
Invoke-MySqlQuery -Database 'auth' -Query "INSERT INTO ``account`` (``username``,``sha_pass_hash``,``joindate``) VALUES ('$AdminLogin','$hash',NOW()) ON DUPLICATE KEY UPDATE ``sha_pass_hash``=VALUES(``sha_pass_hash``), ``v``='', ``s``='';" | Out-Null
$accId = Invoke-MySqlQuery -Database 'auth' -Query "SELECT ``id`` FROM ``account`` WHERE ``username``='$AdminLogin';"
Invoke-MySqlQuery -Database 'auth' -Query "REPLACE INTO ``account_access`` (``id``,``gmlevel``,``RealmID``,``comments``) VALUES ($accId,$AdminGmLevel,-1,'server kit');" | Out-Null
Ok "account '$AdminLogin' (id $accId) ready - password '$AdminPassword', gmlevel $AdminGmLevel"

# ==============================================================================
# 7. verification summary
# ==============================================================================
Step "Verification"
# table counts AFTER the update files are applied (some updates intentionally drop
# leftover tables from the base dump, so these are lower than the fresh-import counts
# of auth 34 / characters 146 / world 281 / hotfixes 813)
$expected = @{ auth=22; characters=140; world=281; hotfixes=813 }
foreach ($db in $Dbs) {
    $n = Get-DbTableCount $db
    $exp = $expected[$db]
    if ($n -lt $exp) { $script:Fail = 1 }
    Write-Host ("  {0,-11} tables {1,-5} (expected >= {2})   updates recorded: {3}" -f $db, $n, $exp, (Invoke-MySqlQuery -Database $db -Query "SELECT COUNT(*) FROM ``updates``;")) -ForegroundColor $(if ($n -ge $exp) { 'Gray' } else { 'Yellow' })
}
$pending = 0
foreach ($db in $Dbs) {
    foreach ($sub in @('old', 'updates')) {
        $dir = Join-Path $SqlTree "$sub\$db"
        if (-not (Test-Path $dir)) { continue }
        foreach ($f in (Get-ChildItem -Path $dir -Filter '*.sql')) {
            $seen = [int](Invoke-MySqlQuery -Database $db -Query "SELECT COUNT(*) FROM ``updates`` WHERE ``name``='$($f.Name)';")
            if ($seen -eq 0) { Warn "pending: $db/$($f.Name)"; $pending++; $script:Fail = 1 }
        }
    }
}
if ($pending -eq 0) { Ok "no pending updates - worldserver.exe will report 'database is up-to-date'" }

$keyTables = @(
    @{ q = "SELECT COUNT(*) FROM world.creature_template;";    label = 'world.creature_template' },
    @{ q = "SELECT COUNT(*) FROM world.gameobject_template;";  label = 'world.gameobject_template' },
    @{ q = "SELECT COUNT(*) FROM world.quest_template;";       label = 'world.quest_template' },
    @{ q = "SELECT COUNT(*) FROM hotfixes.item;";              label = 'hotfixes.item' },
    @{ q = "SELECT COUNT(*) FROM auth.account;";               label = 'auth.account' },
    @{ q = "SELECT COUNT(*) FROM auth.realmlist;";             label = 'auth.realmlist' }
)
foreach ($t in $keyTables) {
    $v = Invoke-MySqlQuery $t.q
    if ([int64]$v -le 0) { $script:Fail = 1; Warn "$($t.label) = $v" } else { Info "$($t.label) = $v" }
}

Write-Host ""
if ($script:Fail -eq 0) {
    Write-Host "  RESULT: SUCCESS - all four databases are created, populated and up to date." -ForegroundColor Green
    Write-Host "  Next: 4-Start-Server.bat   (log in with: $AdminLogin / $AdminPassword)" -ForegroundColor Green
} else {
    Write-Host "  RESULT: finished with warnings - review the messages above." -ForegroundColor Yellow
}
