# LegionCore 7.3.5 Server Kit — Windows 10/11

Everything needed to build and run a **[LegionCore 7.3.5](https://github.com/The-Legion-Preservation-Project/LegionCore-7.3.5)**
server (WoW Legion, build **26972**) on your own PC, as a set of numbered scripts.

> **What you have to bring:** a **WoW 7.3.5 (build 26972) game client**.
> Without the client there is nothing to log in with and no files to extract.
> The kit builds the server from the official GitHub source and creates all four
> databases from the official release files — the client is the only piece that
> cannot be automated.

---

## What gets installed / created

| Where | What |
|---|---|
| `C:\libs\boost` | Boost 1.84 (prebuilt, MSVC v143, static) |
| `C:\libs\openssl` | OpenSSL 3.x x64 |
| `C:\libs\mysql-8.0` | MySQL Server 8.0 (zip, no installer) + service `LegionCoreMySQL` |
| `C:\LegionCore\source` | git clone of LegionCore-7.3.5 |
| `C:\LegionCore\build` | CMake build tree (Ninja or Visual Studio 2022) |
| `C:\LegionCore\logs` | complete configure/build output and executable smoke-test logs |
| `C:\LegionCore\server` | `worldserver.exe`, `bnetserver.exe`, extractor tools, configs, DLLs |
| `C:\LegionCore\ClientData` | `dbc`, `maps`, `vmaps`, `mmaps`, `cameras`, `gt` (extracted from your client) |
| MySQL databases | `auth`, `characters`, `world`, `hotfixes` |

All paths/passwords are set in **`kit-config.ps1`** — edit that one file, nothing else.

---

## Requirements

- Windows 10 or 11 (x64), **Administrator** access
- ~40 GB free disk (build ≈ 8 GB, extracted client data ≈ 15–30 GB)
- A **WoW 7.3.5 build 26972 client** — it needs a `Data\` folder containing `Data\config` and `Data\data`.
  A missing `.build.info` is rebuilt for you by step 5 (see *Client data extraction* below).
- Internet connection (about 1 GB of downloads: VS Build Tools, Boost, OpenSSL, MySQL, world DB, plus the git clone)
- Time: 30–90 min for the build + 1.5–4 h for the (one-time) client data extraction

## Quick start

Run **every** script from an **Administrator PowerShell** in the kit folder
(`-ExecutionPolicy Bypass` avoids script-signing issues):

```powershell
cd C:\path\to\LegionCore-Server-Kit

# 0) EDIT kit-config.ps1  ->  set $ClientDir to your WoW folder
notepad kit-config.ps1

# 1) install VS2022 Build Tools, CMake/Ninja/Git/7-Zip, Boost, OpenSSL, MySQL   (~20 min)
powershell -ExecutionPolicy Bypass -File .\1-Install-Prerequisites.ps1

# 2) build worldserver.exe + bnetserver.exe + tools                              (30-90 min)
powershell -ExecutionPolicy Bypass -File .\2-Build-Core.ps1

# 3) create + fill ALL FOUR databases (downloads the 33 MB world/hotfixes dump)  (5-15 min)
powershell -ExecutionPolicy Bypass -File .\3-Setup-Databases.ps1

# 4) extract client data — START THIS AND WALK AWAY, it is the long step         (1.5-4 h)
#    (a client with no .build.info is handled automatically)
powershell -ExecutionPolicy Bypass -File .\5-Extract-Client-Data.ps1

# 5) start the server
.\4-Start-Server.bat

# 6) (optional) create more accounts
powershell -ExecutionPolicy Bypass -File .\6-Create-Account.ps1 -Login "friend@realm" -Password "secret"
```

### If the MySQL download fails (Oracle "Technical Difficulties")

Use the repaired `1-Install-Prerequisites.ps1` (2026-10-11) and run step 1 again. It uses
Oracle's direct archive URL, verifies the ZIP, and discards partial downloads. It is
compatible with your original `kit-config.ps1`, so keep your edited settings. The
latest installer also needs `tools/MySql-Client.ps1`; copy the entire repair ZIP
into the kit folder, including its `tools` subfolder.
For a browser-downloaded ZIP, use `-MySqlZipPath "C:\path\to\mysql-8.0.43-winx64.zip"`.
See [troubleshooting section 11](docs/TROUBLESHOOTING.md#11-step-1-oracle-technical-difficulties--invoke-webrequest-fails-downloading-mysql).

### If MySQL's password warning becomes `NativeCommandError`

The warning itself is a security advisory, not a database failure, but the original
Windows PowerShell error handling can abort the installer on that warning. Apply
`LegionCore-MySQL-PowerShell-Fix.zip` to the existing kit folder, including its
`tools` subfolder, and rerun step 1. Keep your existing `kit-config.ps1` and data.
The fix uses protected temporary credentials, separates stdout/stderr and checks
real exit codes. Steps 3 and 6 use the same transport so the issue does not recur.
See [troubleshooting section 12](docs/TROUBLESHOOTING.md#12-step-1-mysql-password-warning-becomes-nativecommanderror).

### If MySQL says `Host 127.0.0.1 is not allowed` (ERROR 1130)

The original configuration enabled `skip-name-resolve` before creating the TCP root
account. Apply `LegionCore-MySQL-Host-Fix.zip` and rerun step 1. The installer matches
service/port ownership, backs up and repairs the legacy config, briefly restarts the
kit's service, and verifies the exact loopback account. Keep your configuration and
data; **do not reset MySQL**. See [troubleshooting section 13](docs/TROUBLESHOOTING.md#13-step-1-error-1130-host-127001-is-not-allowed-to-connect).

### If the old check reports a port conflict

The previous check can confuse Windows MySQL's normal monitor/server child PIDs.
Apply `LegionCore-MySQL-Monitor-Fix.zip` and rerun step 1 before stopping any other
service or changing ports. If it still stops, run the included read-only
`tools/Show-MySql-Port.ps1` and share its output. See [troubleshooting section 14](docs/TROUBLESHOOTING.md#14-port-3306-belongs-to-a-different-process-from-the-old-ownership-check).

### If step 2 stops at `CMake Warning:` / `NativeCommandError`

Apply **`LegionCore-Build-Fix.zip`** to the existing kit folder, including its required
`tools/Native-Tools.ps1`, and rerun **step 2 only**. Keep your edited `kit-config.ps1`,
source, libraries and database data; do not use `-Clean` for this repair. The script
now shows and logs complete native output, checks actual exit codes, keeps each CMake
`-D` path option in a single argument, and explicitly selects `RelWithDebInfo` for the
Visual Studio fallback. Missing Ninja is not itself an error. Existing supported
build generators are reused. If configure still fails, share
`C:\LegionCore\logs\cmake-configure.log`; for a compiler/linker failure share
`cmake-build.log` in that folder. See [troubleshooting section 15](docs/TROUBLESHOOTING.md#15-step-2-cmake-warning--nativecommanderror).

### If step 2 links the servers but extraction tools fail with `LNK2019` / `LNK1120`

Apply **`LegionCore-Linker-Fix.zip`**, including `tools/Native-Tools.ps1`, and rerun
step 2 without `-Clean`. The previous kit forced experimental dynamic scripts/core;
`DB2Record` and several `VMAP` classes do not export the symbols the tools need on
Windows. The kit now selects the repository/Windows-CI default **static scripts**
and explicitly disables dynamic core linking. All default script modules, both
servers and **all five tools** remain enabled. External MySQL/OpenSSL DLLs are still
required and copied.

CMake reconfigures the existing build tree; expect affected targets to rebuild.
No MySQL reinstall, database reset, source-header edits or Boost replacement is
part of this repair. Deployment uses the current configuration's `cmake --install`
rules, keeps edited runtime configs, and requires every tool and successful server
`--version` probes before reporting completion. See [troubleshooting section 16](docs/TROUBLESHOOTING.md#16-step-2-linker-errors-for-db2record--vmap-in-the-extraction-tools).

### Logging in

| Login | Password | Rights |
|---|---|---|
| `GM@GM` | `admin` | administrator (gmlevel 6) |

This account ships with the world database (it is the project's own example account).
`6-Create-Account.ps1` adds/resets accounts; GM levels are
`0` player, `1` moderator, `2` game master, `6` administrator, `7` console.

In the client, the login name must be typed **exactly** as stored
(the project's style is `name@name`, e.g. `GM@GM`) — ASCII only.

---

## The scripts

| Script | Purpose | Notes |
|---|---|---|
| `kit-config.ps1` | all settings: paths, MySQL password, realm name/address, admin account | edit first |
| `1-Install-Prerequisites.ps1` | winget: VS2022 Build Tools, CMake, Ninja, Git, 7-Zip; downloads Boost/OpenSSL/MySQL; initialises MySQL and installs it as a service | idempotent |
| `2-Build-Core.ps1` | clones the source, uses the project's default static scripts/core (−DTOOLS=ON, Ninja/MSVC or VS2022 x64), builds, installs current targets + runtime DLLs and seeds missing configs into `C:\LegionCore\server`, smoke-tests `--version` | `-Jobs 4` to limit CPU; configure/build/install output in `logs`; needs `tools/Native-Tools.ps1` |
| `3-Setup-Databases.ps1` | creates `auth`/`characters`/`world`/`hotfixes`, imports both base dumps, applies every pending SQL update **the same way worldserver does** (same file order, same SHA1 tracking rows), sets the realmlist, creates the admin account, then verifies everything | `-Force` rebuilds, `-BaseDumpDir <dir>` reuses dumps |
| `4-Start-Server.bat` / `4-Stop-Server.bat` | start/stop bnetserver + worldserver | |
| `5-Extract-Client-Data.ps1` | rebuilds `.build.info` if the client has none, self-tests the storage, then runs `mapextractor`, `vmap4extractor`, `vmap4assembler`, `mmaps_generator` and verifies what they produced | `-SkipMmaps` for a quick test, `-Threads 8`, `-ClientLocale deDE`, `-NoClientWrite`, `-RebuildBuildInfo`, `-SkipProbe`; needs `tools/Casc-BuildInfo.ps1` |
| `6-Create-Account.ps1` | creates/resets a game account (uses the core's exact password hash) | |
| `7-Install-PlayerBots.ps1` | installs the PlayerBots module (world population bots) into the source tree, world DB and worldserver.conf | `-DryRun`, `-SkipSql`, `-SkipSource`; see docs/PLAYERBOTS.md |
| | *if an earlier copy failed with `Find-MySqlClient is not recognized`, that was a bug in the first release - use this one and just run it again* | see docs/TROUBLESHOOTING.md §19 |
| `Check-Kit-Files.ps1` | finds every copy of the PlayerBots scripts on disk and marks each one as the fixed version or the broken first release | `-Root <folder>` |
| | *if the build fails with `error C2513` in PlayerBotMgr.cpp, that was a `near` identifier clashing with a Windows macro - fixed here* | see docs/TROUBLESHOOTING.md §20 |
| | *if `.bots` reports PlayerBots disabled after a successful install, the block went to a config the server never reads - re-run the installer, no rebuild needed* | see docs/TROUBLESHOOTING.md §21 |
| | *if bots spawn white and the server crashes, that was a player display ID plus a packed-field write - re-run the installer and rebuild* | see docs/TROUBLESHOOTING.md §22 |
| | *to check the bot spell ids against your own client data, log in and run `.bots spells`* | see docs/PLAYERBOTS.md |
| `tools/patch-core.py` | the WorldSession patch real player-bots need; applied by the installer, revert with `-RevertCorePatch` | see docs/PLAYERBOTS.md |
| `Repair-Update-Hashes.ps1` | fixes `Reapplying update ... (it changed)` / `ERROR 1051` at worldserver startup by correcting the SHA1 values in the `updates` tables | `-DryRun`, `-Force`, `-SourceDir`; see docs/TROUBLESHOOTING.md §18 |

## Client data extraction (step 5)

The four extraction tools read the client through its CASC storage, and CASC needs
one small metadata file at the top of the client folder: `.build.info`. Many copies
of 7.3.5 (repacks, folders moved between machines, clients restored from a backup)
no longer have it, and without it every tool stops with `FILE_NOT_FOUND`.

Step 5 handles that by itself:

1. It reads the client's own `Data\config` files, verifies each one against its MD5
   filename exactly the way CascLib does, and sorts out which is the build
   configuration (build **26972** is preferred) and which is the CDN configuration.
2. It writes a `.build.info` describing those files. Nothing is downloaded, and no
   game data is touched — the only new file is `.build.info` itself (delete it to
   undo). With `-NoClientWrite` even that is avoided: the file goes to
   `C:\LegionCore\client-root`, which links back to your client's `Data` folder.
3. It runs a short self-test (`mapextractor -e 8`) before the long extraction, and
   if the client holds several build configurations it retries with the next one.
4. Afterwards it checks what each tool actually produced. The extractors exit with
   code 0 even when they fail to open the storage, so the kit inspects their output
   and counts the resulting files instead of trusting the exit code.

Useful switches:

| Switch | What it does |
|---|---|
| `-SkipMmaps` | skip the multi-hour movement-map step (run it later; creature pathing needs it) |
| `-Threads 8` | thread count for `mmaps_generator` |
| `-ClientLocale deDE` | force the client language if detection picks the wrong one (symptom: no `.db2` files) |
| `-NoClientWrite` | never write into the client folder |
| `-RebuildBuildInfo` | replace an existing `.build.info` (the old one is backed up first) |
| `-SkipProbe` | skip the self-test and start extracting immediately |

If the client already has a working `.build.info`, step 5 leaves it untouched.

## Client preparation (7.3.5 specifics)

1. **Realmlist / portal**: in the client's `WTF\Config.wtf` make sure you have
   `SET portal "127.0.0.1"` (or your LAN/public IP if you changed `$RealmAddress`).
2. **Executable patch**: run the built `connection_patcher.exe` once on the client
   executable — it produces a patched copy (e.g. `Wow_patched.exe`) that accepts the
   server's self-signed certificate:
   ```
   C:\LegionCore\server\connection_patcher.exe "C:\World of Warcraft 7.3.5\Wow.exe"
   ```
   Always launch the **patched** executable.

## Opening the server to friends (LAN / internet)

1. In `kit-config.ps1` set `$RealmAddress` to your LAN/public IP and re-run `3-Setup-Databases.ps1`.
2. Set `LoginREST.ExternalAddress` in `C:\LegionCore\server\bnetserver.conf` to the same IP.
3. Allow `bnetserver.exe` and `worldserver.exe` through Windows Firewall (ports **8081** and **8085**).

## Kit contents

```
LegionCore-Server-Kit/
├─ kit-config.ps1                  <- edit me
├─ 1-Install-Prerequisites.ps1
├─ 2-Build-Core.ps1
├─ 3-Setup-Databases.ps1
├─ 4-Start-Server.bat / 4-Stop-Server.bat
├─ 5-Extract-Client-Data.ps1
├─ 6-Create-Account.ps1
├─ 7-Install-PlayerBots.ps1       installs the PlayerBots module (needs a rebuild afterwards)
├─ Repair-Update-Hashes.ps1       fixes the "it changed" update loop at server start
├─ module/PlayerBots/             the module's C++ sources + its worldserver.conf block
├─ sql/custom/world/              custom world-database SQL applied by the installers
├─ conf/                           pre-configured worldserver.conf + bnetserver.conf
├─ sql/                            base + old + updates trees (needed by the core's updater)
├─ tools/verify-databases.sh       independent database checker (see docs/)
├─ tools/MySql-Client.ps1          secure MySQL queries/imports, compatible with PowerShell 5.1
├─ tools/Native-Tools.ps1          native build runner; full logs, separate stderr, real exit codes
├─ tools/Casc-BuildInfo.ps1        rebuilds a missing .build.info from the client's own Data\config
├─ tools/Sql-Updates.ps1           core-compatible SHA1 for .sql updates (text-mode, CRLF aware)
├─ tools/Show-MySql-Port.ps1       read-only Windows listener/service diagnostic
└─ docs/TEST-REPORT.md , docs/TROUBLESHOOTING.md , docs/PLAYERBOTS-TEST-RESULTS.txt
```

## Verification status (short version)

The **database half of this kit was executed and verified** against a real MySQL/MariaDB
server from a clean slate: 4 databases, 268 MB of base data, 48 update files,
81 tracking rows with correct SHA1 hashes, admin account hash validated against the
project's own C++ code, and a safe re-run. Details: [`docs/TEST-REPORT.md`](docs/TEST-REPORT.md).

The **Windows build steps** use the project's
`.github/workflows/build-win-x64.yml` dependency layout/core flags, with a supported
VS2022 fallback, native-output repair and static-linkage repair. The native runner
passed 13 regression groups and the static-cache/install guards passed 9 additional
groups. **All five actual LegionCore tool targets** also compiled on Linux with
static core libraries; their dependent libraries resolved. **That is not a Windows/
MSVC build or a live game-server test.** The user reports step 1 working and a partial
Windows build (servers linked; tools failed in dynamic mode). The repaired static
Windows build and runtime still need to complete on that PC. See
[`docs/TEST-REPORT.md`](docs/TEST-REPORT.md#18-static-scriptcore-linker-and-target-install-repair--2026-10-13).

## Legal note

LegionCore is a community preservation project (GPL). You still need your own legal
WoW 7.3.5 client; no game data is included in this kit.
