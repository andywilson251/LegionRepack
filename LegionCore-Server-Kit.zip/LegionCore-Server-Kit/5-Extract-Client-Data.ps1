<#
================================================================================
 LegionCore 7.3.5 - Server Kit : STEP 5  -  extract client data files
================================================================================
 Runs the four extractor tools (built by 2-Build-Core.ps1) against your WoW
 7.3.5 build 26972 client.  The result - dbc, maps, vmaps, mmaps, cameras, gt -
 is what worldserver.exe loads at startup (DataDir).

 Required before running:  $ClientDir must contain a Data\ folder with the
 client's CASC storage (Data\config and Data\data).

 A missing ".build.info" is handled automatically: the build/CDN configuration
 files inside Data\config are located and MD5-verified, and the small metadata
 file the extractors need is generated from them. Nothing is downloaded and no
 game data is modified. Use -NoClientWrite to keep the client folder untouched.

 Run:   powershell -ExecutionPolicy Bypass -File .\5-Extract-Client-Data.ps1
        -SkipMmaps            skip the (very slow) mmaps step for a quick test run
        -Threads 8            tile threads for the mmaps generator (default: CPU count)
        -ClientLocale deDE    force the client locale instead of detecting it
        -NoClientWrite        never write into the client folder (uses a link folder)
        -RebuildBuildInfo     regenerate .build.info even if the client has one
        -SkipProbe            skip the short storage self-test before extracting

 Expected total time:  mapextractor ~15 min, vmap extract+assemble ~30 min,
 mmaps_generator 1-4 hours (it is the long pole; it can safely be re-run).
================================================================================
#>
#Requires -Version 5.1
[CmdletBinding()]
param(
    [switch]$SkipMmaps,
    [int]$Threads = 0,
    [string]$ClientLocale = '',
    [switch]$NoClientWrite,
    [switch]$RebuildBuildInfo,
    [switch]$SkipProbe
)
$ErrorActionPreference = 'Stop'
# Remember the command line value first: kit-config.ps1 is dot-sourced into this
# scope and may define a locale variable of its own.
$RequestedLocale = $ClientLocale
. (Join-Path $PSScriptRoot 'kit-config.ps1')
. (Join-Path $PSScriptRoot 'tools\Native-Tools.ps1')
. (Join-Path $PSScriptRoot 'tools\Casc-BuildInfo.ps1')
$ExtractLogDir = Join-Path $InstallRoot 'logs'
New-Item -ItemType Directory -Force -Path $ExtractLogDir | Out-Null
if ($RequestedLocale) {
    $ClientLocale = $RequestedLocale                     # -ClientLocale always wins
} else {
    foreach ($name in 'ClientLocaleOverride', 'ClientLocale') {   # then kit-config.ps1
        $configured = Get-Variable -Name $name -ValueOnly -ErrorAction SilentlyContinue
        if ($configured) { $ClientLocale = $configured; break }
    }
}

function Step($m) { Write-Host "`n=== $m" -ForegroundColor Cyan }
function Ok($m)   { Write-Host "  [ok] $m" -ForegroundColor Green }
function Info($m) { Write-Host "  $m" -ForegroundColor Gray }
function Warn($m) { Write-Host "  [!!] $m" -ForegroundColor Yellow }
function Die($m)  { Write-Host "`n  [XX] $m" -ForegroundColor Red; exit 1 }

function Get-FileCount($path, $filter) {
    if (-not (Test-Path -LiteralPath $path)) { return 0 }
    return @(Get-ChildItem -LiteralPath $path -Recurse -File -Filter $filter -ErrorAction SilentlyContinue).Count
}

function Invoke-Extractor {
    <#
    Runs one extractor. The tools keep exit code 0 even when they cannot open
    the storage ("No locales detected"), so their output is checked as well.
    #>
    param(
        [Parameter(Mandatory = $true)][string]$Name,
        [Parameter(Mandatory = $true)][string[]]$Arguments,
        [Parameter(Mandatory = $true)][string]$WorkingDirectory,
        [string]$LogName = '',
        [int]$TimeoutSeconds = 0
    )
    $exe = Join-Path $ServerDir $Name
    if (-not (Test-Path -LiteralPath $exe)) { Die "$Name not found in $ServerDir - run 2-Build-Core.ps1 first." }
    if (-not $LogName) { $LogName = "extract-$([IO.Path]::GetFileNameWithoutExtension($Name)).log" }
    $logPath = Join-Path $ExtractLogDir $LogName
    $result = Invoke-LegionNativeTool -Executable $exe -Arguments $Arguments -WorkingDirectory $WorkingDirectory `
                                      -LogPath $logPath -OutputMode All -TimeoutSeconds $TimeoutSeconds
    $output = ''
    if (Test-Path -LiteralPath $result.LogPath) { $output = Get-Content -LiteralPath $result.LogPath -Raw }
    $failures = @()
    if ($result.TimedOut) { $failures += "it did not finish within $TimeoutSeconds seconds" }
    if ($result.ExitCode -ne 0) { $failures += "exit code $($result.ExitCode)" }
    foreach ($pattern in 'No locales detected', 'No locales defined', 'error opening casc storage', 'Error opening casc storage') {
        if ($output -like "*$pattern*") { $failures += "the tool reported '$pattern'" }
    }
    return [pscustomobject]@{
        Name = $Name; ExitCode = $result.ExitCode; LogPath = $result.LogPath
        Output = $output; Failures = $failures; Success = ($failures.Count -eq 0)
    }
}

# ==============================================================================
Step "1/6  Checking the client and the tools"
if (-not (Test-Path -LiteralPath $ClientDir)) { Die "Client folder not found: $ClientDir`n       Edit `$ClientDir in kit-config.ps1." }
try { $layout = Get-LegionClientCascLayout -ClientDir $ClientDir } catch { Die $_.Exception.Message }
Info "client: $($layout.Root)"
if (-not (Test-Path -LiteralPath (Join-Path $layout.Root 'Wow.exe'))) {
    Warn "Wow.exe is not in the client folder. Extraction does not need it, but 7-Patch-Client/connection_patcher does."
}
foreach ($t in 'mapextractor.exe', 'vmap4extractor.exe', 'vmap4assembler.exe') {
    if (-not (Test-Path -LiteralPath (Join-Path $ServerDir $t))) { Die "$t not found in $ServerDir - run 2-Build-Core.ps1 first." }
}
if (-not $SkipMmaps -and -not (Test-Path -LiteralPath (Join-Path $ServerDir 'mmaps_generator.exe'))) {
    Die "mmaps_generator.exe not found in $ServerDir - run 2-Build-Core.ps1 first, or use -SkipMmaps."
}
Ok "tools present"
New-Item -ItemType Directory -Force -Path $ClientDataDir | Out-Null
Info "output: $ClientDataDir  (this is also DataDir in worldserver.conf)"

# ==============================================================================
Step "2/6  Checking the CASC storage metadata (.build.info)"
$plan = Get-LegionCascRepairPlan -ClientDir $layout.Root -PreferredBuild 26972 -RequestedLocale $ClientLocale
$storageRoot = $layout.Root
$generated = $null
$existingBuildFile = $plan.Layout.ExistingBuildFile

if (-not $plan.IndexDirPresent) { Die "This client has no $($plan.Layout.IndexDir) folder - the CASC data/index files are missing." }
if ($plan.IndexFileCount -eq 0) {
    Die ("$($plan.Layout.IndexDir) contains no .idx index files, so the client's data cannot be read.`n" +
         "       (The extractor does not fail gracefully on this - it crashes - so the kit stops here.)`n" +
         "       The client download looks incomplete: let the game launcher finish downloading/repairing it.")
}
Info "index files in $($plan.Layout.IndexDir): $($plan.IndexFileCount)"

if ($existingBuildFile -and -not $RebuildBuildInfo) {
    Ok "client already has $($existingBuildFile.Path) ($($existingBuildFile.Length) bytes) - leaving it alone"
    if ($plan.BuildCandidates.Count -gt 0) { Info "build configurations found in Data\config: $($plan.BuildCandidates.Count)" }
} else {
    if ($existingBuildFile -and $RebuildBuildInfo) {
        $backup = "$($existingBuildFile.Path).bak-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
        Copy-Item -LiteralPath $existingBuildFile.Path -Destination $backup -Force
        Warn "existing $($existingBuildFile.Path) backed up to $backup (-RebuildBuildInfo)"
    } else {
        Info "no .build.info / .build.db in the client - rebuilding it from the client's own files"
    }
    if (-not (Test-Path -LiteralPath $plan.Layout.ConfigDir)) {
        Die ("This client has no $($plan.Layout.ConfigDir) folder, so the CASC build configuration cannot be recovered.`n" +
             "       A Legion client folder must contain Data\config and Data\data. If your Data folder holds .MPQ files`n" +
             "       instead, it is not a 7.3.5 CASC client and these tools cannot read it.")
    }
    if ($plan.BuildCandidates.Count -eq 0) {
        $detail = ''
        if ($plan.Rejected.Count -gt 0) { $detail = "`n       Ignored files: " + (($plan.Rejected | Select-Object -First 5 | ForEach-Object { "$($_.Key) - $($_.Reason)" }) -join "`n                      ") }
        Die ("No usable build configuration was found in $($plan.Layout.ConfigDir).$detail`n" +
             "       Without it the client's data cannot be opened. Re-download/repair the client, or copy .build.info from the original install.")
    }
    Ok "locale: $($plan.Locale)  (from $($plan.LocaleSource))"
    if (-not $plan.LocaleSupported) {
        Warn "the extractors only support $($script:LegionToolLocales -join ', ') - if extraction finds no files, rerun with -ClientLocale <locale>."
    }
    if ($plan.CdnConfig) { Info "CDN configuration: $($plan.CdnKey)" } else { Info "no CDN configuration found - it is optional and will be skipped" }
    Info "build configuration candidates: $($plan.BuildCandidates.Count)"
    foreach ($candidate in ($plan.BuildCandidates | Select-Object -First 5)) {
        $label = if ($candidate.BuildName) { $candidate.BuildName } else { '(no build-name)' }
        Info ("  {0}  build {1}  {2}" -f $candidate.Key, $candidate.BuildNumber, $label)
    }
    $shadowRoot = Join-Path $InstallRoot 'client-root'
    $generated = Write-LegionCascBuildInfo -Plan $plan -Candidate $plan.BuildCandidates[0] -ShadowRootDir $shadowRoot -NoClientWrite:$NoClientWrite
    $storageRoot = $generated.StorageRoot
    if ($generated.Mode -eq 'shadow') {
        Ok "generated $($generated.BuildInfo) with a Data link to $($plan.Layout.DataDir) (client folder untouched)"
    } else {
        Ok "generated $($generated.BuildInfo) (delete this file to undo; your game data was not touched)"
    }
    Info "build key $($generated.BuildKey), client build $($generated.BuildNumber), locale $($generated.Locale)"
}

# ==============================================================================
Step "3/6  Storage self-test"
if ($SkipProbe) {
    Info "skipped (-SkipProbe)"
} else {
    $probeDir = Join-Path $ExtractLogDir 'casc-probe'
    $attempt = 0
    $probeOk = $false
    $candidates = if ($generated) { @($plan.BuildCandidates) } else { @($null) }
    foreach ($candidate in $candidates) {
        $attempt++
        if ($generated -and $attempt -gt 1) {
            Warn "trying the next build configuration: $($candidate.Key) (build $($candidate.BuildNumber))"
            $generated = Write-LegionCascBuildInfo -Plan $plan -Candidate $candidate -ShadowRootDir (Join-Path $InstallRoot 'client-root') -NoClientWrite:$NoClientWrite
            $storageRoot = $generated.StorageRoot
        }
        Remove-Item -LiteralPath $probeDir -Recurse -Force -ErrorAction SilentlyContinue
        New-Item -ItemType Directory -Force -Path $probeDir | Out-Null
        Info "reading the smallest data set (game tables) to confirm the client opens ..."
        $probe = Invoke-Extractor -Name 'mapextractor.exe' -Arguments @('-i', $storageRoot, '-o', $probeDir, '-e', '8') `
                                  -WorkingDirectory $probeDir -LogName 'extract-probe.log' -TimeoutSeconds 900
        if ($probe.Success -and $probe.Output -match 'Detected client build:?\s*(\d+)') {
            Ok "client opened - detected build $($Matches[1])"
            $probeOk = $true
            Remove-Item -LiteralPath $probeDir -Recurse -Force -ErrorAction SilentlyContinue
            break
        }
        Warn "self-test failed: $($probe.Failures -join '; ') (see $($probe.LogPath))"
    }
    if (-not $probeOk) {
        Die ("The client's CASC storage could not be opened. See $(Join-Path $ExtractLogDir 'extract-probe.log').`n" +
             "       FILE_NOT_FOUND here usually means Data\data (the .idx/data files) is incomplete.`n" +
             "       If the client is not English, rerun with -ClientLocale <locale>, e.g. -ClientLocale deDE.")
    }
}

# ==============================================================================
Step "4/6  mapextractor  (maps, dbc, cameras, gt)"
$result = Invoke-Extractor -Name 'mapextractor.exe' -Arguments @('-i', $storageRoot, '-o', '.') -WorkingDirectory $ClientDataDir
if (-not $result.Success) { Die "mapextractor failed: $($result.Failures -join '; '). See $($result.LogPath)." }
$mapCount = Get-FileCount (Join-Path $ClientDataDir 'maps') '*.map'
$dbcCount = Get-FileCount (Join-Path $ClientDataDir 'dbc') '*.db2'
if ($mapCount -eq 0) { Die "mapextractor produced no .map files. See $($result.LogPath)." }
if ($dbcCount -eq 0) {
    Die ("mapextractor produced no .db2 files in $ClientDataDir\dbc. This usually means the locale is wrong.`n" +
         "       Rerun with -ClientLocale <locale> (for example -ClientLocale deDE). See $($result.LogPath).")
}
Ok "done - $mapCount map files, $dbcCount dbc/db2 files"

# ==============================================================================
Step "5/6  vmap4extractor + vmap4assembler  (vmaps)"
$result = Invoke-Extractor -Name 'vmap4extractor.exe' -Arguments @('-d', $storageRoot) -WorkingDirectory $ClientDataDir
if (-not $result.Success) { Die "vmap4extractor failed: $($result.Failures -join '; '). See $($result.LogPath)." }
$buildingsDir = Join-Path $ClientDataDir 'Buildings'
if ((Get-FileCount $buildingsDir '*') -eq 0) { Die "vmap4extractor produced no raw geometry in $buildingsDir. See $($result.LogPath)." }
Ok "raw geometry extracted"
$result = Invoke-Extractor -Name 'vmap4assembler.exe' -Arguments @('Buildings', 'vmaps') -WorkingDirectory $ClientDataDir
if (-not $result.Success) { Die "vmap4assembler failed: $($result.Failures -join '; '). See $($result.LogPath)." }
$vmapCount = Get-FileCount (Join-Path $ClientDataDir 'vmaps') '*'
if ($vmapCount -eq 0) { Die "vmap4assembler produced no vmaps. See $($result.LogPath)." }
Ok "done - $vmapCount vmap files"
Remove-Item -LiteralPath $buildingsDir -Recurse -Force -ErrorAction SilentlyContinue
Info "temporary Buildings folder removed"

# ==============================================================================
if ($SkipMmaps) {
    Step "6/6  mmaps_generator skipped (-SkipMmaps)"
    Info "without mmaps, creatures cannot path-find correctly - run this script again without -SkipMmaps when you have a few hours."
} else {
    Step "6/6  mmaps_generator  (movement maps - the long step)"
    $mt = if ($Threads -gt 0) { $Threads } else { [Environment]::ProcessorCount }
    Info "using $mt threads"
    $result = Invoke-Extractor -Name 'mmaps_generator.exe' -Arguments @('--threads', "$mt") -WorkingDirectory $ClientDataDir
    if (-not $result.Success) { Die "mmaps_generator failed: $($result.Failures -join '; '). See $($result.LogPath)." }
    $mmapCount = Get-FileCount (Join-Path $ClientDataDir 'mmaps') '*'
    if ($mmapCount -eq 0) { Die "mmaps_generator produced no mmaps. See $($result.LogPath)." }
    Ok "done - $mmapCount mmap files"
}

# ==============================================================================
Step "Result"
$missing = @()
foreach ($d in 'dbc', 'maps', 'vmaps', 'mmaps', 'cameras', 'gt') {
    $p = Join-Path $ClientDataDir $d
    if (Test-Path -LiteralPath $p) {
        $size = (Get-ChildItem -LiteralPath $p -Recurse -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
        Ok ("{0,-8} {1,8:N0} MB" -f $d, ($size / 1MB))
    } else {
        if ($d -eq 'mmaps' -and $SkipMmaps) { Warn "mmaps    skipped (-SkipMmaps)" }
        else { Warn "$d  missing"; $missing += $d }
    }
}
if ($missing.Count -gt 0) { Die "These data folders were not produced: $($missing -join ', '). Check the logs in $ExtractLogDir." }
Write-Host "`n  Set DataDir in worldserver.conf to: $ClientDataDir" -ForegroundColor Green
Write-Host "  (the kit's conf already points there)" -ForegroundColor Green
