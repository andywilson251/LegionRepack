<#
================================================================================
 LegionCore 7.3.5 - Server Kit : STEP 2  -  build worldserver.exe + bnetserver.exe
================================================================================
 Clones the core (if needed), uses the project's Windows CI dependency layout
 and core flags (Ninja/MSVC or VS2022 x64, -DTOOLS=ON), and copies built binaries,
 the extractor tools and every required DLL into  C:\LegionCore\server.

 Run:   powershell -ExecutionPolicy Bypass -File .\2-Build-Core.ps1
        (add -Jobs 4 to limit CPU usage, default = all cores)

 A full build takes roughly 30-90 minutes on a normal desktop and needs ~6 GB of
 free disk space. Build output is streamed and saved under C:\LegionCore\logs.
 Repair: 2026-10-11 - native stderr warnings do not abort PowerShell; CMake
 path arguments remain single tokens; Visual Studio builds use RelWithDebInfo.
 Repair: 2026-10-13 - use the repository default static scripts/core to avoid
 incomplete Windows DLL exports in extraction tools; install current targets.
================================================================================
#>
#Requires -Version 5.1
[CmdletBinding()]
param(
    [int]$Jobs = 0,                  # 0 = use all cores
    [switch]$Clean                   # delete the build folder first
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'kit-config.ps1')
. (Join-Path $PSScriptRoot 'tools\Native-Tools.ps1')
$BuildLogDir = Join-Path $InstallRoot 'logs'
New-Item -ItemType Directory -Force -Path $BuildLogDir | Out-Null

function Step($m) { Write-Host "`n=== $m" -ForegroundColor Cyan }
function Ok($m)   { Write-Host "  [ok] $m" -ForegroundColor Green }
function Info($m) { Write-Host "  $m" -ForegroundColor Gray }
function Warn($m) { Write-Host "  [!!] $m" -ForegroundColor Yellow }
function Die($m)  { Write-Host "`n  [XX] $m" -ForegroundColor Red; exit 1 }

# ==============================================================================
Step "1/6  Getting the source code"
if (Test-Path (Join-Path $SourceDir 'CMakeLists.txt')) {
    Ok "source already present: $SourceDir"
    Push-Location $SourceDir
    try {
        if (Get-Command git -ErrorAction SilentlyContinue) {
            Info "pulling latest changes (ignored if you have local edits) ..."
            $gitResult = Invoke-LegionNativeTool -Executable (Get-Command git).Source -Arguments @('pull','--ff-only') -WorkingDirectory $SourceDir -LogPath (Join-Path $BuildLogDir 'git-source.log')
            if ($gitResult.ExitCode -ne 0) { Warn "git pull did not update the existing source; continuing with that checkout. See $($gitResult.LogPath)." }
        }
    } finally { Pop-Location }
} else {
    if (-not (Get-Command git -ErrorAction SilentlyContinue)) { Die "git not found - run 1-Install-Prerequisites.ps1 first." }
    New-Item -ItemType Directory -Force -Path (Split-Path $SourceDir -Parent) | Out-Null
    Info "cloning $RepoUrl ..."
    $gitResult = Invoke-LegionNativeTool -Executable (Get-Command git).Source -Arguments @('clone','--depth','1',$RepoUrl,$SourceDir) -LogPath (Join-Path $BuildLogDir 'git-source.log')
    if ($gitResult.ExitCode -ne 0) { Die "git clone failed (exit $($gitResult.ExitCode)). See $($gitResult.LogPath)." }
    Ok "cloned to $SourceDir"
}
$revision = (Get-Content (Join-Path $SourceDir 'revision_data.h.in.cmake') | Select-String '_FULL_DATABASE').ToString().Trim()
Ok "source revision data: $revision"

# ==============================================================================
Step "2/6  Checking dependencies (Boost / OpenSSL / MySQL / MSVC)"
if (-not $env:BOOST_ROOT -or -not (Test-Path $env:BOOST_ROOT)) { $env:BOOST_ROOT = (Join-Path $BoostRoot 'boost') }
if (-not (Test-Path (Join-Path $env:BOOST_ROOT 'boost\version.hpp'))) { Die "Boost not found at $env:BOOST_ROOT - run 1-Install-Prerequisites.ps1." }
Ok "BOOST_ROOT       = $env:BOOST_ROOT"
if (-not (Test-Path (Join-Path $OpenSslRoot 'include\openssl\ssl.h'))) { Die "OpenSSL not found at $OpenSslRoot - run 1-Install-Prerequisites.ps1." }
Ok "OPENSSL_ROOT_DIR = $OpenSslRoot"
if (-not (Test-Path (Join-Path $MySqlRoot 'include\mysql.h'))) { Die "MySQL headers not found at $MySqlRoot - run 1-Install-Prerequisites.ps1." }
Ok "MYSQL_ROOT_DIR   = $MySqlRoot"
$env:OPENSSL_ROOT_DIR = $OpenSslRoot
$env:MYSQL_ROOT_DIR   = $MySqlRoot

# --- load the MSVC environment (cl.exe, link.exe, INCLUDE/LIB paths) ----------
$vsDevCmd = $null
$vswhere  = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
if (Test-Path $vswhere) {
    $vsPath = & $vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
    if ($vsPath) {
        $cand = Join-Path $vsPath 'Common7\Tools\VsDevCmd.bat'
        if (Test-Path $cand) { $vsDevCmd = $cand }
    }
}
if ($vsDevCmd) {
    Info "loading MSVC environment from VsDevCmd.bat ..."
    $envDump = & cmd /s /c "`"$vsDevCmd`" -arch=amd64 -host_arch=amd64 >nul 2>&1 && set"
    if ($LASTEXITCODE -ne 0) { Die "VsDevCmd.bat failed to load the compiler environment." }
    foreach ($line in $envDump) {
        if ($line -match '^([^=]+)=(.*)$') {
            $k = $Matches[1]; $v = $Matches[2]
            if ($k -in 'PATH','INCLUDE','LIB','LIBPATH','VCToolsInstallDir','WindowsSdkDir') { Set-Item -Path "env:$k" -Value $v }
        }
    }
    if (Get-Command cl.exe -ErrorAction SilentlyContinue) { Ok "cl.exe available" } else { Warn "cl.exe still not found - the VS Build Tools C++ workload may be missing." }
} else { Warn "VsDevCmd.bat not found - hoping cmake can locate MSVC by itself." }

$cmakeCommand = Get-Command cmake -ErrorAction SilentlyContinue
if (-not $cmakeCommand) { Die "cmake not found - run 1-Install-Prerequisites.ps1." }
$CMakeExe = $cmakeCommand.Source
if (-not (Get-Command ninja -ErrorAction SilentlyContinue)) { Warn "ninja not found - the Visual Studio 17 2022 generator is a supported fallback." }

# ==============================================================================
Step "3/6  Configuring with CMake"
if ($Clean -and (Test-Path $BuildDir)) { Remove-Item $BuildDir -Recurse -Force; Ok "build folder cleared" }
New-Item -ItemType Directory -Force -Path $BuildDir | Out-Null

$generatorArgs = @()
if (Get-Command ninja -ErrorAction SilentlyContinue) { $generatorArgs = @('-GNinja') } else { $generatorArgs = @('-G', 'Visual Studio 17 2022', '-A', 'x64') }
# Reuse the generator selected by any prior configure attempt. Do not delete a
# partial build or silently switch generators just because PATH has changed.
$cacheFile = Join-Path $BuildDir 'CMakeCache.txt'
if (Test-Path $cacheFile) {
    $cacheGenerator = Get-Content $cacheFile | Select-String '^CMAKE_GENERATOR:INTERNAL=(.*)$' | Select-Object -First 1
    if ($cacheGenerator) {
        $cached = $cacheGenerator.Matches[0].Groups[1].Value
        if ($cached -eq 'Visual Studio 17 2022') { $generatorArgs = @('-G','Visual Studio 17 2022','-A','x64') }
        elseif ($cached -eq 'Ninja') {
            if (-not (Get-Command ninja -ErrorAction SilentlyContinue)) { Die "This build cache requires Ninja, which is not on PATH. Install Ninja or intentionally rerun with -Clean to choose a different generator." }
            $generatorArgs = @('-GNinja')
        } else { Die "The existing build cache uses generator '$cached'. Use -Clean only if you intentionally want to replace that build tree." }
    }
}
Info ("generator: " + ($generatorArgs -join ' '))

Info "linkage: static scripts/static core; all default script modules and TOOLS remain enabled"
# An explicit per-module dynamic override would force shared core libraries even
# with WITH_DYNAMIC_LINKING=OFF. Do not silently overwrite a custom cache choice.
if (Test-Path $cacheFile) {
    $dynamicOverrides = @(Get-Content $cacheFile | Select-String '^SCRIPTS_[^:]+:(STRING|UNINITIALIZED)=dynamic$')
    if ($dynamicOverrides.Count -gt 0) {
        Die "This build cache has an explicit dynamic script-module override: $($dynamicOverrides.Line -join ', '). Change only those SCRIPTS_<module> cache values to default or static, then rerun. No automatic cache/source deletion was performed."
    }
}

$cmakeArgs = $generatorArgs + @(
    '-S', $SourceDir,
    '-B', $BuildDir,
    '-DTOOLS=ON',
    '-DSCRIPTS=static',
    '-DWITH_DYNAMIC_LINKING=OFF',
    '-DSERVERS=ON',
    '-DCMAKE_BUILD_TYPE=RelWithDebInfo',
    ('-DCMAKE_INSTALL_PREFIX=' + $ServerDir),
    ('-DBOOST_ROOT=' + $env:BOOST_ROOT),
    ('-DOPENSSL_ROOT_DIR=' + $OpenSslRoot),
    ('-DMYSQL_ROOT_DIR=' + $MySqlRoot)
)
$configureLog = Join-Path $BuildLogDir 'cmake-configure.log'
Info "complete configure output: $configureLog"
$configureResult = Invoke-LegionNativeTool -Executable $CMakeExe -Arguments $cmakeArgs -LogPath $configureLog -OutputMode All
if ($configureResult.ExitCode -ne 0) {
    Die "CMake configuration failed (exit $($configureResult.ExitCode)). The complete warning/error text is above and in $configureLog."
}
Ok "configuration done"

# ==============================================================================
Step "4/6  Building (this is the long part - grab a coffee)"
$buildArgs = @('--build', $BuildDir, '--config', 'RelWithDebInfo')
if ($Jobs -gt 0) { $buildArgs += @('--parallel', "$Jobs") } else { $buildArgs += '--parallel' }
if ($generatorArgs[0] -ne '-GNinja') { $buildArgs += @('--', '/nologo') }   # MSBuild only
$sw = [Diagnostics.Stopwatch]::StartNew()
$buildLog = Join-Path $BuildLogDir 'cmake-build.log'
Info "complete build output: $buildLog"
$buildResult = Invoke-LegionNativeTool -Executable $CMakeExe -Arguments $buildArgs -LogPath $buildLog -OutputMode Build
if ($buildResult.ExitCode -ne 0) { Die "Build failed (exit $($buildResult.ExitCode)). See $buildLog for the full compiler/linker output." }
$sw.Stop()
Ok ("build finished in {0:N1} minutes" -f $sw.Elapsed.TotalMinutes)

# ==============================================================================
Step "5/6  Collecting binaries, configs and DLLs into $ServerDir"
# Install only artifacts declared by the CURRENT generated project/configuration.
# This also deploys any current project DLL targets via their own install rules;
# do not glob stale DLLs left behind by an earlier dynamic configure attempt.
New-Item -ItemType Directory -Force -Path $ServerDir | Out-Null
$installArgs = @('--install', $BuildDir, '--config', 'RelWithDebInfo', '--prefix', $ServerDir)
$installLog = Join-Path $BuildLogDir 'cmake-install.log'
Info "complete install output: $installLog"
$installResult = Invoke-LegionNativeTool -Executable $CMakeExe -Arguments $installArgs -LogPath $installLog -OutputMode All
if ($installResult.ExitCode -ne 0) { Die "CMake installation failed (exit $($installResult.ExitCode)). See $installLog." }

# Extraction tools are required, not optional: do not report success without them.
foreach ($required in 'worldserver.exe','bnetserver.exe','mapextractor.exe','vmap4extractor.exe','vmap4assembler.exe','mmaps_generator.exe','connection_patcher.exe') {
    if (-not (Test-Path (Join-Path $ServerDir $required))) { Die "Required installed binary missing: $required. See $installLog; TOOLS must remain ON." }
    Ok $required
}
foreach ($pem in 'bnetserver.cert.pem','bnetserver.key.pem') {
    if (-not (Test-Path (Join-Path $ServerDir $pem))) { Die "Required installed TLS file missing: $pem. See $installLog." }
    Ok $pem
}
# runtime DLLs (exactly like the project's CI does)
$dlls = @(
    @{ src = (Join-Path $MySqlRoot 'lib\libmysql.dll');                          dst = 'libmysql.dll' },
    @{ src = (Join-Path $OpenSslRoot 'bin\libssl-3-x64.dll');                   dst = 'libssl-3-x64.dll' },
    @{ src = (Join-Path $OpenSslRoot 'bin\libcrypto-3-x64.dll');                dst = 'libcrypto-3-x64.dll' },
    @{ src = (Join-Path $OpenSslRoot 'bin\legacy.dll');                         dst = 'legacy.dll' }
)
foreach ($d in $dlls) {
    if (Test-Path $d.src) { Copy-Item $d.src (Join-Path $ServerDir $d.dst) -Force; Ok "dll: $($d.dst)" }
    else {
        # the MySQL zip sometimes keeps libmysql.dll elsewhere in the tree
        if ($d.dst -eq 'libmysql.dll') {
            $alt = Get-ChildItem $MySqlRoot -Recurse -Filter 'libmysql.dll' -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($alt) { Copy-Item $alt.FullName (Join-Path $ServerDir $d.dst) -Force; Ok "dll: libmysql.dll (found in $($alt.DirectoryName))" }
            else { Warn "libmysql.dll not found under $MySqlRoot - worldserver will not start without it." }
        } else { Warn "dll missing: $($d.src)" }
    }
}
# Seed kit configs only when absent. Preserve already-edited runtime configs.
foreach ($name in 'worldserver.conf','bnetserver.conf') {
    $destination = Join-Path $ServerDir $name
    if (Test-Path $destination) { Ok "$name preserved (already present)" }
    else { Copy-Item (Join-Path $PSScriptRoot ("conf\" + $name)) $destination; Ok "$name installed from kit" }
}

# ==============================================================================
Step "6/6  Smoke test"
$smokeFailures = New-Object 'Collections.Generic.List[string]'
foreach ($exe in 'bnetserver.exe','worldserver.exe') {
    $p = Join-Path $ServerDir $exe
    if (Test-Path $p) {
        Push-Location $ServerDir
        try {
            $smokeResult = Invoke-LegionNativeTool -Executable $p -Arguments @('--version') -WorkingDirectory $ServerDir -LogPath (Join-Path $BuildLogDir ($exe + '-version.log')) -OutputMode Quiet -CaptureOutput -TimeoutSeconds 30
            $ver = @($smokeResult.StdOut -split '\r?\n' | Select-Object -First 3)
            if ($smokeResult.ExitCode -eq 0 -and -not $smokeResult.TimedOut) { Ok "$exe --version -> $($ver -join ' / ')" }
            else { Warn "$exe --version failed (exit $($smokeResult.ExitCode), timeout $($smokeResult.TimedOut)). See $($smokeResult.LogPath); check the runtime DLLs next to the exe."; $smokeFailures.Add($exe) }
        } catch { Warn "$exe could not be started: $_"; $smokeFailures.Add($exe) }
        finally { Pop-Location }
    }
}
if ($smokeFailures.Count -gt 0) { Die "Executable version probes failed: $($smokeFailures -join ', '). See the version logs in $BuildLogDir. Build/install alone do not verify startup; do not proceed to databases yet." }
Write-Host "`n  Next step: 3-Setup-Databases.ps1" -ForegroundColor Green
