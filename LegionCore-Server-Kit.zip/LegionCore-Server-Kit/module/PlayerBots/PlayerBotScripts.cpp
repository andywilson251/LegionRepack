/*
 * LegionCore PlayerBots - script registrations
 *
 *  - WorldScript  : loads the config/data at startup and drives the manager tick
 *  - PlayerScript : keeps the level band in step with who is actually online
 *  - CommandScript: .bots status | spawn | despawn | reload | level
 */

#include "PlayerBots.h"

#include "Chat.h"
#include "DatabaseEnv.h"
#include "Config.h"
#include "Log.h"
#include "ObjectMgr.h"
#include "Player.h"
#include "ScriptMgr.h"
#include "SpellInfo.h"
#include "SpellMgr.h"
#include "World.h"

#include <vector>
#include <utility>

class playerbots_world : public WorldScript
{
public:
    playerbots_world() : WorldScript("playerbots_world") { }

    void OnConfigLoad(bool reload) override
    {
        sPlayerBotMgr->LoadConfig(reload);
    }

    void OnStartup() override
    {
        sPlayerBotMgr->OnWorldStartup();
    }

    void OnUpdate(uint32 diff) override
    {
        sPlayerBotMgr->Update(diff);
        sPlayerBotRealMgr->Update(diff);
    }
};

class playerbots_player : public PlayerScript
{
public:
    playerbots_player() : PlayerScript("playerbots_player") { }

    void OnLogin(Player* /*player*/) override
    {
        sPlayerBotMgr->OnPlayerLevelChanged();
    }

    void OnLogout(Player* /*player*/) override
    {
        sPlayerBotMgr->OnPlayerLevelChanged();
    }

    void OnLevelChanged(Player* /*player*/, uint8 /*oldLevel*/) override
    {
        sPlayerBotMgr->OnPlayerLevelChanged();
    }
};

class playerbots_commandscript : public CommandScript
{
public:
    playerbots_commandscript() : CommandScript("playerbots_commandscript") { }

    std::vector<ChatCommand> GetCommands() const override
    {
        static std::vector<ChatCommand> botsCommandTable =
        {
            { "status",  SEC_GAMEMASTER, true,  &HandleBotsStatusCommand,  "Shows the bot roster, how many are active and the level band." },
            { "spawn",   SEC_GAMEMASTER, false, &HandleBotsSpawnCommand,   "Spawns N bots around you right now. Usage: .bots spawn 10" },
            { "despawn", SEC_GAMEMASTER, true,  &HandleBotsDespawnCommand, "Despawns every materialised bot." },
            { "reload",  SEC_GAMEMASTER, true,  &HandleBotsReloadCommand,  "Reloads playerbot_profile / playerbot_area / playerbot_rotation from the world database." },
            { "level",   SEC_GAMEMASTER, true,  &HandleBotsLevelCommand,   "Shows how the roster levels are distributed." },
            { "addarea", SEC_GAMEMASTER, false, &HandleBotsAddAreaCommand, "Records where you are standing as a bot spawn area. Usage: .bots addarea <minLevel> <maxLevel> [radius]" },
            { "spells",  SEC_GAMEMASTER, true,  &HandleBotsSpellsCommand,  "Lists every rotation spell with the name this server resolves it to, and any that were dropped." },
            { "player",  SEC_ADMINISTRATOR, false, &HandleBotsPlayerCommand, "Logs in N REAL player-bots (needs the core patch). Usage: .bots player 1" },
            { "logout",  SEC_ADMINISTRATOR, true,  &HandleBotsLogoutCommand, "Logs out every real player-bot." }
        };

        static std::vector<ChatCommand> commandTable =
        {
            { "bots", SEC_GAMEMASTER, true, nullptr, "", botsCommandTable }
        };

        return commandTable;
    }

    // Answers "are these spell ids real on my build?" from the server's own
    // Spell data, which is the only authority on it.
    static bool HandleBotsSpellsCommand(ChatHandler* handler, char const* /*args*/)
    {
        static char const* const roleNames[BOT_ROLE_MAX] = { "tank", "healer", "melee", "ranged" };
        uint32 shown = 0;

        for (uint8 role = 0; role < BOT_ROLE_MAX; ++role)
        {
            std::vector<PlayerBotRotationStep> const& steps = sPlayerBotMgr->GetRotation(role);
            if (steps.empty())
                continue;

            handler->PSendSysMessage("--- %s (%u step%s) ---", roleNames[role],
                uint32(steps.size()), steps.size() == 1 ? "" : "s");

            for (PlayerBotRotationStep const& step : steps)
            {
                SpellInfo const* info = sSpellMgr->GetSpellInfo(step.SpellId);
                handler->PSendSysMessage("  %u  %s", step.SpellId,
                    (info && info->SpellName) ? info->SpellName : "<no name in Spell data>");
                ++shown;
            }
        }

        std::vector<PlayerBotMgr::DroppedSpell> const& dropped = sPlayerBotMgr->GetDroppedSpells();
        if (dropped.empty())
        {
            handler->PSendSysMessage("All %u rotation spells exist in this build's Spell data.", shown);
        }
        else
        {
            handler->PSendSysMessage("%u rotation step(s) were DROPPED - the spell id is not in this build:",
                uint32(dropped.size()));
            for (PlayerBotMgr::DroppedSpell const& d : dropped)
                handler->PSendSysMessage("  %u  (%s, intended for %s)", d.SpellId,
                    d.Comment.empty() ? "no comment" : d.Comment.c_str(),
                    d.Role < BOT_ROLE_MAX ? roleNames[d.Role] : "?");
            handler->PSendSysMessage("Fix them in playerbot_rotation, then run .bots reload");
        }

        return true;
    }

    // Stage 2: real Player bots. Deliberately admin-only and opt-in - this
    // creates accounts and characters, and needs the core patch.
    static bool HandleBotsPlayerCommand(ChatHandler* handler, char const* args)
    {
        Player* owner = handler->GetSession() ? handler->GetSession()->GetPlayer() : nullptr;
        if (!owner)
        {
            handler->SendSysMessage("This command has to be run in game.");
            return true;
        }

        if (!sPlayerBotRealMgr->IsEnabled())
        {
            handler->SendSysMessage("Real player-bots are off. Set PlayerBots.RealPlayers.Enable = 1 in");
            handler->SendSysMessage("worldserver.conf and restart, and make sure the core patch is applied");
            handler->SendSysMessage("(7-Install-PlayerBots.ps1, then rebuild).");
            return true;
        }

        uint32 count = 1;
        if (args && *args)
        {
            int32 parsed = atoi(args);
            if (parsed > 0)
                count = uint32(parsed);
        }
        if (count > 20)
            count = 20;         // logging in is not free; keep a single command modest

        uint32 spawned = sPlayerBotRealMgr->SpawnPlayerBots(owner, count);
        handler->PSendSysMessage("Started login for %u real player-bot(s). %u of max %u are in.",
            spawned, sPlayerBotRealMgr->CountLoggedIn(), sPlayerBotRealMgr->GetMax());
        if (spawned < count)
            handler->SendSysMessage("Some did not start - check the worldserver log for PlayerBots lines.");
        return true;
    }

    static bool HandleBotsLogoutCommand(ChatHandler* handler, char const* /*args*/)
    {
        uint32 n = sPlayerBotRealMgr->LogoutAll();
        handler->PSendSysMessage("Logged out %u real player-bot(s).", n);
        return true;
    }

    static bool HandleBotsStatusCommand(ChatHandler* handler, char const* /*args*/)
    {
        PlayerBotConfig const& config = sPlayerBotMgr->GetConfig();

        handler->PSendSysMessage("PlayerBots: %s", config.Enable ? "enabled" : "disabled (PlayerBots.Enable = 0)");
        handler->PSendSysMessage("  profiles %u | spawn areas %u | rotation steps %u",
            sPlayerBotMgr->GetProfileCount(), sPlayerBotMgr->GetAreaCount(), sPlayerBotMgr->GetRotationStepCount());

        // Silently losing abilities is the worst failure mode here, so surface
        // it on the command people actually run.
        handler->PSendSysMessage("  real player-bots: %s, %u logged in (max %u)",
            sPlayerBotRealMgr->IsEnabled() ? "enabled" : "disabled",
            sPlayerBotRealMgr->CountLoggedIn(), sPlayerBotRealMgr->GetMax());

        if (size_t droppedCount = sPlayerBotMgr->GetDroppedSpells().size())
            handler->PSendSysMessage("  WARNING: %u rotation step(s) dropped - unknown spell ids. Run .bots spells",
                uint32(droppedCount));
        handler->PSendSysMessage("  roster %u (min %u / max %u) | active now %u (cap %u, %u per player)",
            sPlayerBotMgr->GetRosterSize(), config.RosterMin, config.RosterMax,
            sPlayerBotMgr->GetActiveCount(), config.ActiveMax, config.ActivePerPlayer);
        handler->PSendSysMessage("  reference level %u | spread %u | stragglers %u%% | max-level focus %u%%",
            uint32(sPlayerBotMgr->GetReferenceLevel()), uint32(config.LevelSpread),
            uint32(config.StragglerPct), uint32(config.MaxLevelFocusPct));
        handler->PSendSysMessage("  world pvp %s | combat %s | activation radius %.0f yd",
            config.WorldPvpEnable ? "on" : "off", config.CombatEnable ? "on" : "off", config.ActivationRadius);

        return true;
    }

    static bool HandleBotsSpawnCommand(ChatHandler* handler, char const* args)
    {
        Player* player = handler->GetSession() ? handler->GetSession()->GetPlayer() : nullptr;
        if (!player)
        {
            handler->SendSysMessage("This command has to be used in game.");
            handler->SetSentErrorMessage(true);
            return false;
        }

        uint32 count = 1;
        if (args && *args)
        {
            int32 parsed = atoi(args);
            if (parsed > 0)
                count = uint32(parsed);
        }

        if (count > 200)
            count = 200;

        uint32 spawned = sPlayerBotMgr->SpawnBatch(player, count);
        handler->PSendSysMessage("PlayerBots: spawned %u of %u requested (active %u / %u).",
            spawned, count, sPlayerBotMgr->GetActiveCount(), sPlayerBotMgr->GetConfig().ActiveMax);

        if (!spawned)
            handler->PSendSysMessage("Nothing spawned - check PlayerBots.Enable, the active cap, and that playerbot_profile is populated.");

        return true;
    }

    static bool HandleBotsDespawnCommand(ChatHandler* handler, char const* /*args*/)
    {
        uint32 removed = sPlayerBotMgr->DespawnAll();
        handler->PSendSysMessage("PlayerBots: despawned %u bots.", removed);
        return true;
    }

    static bool HandleBotsReloadCommand(ChatHandler* handler, char const* /*args*/)
    {
        sPlayerBotMgr->LoadConfig(true);
        sPlayerBotMgr->LoadFromDb();
        handler->PSendSysMessage("PlayerBots: reloaded %u profiles, %u areas, %u rotation steps.",
            sPlayerBotMgr->GetProfileCount(), sPlayerBotMgr->GetAreaCount(), sPlayerBotMgr->GetRotationStepCount());
        return true;
    }

    // Rather than trust hand-written coordinates, let the server owner stand
    // where they want bots and record that spot. The row goes straight into the
    // world database, so it survives restarts.
    static bool HandleBotsAddAreaCommand(ChatHandler* handler, char const* args)
    {
        Player* player = handler->GetSession() ? handler->GetSession()->GetPlayer() : nullptr;
        if (!player)
        {
            handler->SendSysMessage("This command has to be used in game.");
            handler->SetSentErrorMessage(true);
            return false;
        }

        uint32 minLevel = 1;
        uint32 maxLevel = 110;
        uint32 radius   = 80;

        if (args && *args)
        {
            uint32 a = 0, b = 0, c = 0;
            int parsed = sscanf(args, "%u %u %u", &a, &b, &c);
            if (parsed >= 2)
            {
                minLevel = a;
                maxLevel = b;
            }
            if (parsed >= 3 && c > 0)
                radius = c;
        }

        if (maxLevel < minLevel)
            std::swap(minLevel, maxLevel);

        WorldDatabase.PExecute(
            "INSERT INTO `playerbot_area` (`map`, `zone`, `x`, `y`, `z`, `radius`, `min_level`, `max_level`, `team_mask`, `weight`, `name`) "
            "VALUES (%u, %u, %f, %f, %f, %f, %u, %u, 3, 1, 'added in game by %s')",
            player->GetMapId(), player->GetZoneId(),
            player->GetPositionX(), player->GetPositionY(), player->GetPositionZ(),
            float(radius), minLevel, maxLevel, player->GetName());

        sPlayerBotMgr->LoadFromDb();

        handler->PSendSysMessage("PlayerBots: spawn area added here (map %u, zone %u, levels %u-%u, radius %u). Areas now loaded: %u.",
            player->GetMapId(), player->GetZoneId(), minLevel, maxLevel, radius, sPlayerBotMgr->GetAreaCount());

        return true;
    }

    static bool HandleBotsLevelCommand(ChatHandler* handler, char const* /*args*/)
    {
        std::vector<uint32> buckets;
        sPlayerBotMgr->GetLevelHistogram(buckets);

        handler->PSendSysMessage("PlayerBots: roster level spread (reference level %u):",
            uint32(sPlayerBotMgr->GetReferenceLevel()));

        for (uint32 i = 0; i < buckets.size(); ++i)
        {
            if (!buckets[i])
                continue;

            handler->PSendSysMessage("  level %u-%u : %u bots", i * 10 == 0 ? 1 : i * 10, (i * 10) + 9, buckets[i]);
        }

        return true;
    }
};

void AddSC_playerbot_wanderer();

void AddSC_playerbots()
{
    new playerbots_world();
    new playerbots_player();
    new playerbots_commandscript();

    AddSC_playerbot_wanderer();
}
