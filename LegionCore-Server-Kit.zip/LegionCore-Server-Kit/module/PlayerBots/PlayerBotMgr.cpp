/*
 * LegionCore PlayerBots - manager
 *
 * Owns the bot roster, the level band derived from the connected players, and
 * the spawn/despawn budget. Bots are only materialised near players; the roster
 * is the logical population of the world.
 */

#include "PlayerBots.h"

#include "Config.h"
#include "Creature.h"
#include "DatabaseEnv.h"
#include "DB2Stores.h"
#include "Log.h"
#include "Map.h"
#include "MapManager.h"
#include "MotionMaster.h"
#include "ObjectAccessor.h"
#include "ObjectMgr.h"
#include "Player.h"
#include "Random.h"
#include "SharedDefines.h"
#include "SpellMgr.h"
#include "TemporarySummon.h"
#include "World.h"

#include <algorithm>
#include <cmath>
#include <utility>

namespace
{
    float const BOT_TWO_PI = 6.2831853f;
}

void PlayerBotUtil::ApplyLevel(Creature* creature, uint8 level)
{
    if (!creature)
        return;

    CreatureTemplate const* cinfo = creature->GetCreatureTemplate();
    if (!cinfo)
        return;

    if (level < 1)
        level = 1;

    creature->SetLevel(level);
    creature->SetEffectiveLevel(0);

    if (CreatureBaseStats const* stats = sObjectMgr->GetCreatureBaseStats(level, cinfo->unit_class))
    {
        uint64 health = stats->GenerateHealth(cinfo);
        if (!health)
            health = 1;

        creature->SetCreateHealth(uint32(health));
        creature->SetMaxHealth(health);
        creature->SetHealth(health);

        uint32 mana = stats->GenerateMana(cinfo);
        creature->SetCreateMana(mana);
        if (mana)
        {
            creature->SetMaxPower(POWER_MANA, mana);
            creature->SetFullPower(POWER_MANA);
        }
    }

    creature->UpdateAllStats();
}

void PlayerBotUtil::ApplyAppearance(Creature* creature, PlayerBotProfile const& profile, PlayerBotConfig const& config)
{
    if (!creature)
        return;

    // Do NOT reach for ChrRaces here. MaleDisplayID/FemaleDisplayID are PLAYER
    // character models: the client builds their skin from character
    // customisation data that only a Player object carries, so a creature
    // wearing one renders as an untextured white figure. The display the bot
    // should use is already on its creature_template_wdb row, applied when the
    // creature was created; leave it alone.

    uint32 faction = (profile.Team == BOT_TEAM_HORDE) ? config.FactionHorde : config.FactionAlliance;
    if (faction)
        creature->setFaction(faction);

    // UNIT_FIELD_SEX *is* UNIT_FIELD_BYTES_0 - one packed uint32 holding
    // race, class, power type and gender. Writing the whole field with
    // SetUInt32Value sets class to 0, and Unit::UpdateAttackPowerAndDamage
    // then does sChrClassesStore.LookupEntry(0)->RangedAttackPowerPerAgility
    // with no null check, which crashes the world server. Touch only the one
    // byte that holds gender.
    creature->SetByteValue(UNIT_FIELD_BYTES_0, UNIT_BYTES_0_OFFSET_GENDER, profile.Gender);
}

PlayerBotMgr* PlayerBotMgr::instance()
{
    static PlayerBotMgr instance;
    return &instance;
}

void PlayerBotMgr::LoadConfig(bool /*reload*/)
{
    _config.Enable              = sConfigMgr->GetBoolDefault("PlayerBots.Enable", false);
    sPlayerBotRealMgr->LoadConfig();

    _config.RosterMin           = uint32(sConfigMgr->GetIntDefault("PlayerBots.World.Min", 200));
    _config.RosterMax           = uint32(sConfigMgr->GetIntDefault("PlayerBots.World.Max", 2000));
    _config.ActiveMax           = uint32(sConfigMgr->GetIntDefault("PlayerBots.Active.Max", 300));
    _config.ActivePerPlayer     = uint32(sConfigMgr->GetIntDefault("PlayerBots.Active.PerPlayer", 40));
    _config.SpawnPerTickMax     = uint32(sConfigMgr->GetIntDefault("PlayerBots.Active.SpawnPerTick", 5));
    _config.UpdateIntervalMs    = uint32(sConfigMgr->GetIntDefault("PlayerBots.UpdateIntervalMs", 2000));
    _config.ActivationRadius    = sConfigMgr->GetFloatDefault("PlayerBots.Active.Radius", 250.0f);
    _config.DeactivationRadius  = sConfigMgr->GetFloatDefault("PlayerBots.Active.DespawnRadius", 450.0f);

    _config.MaxLevel            = uint8(sConfigMgr->GetIntDefault("PlayerBots.Level.Max", 110));
    _config.MinLevel            = uint8(sConfigMgr->GetIntDefault("PlayerBots.Level.Min", 1));
    _config.LevelSpread         = uint8(sConfigMgr->GetIntDefault("PlayerBots.Level.Spread", 10));
    _config.StragglerPct        = uint8(sConfigMgr->GetIntDefault("PlayerBots.Level.StragglerPercent", 15));
    _config.MaxLevelFocusPct    = uint8(sConfigMgr->GetIntDefault("PlayerBots.Level.MaxLevelFocusPercent", 70));
    _config.LevelResyncSeconds  = uint32(sConfigMgr->GetIntDefault("PlayerBots.Level.ResyncSeconds", 60));

    _config.CombatEnable        = sConfigMgr->GetBoolDefault("PlayerBots.Combat.Enable", true);
    _config.WorldPvpEnable      = sConfigMgr->GetBoolDefault("PlayerBots.Combat.WorldPvp", true);
    _config.WanderRadius        = sConfigMgr->GetFloatDefault("PlayerBots.Wander.Radius", 60.0f);
    _config.WanderPauseMinMs    = uint32(sConfigMgr->GetIntDefault("PlayerBots.Wander.PauseMinMs", 4000));
    _config.WanderPauseMaxMs    = uint32(sConfigMgr->GetIntDefault("PlayerBots.Wander.PauseMaxMs", 15000));

    _config.FactionAlliance     = uint32(sConfigMgr->GetIntDefault("PlayerBots.Faction.Alliance", 1801));
    _config.FactionHorde        = uint32(sConfigMgr->GetIntDefault("PlayerBots.Faction.Horde", 1802));

    _config.DebugLog            = sConfigMgr->GetBoolDefault("PlayerBots.DebugLog", false);

    // sanity clamps - a bad config line must never take the server down
    if (_config.MaxLevel < 1)
        _config.MaxLevel = 1;
    if (_config.MinLevel < 1)
        _config.MinLevel = 1;
    if (_config.MinLevel > _config.MaxLevel)
        _config.MinLevel = _config.MaxLevel;
    if (_config.RosterMax < _config.RosterMin)
        _config.RosterMax = _config.RosterMin;
    if (_config.ActiveMax > _config.RosterMax)
        _config.ActiveMax = _config.RosterMax;
    if (_config.StragglerPct > 100)
        _config.StragglerPct = 100;
    if (_config.MaxLevelFocusPct > 100)
        _config.MaxLevelFocusPct = 100;
    if (_config.UpdateIntervalMs < 250)
        _config.UpdateIntervalMs = 250;
    if (_config.DeactivationRadius < _config.ActivationRadius)
        _config.DeactivationRadius = _config.ActivationRadius * 1.5f;
    if (_config.WanderPauseMaxMs < _config.WanderPauseMinMs)
        _config.WanderPauseMaxMs = _config.WanderPauseMinMs;
}

void PlayerBotMgr::LoadFromDb()
{
    _profiles.clear();
    _profileByEntry.clear();
    _areas.clear();
    _rotationStepCount = 0;
    for (uint8 i = 0; i < BOT_ROLE_MAX; ++i)
        _rotations[i].clear();
    _droppedSpells.clear();

    // ---- profiles -------------------------------------------------------
    if (QueryResult result = WorldDatabase.Query("SELECT `entry`, `class`, `race`, `gender`, `role`, `team`, `name` FROM `playerbot_profile` ORDER BY `entry`"))
    {
        do
        {
            Field* fields = result->Fetch();

            PlayerBotProfile profile;
            profile.Entry   = fields[0].GetUInt32();
            profile.ClassId = fields[1].GetUInt8();
            profile.RaceId  = fields[2].GetUInt8();
            profile.Gender  = fields[3].GetUInt8() ? 1 : 0;
            profile.Role    = fields[4].GetUInt8();
            profile.Team    = fields[5].GetUInt8() ? BOT_TEAM_HORDE : BOT_TEAM_ALLIANCE;
            profile.Name    = fields[6].GetString();

            if (profile.Role >= BOT_ROLE_MAX)
                profile.Role = BOT_ROLE_MELEE;

            if (!sObjectMgr->GetCreatureTemplate(profile.Entry))
            {
                TC_LOG_ERROR("server.loading", "PlayerBots: profile %u has no creature_template row, skipped.", profile.Entry);
                continue;
            }

            _profileByEntry[profile.Entry] = uint32(_profiles.size());
            _profiles.push_back(profile);
        }
        while (result->NextRow());
    }

    // ---- spawn areas ----------------------------------------------------
    if (QueryResult result = WorldDatabase.Query("SELECT `id`, `map`, `zone`, `x`, `y`, `z`, `radius`, `min_level`, `max_level`, `team_mask`, `weight`, `name` FROM `playerbot_area` ORDER BY `id`"))
    {
        do
        {
            Field* fields = result->Fetch();

            PlayerBotArea area;
            area.Id       = fields[0].GetUInt32();
            area.MapId    = fields[1].GetUInt32();
            area.ZoneId   = fields[2].GetUInt32();
            area.X        = fields[3].GetFloat();
            area.Y        = fields[4].GetFloat();
            area.Z        = fields[5].GetFloat();
            area.Radius   = fields[6].GetFloat();
            area.MinLevel = fields[7].GetUInt8();
            area.MaxLevel = fields[8].GetUInt8();
            area.TeamMask = fields[9].GetUInt8();
            area.Weight   = fields[10].GetUInt32();
            area.Name     = fields[11].GetString();

            if (area.Radius < 5.0f)
                area.Radius = 5.0f;
            if (!area.Weight)
                area.Weight = 1;
            if (area.MaxLevel < area.MinLevel)
                std::swap(area.MinLevel, area.MaxLevel);
            if (!area.TeamMask)
                area.TeamMask = 3;

            _areas.push_back(area);
        }
        while (result->NextRow());
    }

    // ---- rotations ------------------------------------------------------
    if (QueryResult result = WorldDatabase.Query("SELECT `role`, `priority`, `spell_id`, `condition`, `value`, `cooldown_ms`, `min_range`, `max_range`, `target_self`, `triggered`, `comment` FROM `playerbot_rotation` ORDER BY `role`, `priority`"))
    {
        do
        {
            Field* fields = result->Fetch();

            PlayerBotRotationStep step;
            step.Role       = fields[0].GetUInt8();
            step.Priority   = fields[1].GetUInt8();
            step.SpellId    = fields[2].GetUInt32();
            step.Condition  = fields[3].GetUInt8();
            step.Value      = fields[4].GetFloat();
            step.CooldownMs = fields[5].GetUInt32();
            step.MinRange   = fields[6].GetFloat();
            step.MaxRange   = fields[7].GetFloat();
            step.TargetSelf = fields[8].GetUInt8() != 0;
            step.Triggered  = fields[9].GetUInt8() != 0;
            step.Comment    = fields[10].GetString();

            if (step.Role >= BOT_ROLE_MAX)
            {
                TC_LOG_ERROR("server.loading", "PlayerBots: rotation step for spell %u has invalid role %u, skipped.", step.SpellId, uint32(step.Role));
                continue;
            }

            if (step.Condition >= BOT_COND_MAX)
                step.Condition = BOT_COND_ALWAYS;

            // A spell id that does not exist in this client's data would make the
            // bot silently do nothing, so say so at load time instead.
            if (!sSpellMgr->GetSpellInfo(step.SpellId))
            {
                TC_LOG_ERROR("server.loading", "PlayerBots: rotation spell %u (%s) does not exist in Spell data, skipped.",
                    step.SpellId, step.Comment.c_str());
                _droppedSpells.push_back({ step.SpellId, step.Role, step.Comment });
                continue;
            }

            _rotations[step.Role].push_back(step);
            ++_rotationStepCount;
        }
        while (result->NextRow());
    }

    for (uint8 i = 0; i < BOT_ROLE_MAX; ++i)
        std::sort(_rotations[i].begin(), _rotations[i].end(),
            [](PlayerBotRotationStep const& a, PlayerBotRotationStep const& b) { return a.Priority < b.Priority; });

    _loaded = true;

    TC_LOG_INFO("server.loading", ">> PlayerBots: loaded %u profiles, %u spawn areas, %u rotation steps.",
        uint32(_profiles.size()), uint32(_areas.size()), _rotationStepCount);
}

void PlayerBotMgr::OnWorldStartup()
{
    LoadConfig(false);

    if (!_config.Enable)
    {
        TC_LOG_INFO("server.loading", ">> PlayerBots: disabled (PlayerBots.Enable = 0).");
        return;
    }

    LoadFromDb();

    if (_profiles.empty())
    {
        TC_LOG_ERROR("server.loading", ">> PlayerBots: enabled but no usable profiles were found - the module stays idle. Did you apply the playerbots SQL to the world database?");
        _config.Enable = false;
        return;
    }

    _referenceLevel = _config.MaxLevel;
    BuildRoster();

    TC_LOG_INFO("server.loading", ">> PlayerBots: roster of %u bots ready (at most %u materialised at a time).",
        uint32(_roster.size()), _config.ActiveMax);
}

void PlayerBotMgr::BuildRoster()
{
    _roster.clear();
    _guidToRoster.clear();

    if (_profiles.empty())
        return;

    uint32 size = _config.RosterMax;
    if (size < _config.RosterMin)
        size = _config.RosterMin;

    _roster.reserve(size);
    for (uint32 i = 0; i < size; ++i)
    {
        PlayerBotRosterEntry entry;
        entry.ProfileIndex = urand(0, uint32(_profiles.size()) - 1);
        entry.Level        = RollLevelForBand(_config.MinLevel, _config.MaxLevel);
        _roster.push_back(entry);
    }
}

// Real player-bots are not tied to a spawn area, so they roll against the
// whole configured range using the same distribution.
uint8 PlayerBotMgr::PickLevelForBot() const
{
    return RollLevelForBand(_config.MinLevel, _config.MaxLevel);
}

uint8 PlayerBotMgr::RollLevelForBand(uint8 areaMin, uint8 areaMax) const
{
    uint8 maxLevel = _config.MaxLevel;
    uint8 minLevel = _config.MinLevel;

    if (areaMax > maxLevel)
        areaMax = maxLevel;
    if (areaMin < minLevel)
        areaMin = minLevel;
    if (areaMin > areaMax)
        areaMin = areaMax;

    uint8 reference = _referenceLevel;
    if (reference < minLevel)
        reference = minLevel;
    if (reference > maxLevel)
        reference = maxLevel;

    uint8 level;

    // Players are at (or next to) the level cap: most bots sit at the cap, a few
    // are still levelling in the band below it.
    if (reference + 2 >= maxLevel)
    {
        if (urand(1, 100) <= _config.MaxLevelFocusPct)
            level = maxLevel;
        else
        {
            uint8 low = (maxLevel > _config.LevelSpread) ? uint8(maxLevel - _config.LevelSpread) : minLevel;
            if (low < minLevel)
                low = minLevel;
            level = uint8(urand(low, maxLevel));
        }
    }
    else if (urand(1, 100) <= _config.StragglerPct)
    {
        // the stragglers: anywhere in the world's level range
        level = uint8(urand(minLevel, maxLevel));
    }
    else
    {
        int32 low  = int32(reference) - int32(_config.LevelSpread);
        int32 high = int32(reference) + int32(_config.LevelSpread);
        if (low < int32(minLevel))
            low = int32(minLevel);
        if (high > int32(maxLevel))
            high = int32(maxLevel);
        level = uint8(urand(uint32(low), uint32(high)));
    }

    // keep the bot plausible for where it is going to stand
    if (level < areaMin)
        level = areaMin;
    if (level > areaMax)
        level = areaMax;

    return level;
}

void PlayerBotMgr::RefreshReferenceLevel()
{
    uint32 total = 0;
    uint32 count = 0;

    for (auto const& pair : sObjectAccessor->GetPlayers())
    {
        Player* player = pair.second;
        if (!player || !player->IsInWorld())
            continue;

        total += player->getLevel();
        ++count;
    }

    if (!count)
        return;     // nobody online: keep the last known band

    uint8 average = uint8(total / count);
    if (average < 1)
        average = 1;

    if (average != _referenceLevel)
    {
        _referenceLevel = average;

        // re-level the dormant part of the roster so the world drifts towards the
        // players who are actually here
        for (PlayerBotRosterEntry& entry : _roster)
            if (!entry.Active)
                entry.Level = RollLevelForBand(_config.MinLevel, _config.MaxLevel);

        if (_config.DebugLog)
            TC_LOG_INFO("misc", "PlayerBots: reference level is now %u (from %u player(s)).", uint32(_referenceLevel), count);
    }
}

void PlayerBotMgr::OnPlayerLevelChanged()
{
    _levelTimer = 0;    // force a resync on the next tick
}

void PlayerBotMgr::RegisterBot(Creature* creature)
{
    if (!creature)
        return;

    _activeBots[creature->GetGUID()] = creature;
    _activeCount = uint32(_activeBots.size());
}

void PlayerBotMgr::UnregisterBot(ObjectGuid guid)
{
    _activeBots.erase(guid);
    _activeCount = uint32(_activeBots.size());

    auto itr = _guidToRoster.find(guid);
    if (itr != _guidToRoster.end())
    {
        if (itr->second < _roster.size())
        {
            _roster[itr->second].Active = false;
            _roster[itr->second].Guid.Clear();
        }
        _guidToRoster.erase(itr);
    }
}

std::vector<PlayerBotRotationStep> const& PlayerBotMgr::GetRotation(uint8 role) const
{
    static std::vector<PlayerBotRotationStep> const empty;
    if (role >= BOT_ROLE_MAX)
        return empty;
    return _rotations[role];
}

PlayerBotProfile const* PlayerBotMgr::GetProfileForEntry(uint32 entry) const
{
    auto itr = _profileByEntry.find(entry);
    if (itr == _profileByEntry.end())
        return nullptr;
    return &_profiles[itr->second];
}

uint32 PlayerBotMgr::ResolveFactionTemplate(uint8 /*raceId*/, uint8 team) const
{
    return (team == BOT_TEAM_HORDE) ? _config.FactionHorde : _config.FactionAlliance;
}

uint32 PlayerBotMgr::CountActiveBotsNear(Player* player, float radius) const
{
    uint32 count = 0;
    for (auto const& pair : _activeBots)
    {
        Creature* bot = pair.second;
        if (!bot || !bot->IsInWorld())
            continue;
        if (bot->GetMap() != player->GetMap())
            continue;
        if (bot->GetDistance(player) <= radius)
            ++count;
    }
    return count;
}

PlayerBotArea const* PlayerBotMgr::PickAreaNear(Player* player) const
{
    std::vector<PlayerBotArea const*> candidates;
    uint32 totalWeight = 0;

    for (PlayerBotArea const& area : _areas)
    {
        if (area.MapId != player->GetMapId())
            continue;
        if (area.ZoneId && player->GetZoneId() && area.ZoneId != player->GetZoneId())
            continue;
        if (player->GetExactDist2d(area.X, area.Y) > _config.ActivationRadius + area.Radius)
            continue;

        candidates.push_back(&area);
        totalWeight += area.Weight;
    }

    if (candidates.empty() || !totalWeight)
        return nullptr;

    uint32 roll = urand(1, totalWeight);
    for (PlayerBotArea const* area : candidates)
    {
        if (roll <= area->Weight)
            return area;
        roll -= area->Weight;
    }

    return candidates.front();
}

int32 PlayerBotMgr::PickDormantRosterEntry(uint8 wantedLevel, uint8 teamMask) const
{
    int32 fallback = -1;

    // bounded scan: the roster can be large and this runs on the world thread
    uint32 size = uint32(_roster.size());
    if (!size)
        return -1;

    uint32 start = urand(0, size - 1);
    uint32 const maxScan = std::min<uint32>(size, 256);

    for (uint32 i = 0; i < maxScan; ++i)
    {
        uint32 index = (start + i) % size;
        PlayerBotRosterEntry const& entry = _roster[index];
        if (entry.Active)
            continue;
        if (entry.ProfileIndex >= _profiles.size())
            continue;

        PlayerBotProfile const& profile = _profiles[entry.ProfileIndex];
        uint8 teamBit = (profile.Team == BOT_TEAM_HORDE) ? 2 : 1;
        if (!(teamMask & teamBit))
            continue;

        if (fallback < 0)
            fallback = int32(index);

        int32 delta = int32(entry.Level) - int32(wantedLevel);
        if (delta < 0)
            delta = -delta;
        if (delta <= 2)
            return int32(index);
    }

    return fallback;
}

bool PlayerBotMgr::SpawnOneNear(Player* player)
{
    Map* map = player->GetMap();
    if (!map)
        return false;

    PlayerBotArea const* area = PickAreaNear(player);

    uint8 areaMin  = area ? area->MinLevel : _config.MinLevel;
    uint8 areaMax  = area ? area->MaxLevel : _config.MaxLevel;
    uint8 teamMask = area ? area->TeamMask : uint8(3);

    if (!_config.WorldPvpEnable)
    {
        // no cross-faction trouble: only spawn bots of the player's own side
        teamMask = (player->GetTeamId() == TEAM_HORDE) ? 2 : 1;
    }

    uint8 level = RollLevelForBand(areaMin, areaMax);

    int32 rosterIndex = PickDormantRosterEntry(level, teamMask);
    if (rosterIndex < 0)
        return false;

    PlayerBotRosterEntry& entry = _roster[uint32(rosterIndex)];
    if (entry.ProfileIndex >= _profiles.size())
        return false;

    PlayerBotProfile const& profile = _profiles[entry.ProfileIndex];
    entry.Level = level;

    Position pos;
    if (area)
    {
        float angle = frand(0.0f, BOT_TWO_PI);
        float dist  = frand(3.0f, area->Radius);
        float x = area->X + dist * std::cos(angle);
        float y = area->Y + dist * std::sin(angle);
        float z = area->Z;

        float ground = map->GetHeight(x, y, z + 12.0f, true, 60.0f);
        if (ground > -5000.0f)
            z = ground;

        pos.Relocate(x, y, z);
        pos.SetOrientation(frand(0.0f, BOT_TWO_PI));
    }
    else
    {
        // Relocate, not operator=: Position declares a copy constructor but no
        // copy-assignment, so the implicit one is deprecated.
        pos.Relocate(player->GetRandomNearPosition(frand(20.0f, 60.0f)));
    }

    TempSummon* summon = map->SummonCreature(profile.Entry, pos);
    if (!summon)
        return false;

    PlayerBotUtil::ApplyAppearance(summon, profile, _config);
    PlayerBotUtil::ApplyLevel(summon, level);

    entry.Active = true;
    entry.Guid   = summon->GetGUID();
    entry.AreaId = area ? area->Id : 0;

    _guidToRoster[summon->GetGUID()] = uint32(rosterIndex);

    if (_config.DebugLog)
        TC_LOG_INFO("misc", "PlayerBots: spawned entry %u (%s, level %u) near %s.",
            profile.Entry, profile.Name.c_str(), uint32(level), player->GetName());

    return true;
}

void PlayerBotMgr::SpawnNearPlayers()
{
    if (_activeBots.size() >= _config.ActiveMax)
        return;

    uint32 spawnedThisTick = 0;

    for (auto const& pair : sObjectAccessor->GetPlayers())
    {
        Player* player = pair.second;
        if (!player || !player->IsInWorld())
            continue;
        if (player->isGameMaster())
            continue;

        Map* map = player->GetMap();
        if (!map)
            continue;

        // milestone 1 is the open world only - instances are handled by the
        // queue work, not by wanderers
        if (map->IsDungeon() || map->IsBattlegroundOrArena())
            continue;

        uint32 nearbyBots = CountActiveBotsNear(player, _config.ActivationRadius);

        while (nearbyBots < _config.ActivePerPlayer
            && _activeBots.size() < _config.ActiveMax
            && spawnedThisTick < _config.SpawnPerTickMax)
        {
            if (!SpawnOneNear(player))
                break;

            ++nearbyBots;
            ++spawnedThisTick;
        }

        if (spawnedThisTick >= _config.SpawnPerTickMax)
            break;
    }
}

void PlayerBotMgr::DespawnDistantBots()
{
    if (_activeBots.empty())
        return;

    std::vector<Creature*> toDespawn;

    for (auto const& pair : _activeBots)
    {
        Creature* bot = pair.second;
        if (!bot || !bot->IsInWorld())
            continue;
        if (bot->isInCombat())
            continue;

        bool keep = false;
        for (auto const& playerPair : sObjectAccessor->GetPlayers())
        {
            Player* player = playerPair.second;
            if (!player || !player->IsInWorld())
                continue;
            if (player->GetMap() != bot->GetMap())
                continue;
            if (player->GetDistance(bot) <= _config.DeactivationRadius)
            {
                keep = true;
                break;
            }
        }

        if (!keep)
            toDespawn.push_back(bot);
    }

    // despawn outside the loop: this ends up calling back into UnregisterBot
    for (Creature* bot : toDespawn)
        bot->DespawnOrUnsummon();
}

void PlayerBotMgr::Update(uint32 diff)
{
    if (!_config.Enable || !_loaded)
        return;

    if (_updateTimer > diff)
    {
        _updateTimer -= diff;
        return;
    }
    _updateTimer = _config.UpdateIntervalMs;

    if (_levelTimer > diff)
        _levelTimer -= diff;
    else
    {
        _levelTimer = _config.LevelResyncSeconds * IN_MILLISECONDS;
        RefreshReferenceLevel();
    }

    DespawnDistantBots();
    SpawnNearPlayers();
}

uint32 PlayerBotMgr::SpawnBatch(Player* player, uint32 count)
{
    if (!player)
        return 0;

    uint32 spawned = 0;
    for (uint32 i = 0; i < count; ++i)
    {
        if (_activeBots.size() >= _config.ActiveMax)
            break;
        if (!SpawnOneNear(player))
            break;
        ++spawned;
    }

    return spawned;
}

uint32 PlayerBotMgr::DespawnAll()
{
    std::vector<Creature*> bots;
    bots.reserve(_activeBots.size());

    for (auto const& pair : _activeBots)
        if (pair.second && pair.second->IsInWorld())
            bots.push_back(pair.second);

    for (Creature* bot : bots)
        bot->DespawnOrUnsummon();

    return uint32(bots.size());
}

void PlayerBotMgr::GetLevelHistogram(std::vector<uint32>& buckets) const
{
    buckets.assign(uint32(_config.MaxLevel / 10) + 1, 0);

    for (PlayerBotRosterEntry const& entry : _roster)
    {
        uint32 bucket = uint32(entry.Level) / 10;
        if (bucket >= buckets.size())
            bucket = uint32(buckets.size()) - 1;
        ++buckets[bucket];
    }
}
