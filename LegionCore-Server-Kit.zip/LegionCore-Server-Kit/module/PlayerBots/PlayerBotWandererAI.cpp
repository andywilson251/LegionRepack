/*
 * LegionCore PlayerBots - wanderer AI
 *
 * One of these runs per materialised bot. It keeps the bot moving around its
 * patch of the world, picks fights that make sense, and casts from the
 * data-driven rotation table for its role.
 */

#include "PlayerBots.h"

#include "Creature.h"
#include "Log.h"
#include "Map.h"
#include "MotionMaster.h"
#include "Player.h"
#include "Random.h"
#include "ScriptedCreature.h"
#include "ScriptMgr.h"
#include "SharedDefines.h"
#include "SpellInfo.h"
#include "SpellMgr.h"
#include "Unit.h"

#include <cmath>
#include <algorithm>

namespace
{
    uint32 const BOT_WANDER_POINT_ID = 7001;
    float  const BOT_TWO_PI          = 6.2831853f;
}

struct PlayerBotWandererAI : public ScriptedAI
{
    explicit PlayerBotWandererAI(Creature* creature) : ScriptedAI(creature)
    {
        _profile     = sPlayerBotMgr->GetProfileForEntry(creature->GetEntry());
        _role        = _profile ? _profile->Role : uint8(BOT_ROLE_MELEE);
        _wanderTimer = urand(1000, 6000);
        _huntTimer   = urand(2000, 5000);
        _globalCd    = 0;

        _home.Relocate(creature);
    }

    ~PlayerBotWandererAI()
    {
        sPlayerBotMgr->UnregisterBot(_guid);
    }

    void InitializeAI() override
    {
        ScriptedAI::InitializeAI();

        _guid = me->GetGUID();
        _home.Relocate(me);

        sPlayerBotMgr->RegisterBot(me);

        me->SetReactState(REACT_AGGRESSIVE);
        me->SetHomePosition(_home);
    }

    void JustDied(Unit* /*killer*/) override
    {
        // free the roster slot straight away; the corpse cleans itself up
        sPlayerBotMgr->UnregisterBot(_guid);
    }

    void EnterEvadeMode() override
    {
        ScriptedAI::EnterEvadeMode();
        _wanderTimer = urand(2000, 5000);
    }

    void MovementInform(uint32 type, uint32 id) override
    {
        if (type == POINT_MOTION_TYPE && id == BOT_WANDER_POINT_ID)
        {
            PlayerBotConfig const& config = sPlayerBotMgr->GetConfig();
            _wanderTimer = urand(config.WanderPauseMinMs, config.WanderPauseMaxMs);
        }
    }

    void UpdateAI(uint32 diff) override
    {
        PlayerBotConfig const& config = sPlayerBotMgr->GetConfig();

        TickCooldowns(diff);

        if (!UpdateVictim())
        {
            DoWander(diff, config);
            DoHuntForTargets(diff, config);
            return;
        }

        if (!config.CombatEnable)
            return;

        if (me->HasUnitState(UNIT_STATE_CASTING))
            return;

        if (DoRotation())
            return;

        // nothing castable: close the gap and swing
        DoMeleeAttackIfReady();
    }

private:
    // ---------------------------------------------------------------- idle
    void DoWander(uint32 diff, PlayerBotConfig const& config)
    {
        if (_wanderTimer > diff)
        {
            _wanderTimer -= diff;
            return;
        }

        _wanderTimer = urand(config.WanderPauseMinMs, config.WanderPauseMaxMs);

        if (me->isInCombat() || !me->IsAlive())
            return;

        float angle = frand(0.0f, BOT_TWO_PI);
        float dist  = frand(8.0f, std::max<float>(10.0f, config.WanderRadius));

        float x = _home.GetPositionX() + dist * std::cos(angle);
        float y = _home.GetPositionY() + dist * std::sin(angle);
        float z = _home.GetPositionZ();

        if (Map* map = me->GetMap())
        {
            float ground = map->GetHeight(x, y, z + 10.0f, true, 50.0f);
            if (ground > -5000.0f)
                z = ground;
        }

        me->GetMotionMaster()->MovePoint(BOT_WANDER_POINT_ID, x, y, z);
    }

    // Look for something worth fighting. Creature auto-aggro already handles
    // anything that walks into us; this makes the bots look like they are out
    // there doing something rather than standing around.
    void DoHuntForTargets(uint32 diff, PlayerBotConfig const& config)
    {
        if (!config.CombatEnable)
            return;

        if (_huntTimer > diff)
        {
            _huntTimer -= diff;
            return;
        }

        _huntTimer = urand(3000, 8000);

        if (me->isInCombat() || !me->IsAlive())
            return;

        Unit* target = me->SelectNearestTarget(35.0f);
        if (!target || target == me)
            return;

        if (!me->IsValidAttackTarget(target))
            return;

        // do not chase players across the zone unless world pvp is on
        if (target->IsPlayer() && !config.WorldPvpEnable)
            return;

        // stay near home: a bot that chases forever ends up on another continent
        if (_home.GetExactDist(target) > config.WanderRadius * 3.0f)
            return;

        AttackStart(target);
    }

    // ------------------------------------------------------------- combat
    void TickCooldowns(uint32 diff)
    {
        if (_globalCd > diff)
            _globalCd -= diff;
        else
            _globalCd = 0;

        for (auto& pair : _cooldowns)
        {
            if (pair.second > diff)
                pair.second -= diff;
            else
                pair.second = 0;
        }
    }

    bool CheckCondition(uint8 condition, float value, Unit* victim) const
    {
        switch (condition)
        {
            case BOT_COND_ALWAYS:
                return true;
            case BOT_COND_SELF_HP_BELOW_PCT:
                return me->GetHealthPct() < value;
            case BOT_COND_SELF_HP_ABOVE_PCT:
                return me->GetHealthPct() > value;
            case BOT_COND_TARGET_HP_BELOW_PCT:
                return victim && victim->GetHealthPct() < value;
            case BOT_COND_TARGET_HP_ABOVE_PCT:
                return victim && victim->GetHealthPct() > value;
            case BOT_COND_ENEMIES_AROUND_MIN:
                return float(CountNearbyEnemies()) >= value;
            case BOT_COND_TARGET_IS_PLAYER:
                return victim && victim->IsPlayer();
            case BOT_COND_TARGET_IS_NOT_PLAYER:
                return victim && !victim->IsPlayer();
            default:
                return false;
        }
    }

    // Cheap proxy for "is this a brawl or a duel": everything already swinging
    // at us. This is what keeps bots from firing weak area spells at a single
    // enemy player in world pvp - the aoe rows require several enemies.
    uint32 CountNearbyEnemies() const
    {
        UnitSet* attackers = const_cast<Creature*>(me)->getAttackers();
        uint32 count = attackers ? uint32(attackers->size()) : 0;

        if (Unit* victim = me->getVictim())
            if (!attackers || attackers->find(victim) == attackers->end())
                ++count;

        return count;
    }

    bool DoRotation()
    {
        Unit* victim = me->getVictim();
        if (!victim)
            return false;

        std::vector<PlayerBotRotationStep> const& rotation = sPlayerBotMgr->GetRotation(_role);
        if (rotation.empty())
            return false;

        if (_globalCd)
            return false;

        float distance = me->GetDistance(victim);

        for (PlayerBotRotationStep const& step : rotation)
        {
            auto itr = _cooldowns.find(step.SpellId);
            if (itr != _cooldowns.end() && itr->second > 0)
                continue;

            if (!CheckCondition(step.Condition, step.Value, victim))
                continue;

            if (!step.TargetSelf && (distance < step.MinRange || distance > step.MaxRange))
                continue;

            Unit* target = step.TargetSelf ? me : victim;

            if (!step.TargetSelf && !me->IsValidAttackTarget(target))
                continue;

            if (me->HasSpellCooldown(step.SpellId))
                continue;

            DoCast(target, step.SpellId, step.Triggered);

            _cooldowns[step.SpellId] = step.CooldownMs ? step.CooldownMs : 1500;
            _globalCd = 1500;
            return true;
        }

        return false;
    }

    PlayerBotProfile const*                 _profile    = nullptr;
    uint8                                   _role       = BOT_ROLE_MELEE;
    uint32                                  _wanderTimer = 0;
    uint32                                  _huntTimer  = 0;
    uint32                                  _globalCd   = 0;
    Position                                _home;
    ObjectGuid                              _guid;
    std::unordered_map<uint32, uint32>      _cooldowns;
};

class npc_playerbot_wanderer : public CreatureScript
{
public:
    npc_playerbot_wanderer() : CreatureScript("npc_playerbot_wanderer") { }

    CreatureAI* GetAI(Creature* creature) const override
    {
        return new PlayerBotWandererAI(creature);
    }
};

void AddSC_playerbot_wanderer()
{
    new npc_playerbot_wanderer();
}
