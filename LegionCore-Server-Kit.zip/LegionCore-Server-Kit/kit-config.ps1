<#
================================================================================
 LegionCore 7.3.5 - Server Kit : central configuration
================================================================================
 Edit this file first.  Every numbered script in the kit reads it.

 The defaults below produce a working single-PC server:
   * MySQL on 127.0.0.1:3306, user "root", password "admin"  (matches the
     stock 127.0.0.1;3306;root;admin;<db> defaults in the core's own confs)
   * server installed to C:\LegionCore
   * libraries (Boost/OpenSSL/MySQL) in C:\libs
 Change the values here (and nowhere else) if you want different paths/passwords.
================================================================================
#>

# ---------------------------------------------------------------- install root
# (optional) relocate everything without editing this file:
#   set LEGIONCORE_INSTALL_ROOT=D:\LegionCore
#   set LEGIONCORE_LIBS_ROOT=D:\libs
$InstallRoot   = if ($env:LEGIONCORE_INSTALL_ROOT) { $env:LEGIONCORE_INSTALL_ROOT } else { 'C:\LegionCore' }
$LibsRoot      = if ($env:LEGIONCORE_LIBS_ROOT)    { $env:LEGIONCORE_LIBS_ROOT }    else { 'C:\libs' }
$SourceDir     = Join-Path $InstallRoot 'source'        # git clone of LegionCore
$BuildDir      = Join-Path $InstallRoot 'build'         # cmake build tree
$ServerDir     = Join-Path $InstallRoot 'server'        # exes + dlls + confs (working dir)
$DownloadsDir  = Join-Path $InstallRoot 'downloads'     # installers / base DB archives

# ------------------------------------------------------------------ client data
# dbc / maps / vmaps / mmaps / cameras / gt live here (worldserver's DataDir)
$ClientDataDir = Join-Path $InstallRoot 'ClientData'

# Your WoW 7.3.5 (build 26972) client folder - it must contain a Data\ folder
# (with Data\config and Data\data inside). A missing .build.info is rebuilt by
# step 5 automatically.
# <-- EDIT THIS LINE
$ClientDir     = 'C:\World of Warcraft 7.3.5'

# Client language, only needed if step 5 cannot work it out by itself.
# Leave empty to detect it; otherwise set one of:
# enUS koKR frFR deDE zhCN esES zhTW enGB enCN enTW itIT ptPT esMX ptBR ruRU
$ClientLocaleOverride = ''

# ---------------------------------------------------------------------- libraries
$BoostRoot   = Join-Path $LibsRoot 'boost'              # extracted prebuilt Boost 1.84
$OpenSslRoot = Join-Path $LibsRoot 'openssl'            # OpenSSL 3.x x64
$MySqlRoot   = Join-Path $LibsRoot 'mysql-8.0'          # MySQL 8.0 zip (server + libmysql.dll)

# -------------------------------------------------------------------------- mysql
$MySqlHost = '127.0.0.1'
$MySqlPort = 3306
$MySqlUser = 'root'
$MySqlPass = 'admin'

# --------------------------------------------------------------------------- realm
$RealmName    = 'LegionCore'
$RealmAddress = '127.0.0.1'          # put your LAN/public IP here if friends connect
$WorldPort    = 8085

# ------------------------------------------------------------- admin game account
# Created/updated by 3-Setup-Databases.ps1.
$AdminLogin    = 'GM@GM'             # login name typed in the client ("name@name" style)
$AdminPassword = 'admin'
$AdminGmLevel  = 6                   # 6 = administrator (see docs; 7 = console)

# ------------------------------------------------------------------ source & files
$RepoUrl = 'https://github.com/The-Legion-Preservation-Project/LegionCore-7.3.5.git'

# Base world/hotfixes databases (official release asset, 33 MB .7z -> 268 MB SQL)
$BaseDatabaseUrl      = 'https://github.com/The-Legion-Preservation-Project/LegionCore-7.3.5/releases/download/LegionCore735.24101/LegionCore_full_735.26972_2024_10_23.7z'
$BaseDatabase7zSha256 = 'CF681E1FB2E7443DAAB2A5DB04F4EFA2FC53CC485EA8DE6B6EC3D60D569C2696'
$BaseWorldFile        = 'LegionCore_world_735.26972_2024_10_23.sql'
$BaseHotfixesFile     = 'LegionCore_hotfixes_735.26972_2024_10_23.sql'
$BaseWorldSha256      = '0265CC795B6507F8918162293E7C905143CDB2EF227EE72179BB43BCF889F68C'
$BaseHotfixesSha256   = '437EF854F35DFF7CB39CB34766769CEC1B113A00A5F513361D3A8FCC6E48A96F'

# --------------------------------------------------------------- build dependencies
$BoostUrl        = 'https://github.com/MarkusJx/prebuilt-boost/releases/download/1.84.0/boost-1.84.0-windows-2022-msvc-static-x86.tar.gz'
$BoostSizeBytes  = 646990325
# Pinned MySQL archive; the original dev.mysql.com redirect can return an error page.
$MySqlZipUrl       = 'https://cdn.mysql.com/archives/mysql-8.0/mysql-8.0.43-winx64.zip'
$MySqlZipSizeBytes = 244242563
$MySqlZipSha256    = '745B4A9535992705AC43A5645B84D213A579C8FD866D1B5DCE8D6EE5A2FC7728'
$MySqlZipTopFolder = 'mysql-8.0.43-winx64'
$SevenZipUrl     = 'https://www.7-zip.org/a/7zr.exe'
