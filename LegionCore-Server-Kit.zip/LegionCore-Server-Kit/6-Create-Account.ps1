<#
================================================================================
 LegionCore 7.3.5 - Server Kit : create a game account
================================================================================
 Creates (or resets the password of) an account directly in the auth database,
 using the exact password hash the core itself computes
 (AccountMgr::CalculateShaPassHash - SHA256 of "<SHA256(upper(login))>:<upper(pw)>",
 final digest byte-reversed - verified against the shipped GM@GM account row).

 Run:   powershell -ExecutionPolicy Bypass -File .\6-Create-Account.ps1 -Login "player@realm" -Password "secret"
        -Login "x@y" -Password "z" -GmLevel 6     (administrator)
        -Login "x@y" -Password "z"                (normal player, gmlevel 0)

 GM levels: 0 = player, 1 = moderator, 2 = gamemaster, 6 = administrator, 7 = console
 Note: use ASCII only, and the "name@name" login style the client expects.
================================================================================
#>
#Requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$Login,
    [Parameter(Mandatory=$true)][string]$Password,
    [int]$GmLevel = 0
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'kit-config.ps1')
. (Join-Path $PSScriptRoot 'tools\MySql-Client.ps1')

function Ok($m)   { Write-Host "  [ok] $m" -ForegroundColor Green }
function Info($m) { Write-Host "  $m" -ForegroundColor Gray }
function Die($m)  { Write-Host "`n  [XX] $m" -ForegroundColor Red; exit 1 }

# --- find mysql client --------------------------------------------------------
function Find-MySqlClient {
    foreach ($c in @((Join-Path $MySqlRoot 'bin\mysql.exe'), "$env:ProgramFiles\MySQL\MySQL Server 8.0\bin\mysql.exe")) {
        if ($c -and (Test-Path $c)) { return $c }
    }
    foreach ($n in 'mysql.exe','mysql','mariadb') {
        $g = Get-Command $n -ErrorAction SilentlyContinue
        if ($g) { return $g.Source }
    }
    return $null
}
$mysql = Find-MySqlClient
if (-not $mysql) { Die "mysql client not found - run 1-Install-Prerequisites.ps1." }

function Invoke-MySqlQuery {
    param([string]$Query, [string]$Database = 'auth')
    $result = Invoke-LegionMySql -Executable $mysql -HostName $MySqlHost -Port $MySqlPort `
        -User $MySqlUser -Password $MySqlPass -Query $Query -Database $Database
    if ($result.ExitCode -ne 0) { Die "MySQL query failed (exit $($result.ExitCode)).`n$($result.StdErr)" }
    if ($result.StdErr) { Write-Verbose $result.StdErr.Trim() }
    return $result.StdOut.Trim()
}

function Get-AccountPasswordHash {
    param([string]$User, [string]$Password)
    $u  = $User.ToUpperInvariant()
    $pw = $Password.ToUpperInvariant()
    if ($u -match '[^\x20-\x7E]' -or $pw -match '[^\x20-\x7E]') { Write-Host "  [!!] non-ASCII characters detected - the core only converts latin1, use ASCII." -ForegroundColor Yellow }
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $h1  = $sha.ComputeHash([Text.Encoding]::ASCII.GetBytes($u))
        $hex = -join ($h1 | ForEach-Object { $_.ToString('X2') })
        $h2  = $sha.ComputeHash([Text.Encoding]::ASCII.GetBytes(($hex + ':' + $pw)))
        [array]::Reverse($h2)
        return (-join ($h2 | ForEach-Object { $_.ToString('X2') }))
    } finally { $sha.Dispose() }
}

$hash = Get-AccountPasswordHash -User $Login -Password $Password
Info "login : $Login"
Info "hash  : $hash"
Invoke-MySqlQuery "INSERT INTO ``account`` (``username``,``sha_pass_hash``,``joindate``) VALUES ('$Login','$hash',NOW()) ON DUPLICATE KEY UPDATE ``sha_pass_hash``=VALUES(``sha_pass_hash``), ``v``='', ``s``='';" | Out-Null
$id = Invoke-MySqlQuery "SELECT ``id`` FROM ``account`` WHERE ``username``='$Login';"
if ($GmLevel -gt 0) {
    Invoke-MySqlQuery "REPLACE INTO ``account_access`` (``id``,``gmlevel``,``RealmID``,``comments``) VALUES ($id,$GmLevel,-1,'created by kit');" | Out-Null
    Ok "account '$Login' (id $id) saved with gmlevel $GmLevel"
} else {
    Invoke-MySqlQuery "DELETE FROM ``account_access`` WHERE ``id``=$id;" | Out-Null
    Ok "account '$Login' (id $id) saved as a normal player"
}
Write-Host "`n  Log in in the WoW client with exactly:  $Login / $Password" -ForegroundColor Green
