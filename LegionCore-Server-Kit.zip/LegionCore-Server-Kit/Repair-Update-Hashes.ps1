<#
================================================================================
 LegionCore 7.3.5 - Server Kit : repair the SQL update hashes
================================================================================
 Fixes this worldserver/bnetserver startup failure:

   >> Reapplying update "2024_11_24_drop_transferts.sql" '33553C5' -> 'A6D52F8' (it changed)...
   ERROR 1051 (42S02) ... Unknown table 'auth.transferts'
   Could not update the Login database, see log for details.

 Cause: the updates were applied correctly, but the SHA1 recorded for each file
 was taken from the bytes on disk. The core reads .sql files in text mode, where
 Windows turns CRLF into LF before hashing, so every file in a CRLF checkout
 looks "changed" at startup and gets applied a second time - which fails,
 because the first run already dropped/created those objects.

 This script recomputes every hash the way the core does and corrects the rows.
 It does not run any of the update files again and changes nothing else; the
 old rows are written to a .sql backup first.

 Run:   powershell -ExecutionPolicy Bypass -File .\Repair-Update-Hashes.ps1
        -DryRun          only report what would change
        -Force           also rehash files whose content really differs
                         (default: those are reported and left for the core)
        -SourceDir <dir> override the folder that holds sql\ (normally taken
                         from Updates.SourcePath in worldserver.conf)
================================================================================
#>
#Requires -Version 5.1
[CmdletBinding()]
param(
    [switch]$DryRun,
    [switch]$Force,
    [string]$SourceDir = '',
    [string[]]$Databases = @('auth', 'characters', 'world', 'hotfixes')
)
$ErrorActionPreference = 'Stop'
$SourceDirOverride = $SourceDir
. (Join-Path $PSScriptRoot 'kit-config.ps1')
. (Join-Path $PSScriptRoot 'tools\MySql-Client.ps1')
. (Join-Path $PSScriptRoot 'tools\Sql-Updates.ps1')

function Step($m) { Write-Host "`n=== $m" -ForegroundColor Cyan }
function Ok($m)   { Write-Host "  [ok] $m" -ForegroundColor Green }
function Info($m) { Write-Host "  $m" -ForegroundColor Gray }
function Warn($m) { Write-Host "  [!!] $m" -ForegroundColor Yellow }
function Die($m)  { Write-Host "`n  [XX] $m" -ForegroundColor Red; exit 1 }

function Find-MySqlClient {
    $cand = @(
        (Join-Path $MySqlRoot 'bin\mysql.exe'),
        "$env:ProgramFiles\MySQL\MySQL Server 8.0\bin\mysql.exe",
        "$env:ProgramFiles\MySQL\MySQL Server 8.4\bin\mysql.exe",
        "${env:ProgramFiles(x86)}\MySQL\MySQL Server 8.0\bin\mysql.exe"
    )
    foreach ($c in $cand) { if ($c -and (Test-Path $c)) { return $c } }
    foreach ($n in 'mysql.exe', 'mysql', 'mariadb') {
        $g = Get-Command $n -ErrorAction SilentlyContinue
        if ($g) { return $g.Source }
    }
    return $null
}
function Invoke-MySqlQuery {
    param([string]$Query, [string]$Database = '')
    $result = Invoke-LegionMySql -Executable $script:MySqlExe -HostName $MySqlHost -Port $MySqlPort `
        -User $MySqlUser -Password $MySqlPass -Query $Query -Database $Database
    if ($result.ExitCode -ne 0) { throw "MySQL query failed (exit $($result.ExitCode)).`n$($result.StdErr)" }
    return $result.StdOut
}
function Get-MySqlRows {
    param([string]$Query, [string]$Database = '')
    $out = Invoke-MySqlQuery -Query $Query -Database $Database
    $rows = @()
    foreach ($line in ($out -split '\r?\n')) {
        if ($line.Trim().Length -eq 0) { continue }
        $rows += , ($line -split "`t")
    }
    return $rows
}
function ConvertTo-SqlLiteral {
    param([AllowEmptyString()][string]$Value)
    return "'" + ($Value -replace '\\', '\\' -replace "'", "''") + "'"
}

# ==============================================================================
Step "1/5  Connecting and locating the SQL tree"
$script:MySqlExe = Find-MySqlClient
if (-not $script:MySqlExe) { Die "mysql.exe not found. Run 1-Install-Prerequisites.ps1 or set `$MySqlRoot in kit-config.ps1." }
try { $ver = (Invoke-MySqlQuery 'SELECT VERSION();').Trim() } catch { Die "Cannot connect to MySQL at $MySqlHost`:$MySqlPort as '$MySqlUser'.`n       $_" }
Ok "MySQL $ver"

$confPath = Join-Path $ServerDir 'worldserver.conf'
$resolved = Get-LegionUpdatesSourceDir -ConfigPath $confPath -Fallback $SourceDir
if ($SourceDirOverride) { $resolved = [pscustomobject]@{ Path = $SourceDirOverride; Source = '-SourceDir' } }
$updatesRoot = $resolved.Path
if (-not $updatesRoot) { Die "Could not work out where the sql\ tree is. Pass -SourceDir <folder containing sql\>." }
if (-not (Test-Path -LiteralPath (Join-Path $updatesRoot 'sql'))) {
    Die ("$updatesRoot does not contain a sql\ folder.`n" +
         "       worldserver reads its updates from there, so this path must be the one in`n" +
         "       Updates.SourcePath ($confPath). Pass -SourceDir <folder> to override.")
}
Ok "source tree: $updatesRoot  (from $($resolved.Source))"

# ==============================================================================
Step "2/5  Comparing every recorded hash with the file the core reads"
$plan = @()
$report = @()
foreach ($db in $Databases) {
    $exists = (Invoke-MySqlQuery "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='$db' AND table_name='updates';").Trim()
    if ($exists -notmatch '1') { Warn "database '$db' has no updates table - skipped"; continue }

    $includeRows = Get-MySqlRows -Database $db -Query 'SELECT `path`,`state` FROM `updates_include`;'
    $includes = @()
    foreach ($r in $includeRows) { $includes += [pscustomobject]@{ Path = $r[0]; State = $r[1] } }
    if ($includes.Count -eq 0) { Warn "'$db': updates_include is empty - the core would not look at any file"; continue }

    $scan = Get-LegionSqlUpdateFiles -IncludeDirectories $includes -SourceDir $updatesRoot
    foreach ($d in $scan.MissingDirectories) { Warn "'$db': include directory not found: $d" }
    foreach ($d in $scan.Duplicates) { Warn "'$db': duplicate update file name '$($d.Name)' ($($d.First) / $($d.Second)) - the core refuses to start on this" }

    $rows = Get-MySqlRows -Database $db -Query 'SELECT `name`,`hash`,`state` FROM `updates` ORDER BY `name`;'
    $okCount = 0; $eol = 0; $changed = 0; $missing = 0
    foreach ($row in $rows) {
        $name = $row[0]; $stored = ($row[1]).Trim().ToUpperInvariant()
        if (-not $scan.Files.Contains($name)) { $missing++; continue }
        $file = $scan.Files[$name]
        $coreHash = Get-LegionSqlUpdateHash -Path $file.Path
        if ($stored -eq $coreHash) { $okCount++; continue }
        $rawHash = Get-LegionSqlFileHashRaw -Path $file.Path
        $kind = if ($stored -eq $rawHash) { 'line-endings' } else { 'content' }
        if ($kind -eq 'line-endings') { $eol++ } else { $changed++ }
        $plan += [pscustomobject]@{ Database = $db; Name = $name; Stored = $stored; Correct = $coreHash; Kind = $kind; Path = $file.Path }
    }
    $newFiles = @($scan.Files.Keys | Where-Object { $n = $_; -not ($rows | Where-Object { $_[0] -eq $n }) })
    $report += [pscustomobject]@{ Database = $db; Rows = $rows.Count; Correct = $okCount; LineEndings = $eol; Content = $changed; Missing = $missing; NotApplied = $newFiles.Count }
    Info ("{0,-11} {1,4} rows   {2,4} correct   {3,4} wrong (line endings)   {4,3} wrong (content)   {5,3} file gone   {6,3} not applied yet" -f `
          $db, $rows.Count, $okCount, $eol, $changed, $missing, $newFiles.Count)
}
$eolTotal = @($plan | Where-Object Kind -eq 'line-endings').Count
$contentTotal = @($plan | Where-Object Kind -eq 'content').Count
if ($plan.Count -eq 0) {
    Ok "every recorded hash already matches - nothing to repair"
    Write-Host "`n  If the server still reports a changed update, run it again and send the file name." -ForegroundColor Green
    exit 0
}
Warn "$($plan.Count) row(s) would make the server re-apply an update: $eolTotal from line endings, $contentTotal from different content"
foreach ($p in ($plan | Select-Object -First 8)) {
    Info ("  {0,-10} {1,-52} {2} -> {3}  [{4}]" -f $p.Database, $p.Name, $p.Stored.Substring(0, 7), $p.Correct.Substring(0, 7), $p.Kind)
}
if ($plan.Count -gt 8) { Info "  ... and $($plan.Count - 8) more" }
if ($contentTotal -gt 0 -and -not $Force) {
    Warn "the $contentTotal 'content' row(s) are NOT touched: those files really differ from what was applied."
    Warn "the core will re-apply them, which is usually correct. Use -Force to rehash them instead."
}

# ==============================================================================
Step "3/5  Backing up the current rows"
$toFix = if ($Force) { $plan } else { @($plan | Where-Object Kind -eq 'line-endings') }
if ($toFix.Count -eq 0) { Ok "nothing to change"; exit 0 }
if ($DryRun) {
    Info "-DryRun: no backup written, no row changed"
} else {
    $logDir = Join-Path $InstallRoot 'logs'
    New-Item -ItemType Directory -Force -Path $logDir | Out-Null
    $backup = Join-Path $logDir "updates-hash-backup-$(Get-Date -Format 'yyyyMMdd-HHmmss').sql"
    $lines = @('-- LegionCore kit: the update hashes as they were before the repair',
               '-- restore them with:  mysql -u root -p < this file', '')
    foreach ($db in ($plan.Database | Select-Object -Unique)) {
        $lines += "USE ``$db``;"
        foreach ($p in ($plan | Where-Object Database -eq $db)) {
            $lines += "UPDATE ``updates`` SET ``hash``=$(ConvertTo-SqlLiteral $p.Stored) WHERE ``name``=$(ConvertTo-SqlLiteral $p.Name);"
        }
        $lines += ''
    }
    [IO.File]::WriteAllText($backup, (($lines -join "`r`n") + "`r`n"), (New-Object Text.UTF8Encoding $false))
    Ok "backup: $backup"
}

# ==============================================================================
Step "4/5  Correcting the hashes"
if ($DryRun) {
    Info "-DryRun: would update $($toFix.Count) row(s)"
} else {
    foreach ($db in ($toFix.Database | Select-Object -Unique)) {
        $statements = @()
        foreach ($p in ($toFix | Where-Object Database -eq $db)) {
            $statements += "UPDATE ``updates`` SET ``hash``=$(ConvertTo-SqlLiteral $p.Correct) WHERE ``name``=$(ConvertTo-SqlLiteral $p.Name);"
        }
        # one statement per call keeps the command line short on large trees
        $batch = ''
        $sent = 0
        foreach ($s in $statements) {
            if (($batch.Length + $s.Length) -gt 6000) { Invoke-MySqlQuery -Database $db -Query $batch | Out-Null; $sent += 1; $batch = '' }
            $batch += $s
        }
        if ($batch) { Invoke-MySqlQuery -Database $db -Query $batch | Out-Null }
        Ok "$db`: $(@($toFix | Where-Object Database -eq $db).Count) row(s) corrected"
    }
}

# ==============================================================================
Step "5/5  Verifying"
$stillWrong = 0
$stillContent = 0
foreach ($db in ($plan.Database | Select-Object -Unique)) {
    $rows = Get-MySqlRows -Database $db -Query 'SELECT `name`,`hash` FROM `updates`;'
    $byName = @{}
    foreach ($r in $rows) { $byName[$r[0]] = ($r[1]).Trim().ToUpperInvariant() }
    foreach ($p in ($plan | Where-Object Database -eq $db)) {
        if ($byName[$p.Name] -ne $p.Correct) {
            if ($p.Kind -eq 'content') { $stillContent++ } else { $stillWrong++ }
        }
    }
}
if ($DryRun) {
    Info "-DryRun: database unchanged. Run without -DryRun to apply."
    exit 0
}
if ($stillWrong -gt 0) { Die "$stillWrong row(s) could not be corrected - check the MySQL user's privileges." }
Ok "all line-ending hashes now match what the core computes"
if ($stillContent -gt 0) {
    Warn "$stillContent update file(s) genuinely differ from what was applied; the server will re-apply them on start."
    Warn "That is normal after a 'git pull'. If one of them fails, read docs/TROUBLESHOOTING.md section 18."
}
Write-Host "`n  Start the server again:  .\4-Start-Server.bat" -ForegroundColor Green
