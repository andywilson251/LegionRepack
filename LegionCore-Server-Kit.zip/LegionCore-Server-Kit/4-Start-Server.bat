@echo off
REM ============================================================================
REM  LegionCore 7.3.5 - start the server
REM  Edit the two paths below if you changed them in kit-config.ps1
REM ============================================================================
set "SERVERDIR=C:\LegionCore\server"

title LegionCore 7.3.5
echo Starting bnetserver (login server) and worldserver (game server)...
echo.
echo   Login account: see kit-config.ps1  (default GM@GM / admin)
echo   First start can take several minutes while the world database loads.
echo   Keep both windows open. To stop the server, run 4-Stop-Server.bat.
echo.

if not exist "%SERVERDIR%\worldserver.exe" (
    echo [XX] %SERVERDIR%\worldserver.exe not found - run 2-Build-Core.ps1 first.
    pause
    exit /b 1
)

start "LegionCore BnetServer" /D "%SERVERDIR%" cmd /k "bnetserver.exe"
timeout /t 3 /nobreak >nul
start "LegionCore WorldServer" /D "%SERVERDIR%" cmd /k "worldserver.exe"
exit /b 0
